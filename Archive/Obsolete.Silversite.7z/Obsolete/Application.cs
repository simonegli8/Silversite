﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Web;
using System.Web.Security;
using System.Web.Hosting;

namespace Silversite.Services {

	public class Application: Web.IHttpAutoModule {

		static HttpApplication App;

		public virtual void Init(HttpApplication app) {
			App = app;
		}

		public void Dispose() { }

		public static string MapPath(string path) {
			return HostingEnvironment.MapPath(path);
			
			/*
			if (HttpContext.Current != null) {
				if (rootPath == null) rootPath = HttpContext.Current.Server.MapPath("~");
				return HttpContext.Current.Server.MapPath(path);
			} else if (path.StartsWith("~")) {
				if (rootPath != null) {
					if (path == "~" || path == "~/") return rootPath;
					return Path.Combine(rootPath, path.Substring(2).Replace('/', Path.DirectorySeparatorChar));
				}
				return path.Substring(2).Replace('/', Path.DirectorySeparatorChar);
			} else {
				return path;
			}
			*/
			// return App.Server.MapPath(path);
		}

		public static HttpApplication Current {
			get {
				if (HttpContext.Current != null) App = HttpContext.Current.ApplicationInstance;
				return App;
			}
		}

		public static HttpApplicationState State {
			get { return Current.Application; }
		}

		public static string Home {
			get {
				try {
					State.Lock();
					string home = State["home"] as string;
					if (home == null) {
						try {
							string url = HttpContext.Current.Request.Url.AbsoluteUri;
							string file = HttpContext.Current.Request.AppRelativeCurrentExecutionFilePath;
							file = file.Replace("~", string.Empty);
							State["home"] = home = url.Replace(file, string.Empty);
						} catch {
						}
					}
					return home;
				} finally {
					State.UnLock();
				}
			}
			set {
				try {
					State.Lock();
					State["home"] = value;
				} finally {
					State.UnLock();
				}
			}
		}

		public static Exception GetLastError() {
			return Current.Server.GetLastError();
		}

		public ApplicationShutdownReason ShudwonReason { get { return HostingEnvironment.ShutdownReason; } }
	}
}