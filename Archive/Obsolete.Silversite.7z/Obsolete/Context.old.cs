﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Objects;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Data.Entity;
using System.Data.Common;
using System.Reflection;

namespace Silversite.Data {

	public class Context: IDisposable, IObjectContextAdapter {
		public Context() { Database = Database.Default; Database.Default.Open(this); InitSets(); }
		public Context(Database db) { db.Open(this); InitSets(); }

		public virtual void Dispose() { DbContext.Dispose(); }
		public DbEntityEntry Entry(object entity) { return DbContext.Entry(entity); }
		public DbEntityEntry<TEntity> Entry<TEntity>(TEntity entity) where TEntity: class { return DbContext.Entry<TEntity>(entity); }
		public IEnumerable<DbEntityValidationResult> GetValidationErrors() { return DbContext.GetValidationErrors(); }
		protected virtual void OnModelCreating(DbModelBuilder modelBuilder) { }
      public virtual int SaveChanges() { return DbContext.SaveChanges(); }
		public DbSet<TEntity> Set<TEntity>() where TEntity: class { return DbContext.Set<TEntity>(); }
		public DbSet Set(Type entityType) { return DbContext.Set(entityType); }
		protected virtual bool ShouldValidateEntity(DbEntityEntry entityEntry) { return DbContext.CallShouldValidateEntity(entityEntry); }
		protected virtual DbEntityValidationResult ValidateEntity(DbEntityEntry entityEntry, IDictionary<object, object> items) { return DbContext.CallValidateEntity(entityEntry, items); }
		public DbChangeTracker ChangeTracker { get; }
		public DbContextConfiguration Configuration { get; }
		public Database Database { get; set; }
		ObjectContext IObjectContextAdapter.ObjectContext { get { return ((IObjectContextAdapter)DbContext).ObjectContext; } }
		
		internal IEnumerable<Tuple<PropertyInfo, Type>> Sets {
			get {
				return this.GetType().GetProperties(BindingFlags.Public)
					.Where(p => p.PropertyType.IsSubclassOf(typeof(DbSet)) && p.PropertyType.IsGenericType && p.PropertyType.GetGenericArguments().Length == 1)
					.Select(p => new Tuple<PropertyInfo, Type>(p, p.PropertyType.GetGenericArguments()[0]));
			}
		}
		internal void CreateModelForSetProperties(DbModelBuilder modelBuilder) {
			var em = modelBuilder.GetType().GetMethod("Entity");
			foreach (var p in Sets) {
					var emg = em.MakeGenericMethod(p.Item2);
					emg.Invoke(modelBuilder, null);
			}
		}
		internal void InitSets() {
			foreach (var p in Sets) {
				p.Item1.SetValue(this, DbContext.Set(p.Item2), null);
			}
		}
		internal void CallOnModelCreating(DbModelBuilder modelBuilder) { CreateModelForSetProperties(modelBuilder); OnModelCreating(modelBuilder); }
		internal bool CallShouldValidateEntity(DbEntityEntry entityEntry) { return ShouldValidateEntity(entityEntry); }
		internal DbEntityValidationResult CallValidateEntity(DbEntityEntry entityEntry, IDictionary<object, object> items) { return ValidateEntity(entityEntry, items); }
		public ProviderContext DbContext { get; set; }
	}

	public class ProviderContext: DbContext {
		Context context;
		public ProviderContext(Context context): base(context.Database.Connection, false) { this.context = context; }
		internal bool CallShouldValidateEntity(DbEntityEntry entityEntry) { return base.ShouldValidateEntity(entityEntry); }
		internal DbEntityValidationResult CallValidateEntity(DbEntityEntry entityEntry, IDictionary<object, object> items) { return base.ValidateEntity(entityEntry, items); }

		protected override void  OnModelCreating(DbModelBuilder modelBuilder) {
			context.CallOnModelCreating(modelBuilder);
		}
		protected override bool ShouldValidateEntity(DbEntityEntry entityEntry) { return context.CallShouldValidateEntity(entityEntry); }
		protected override DbEntityValidationResult ValidateEntity(DbEntityEntry entityEntry, IDictionary<object, object> items) { return context.CallValidateEntity(entityEntry, items); }
	}

}