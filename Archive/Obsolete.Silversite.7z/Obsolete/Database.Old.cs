﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Web.Configuration;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.ComponentModel.DataAnnotations;
using System.Web.Hosting;
using System.Reflection;
using Silversite.Configuration;
using System.Data.Entity;
using System.Data.Common;

namespace Silversite.Services {

	[Table("ContextVersions", Schema = "Silversite")]
	public class ContextVersion {
		[Key]
		public string AssemblyQualifiedName { get; set; }
		public string Context { get; set; }
		public int Version { get; set; }
	}

	public class ContextVersionAttribute: Attribute {
		public ContextVersionAttribute(int version) { Version = version; }
		public int Version { get; set; }
	}


	/*
	public static class DbModelBuilderExtensions {
	
		public DbModelBuilder ContextByConvention(this DbModelBuilder m, DbContext ctx) {
			var t = ctx.GetType();
			var props = t.GetProperties(BindingFlags.FlattenHierarchy | BindingFlags.Public | BindingFlags.GetProperty);
			foreach (var p in props) {
				if (p.PropertyType.IsGenericType &&
					(p.PropertyType.Name.StartsWith("IDbSet<") || p.PropertyType.Name.StartsWith("DbSet<"))) {
					var arg = p.PropertyType.GetGenericArguments()[0];
		
		public static DbModelBuilder ContextByFluent(this DbModelBuilder m, DbContext ctx) {
			var method = ctx.GetType().GetMethod("OnModelCreating", BindingFlags.FlattenHierarchy | BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.InvokeMethod);
			method.Invoke(ctx, new object[] { m });
		}

		public DbModelBuilder Context(this DbModelBuilder m, DbContext ctx) {
			m.ContextByConvention(ctx);
			m.ContextByFluent(ctx);
		}

	}
	*/

	public class Database: StaticService<Database>, IDataService {

		public class Context: DbContext {
			public Context() : base(Connection(), true) { /* Register(this); */ }
			public Context(DbConnection db) : base(db, true) { }

			static Context() {
				try { System.Data.Entity.Database.SetInitializer<Context>(new DropCreateDatabaseIfModelChanges<Context>()); } catch { }
			}

			public DbSet<ContextVersion> Versions { get; set; }
			public DbSet<Membership.User> Users { get; set; }
			public DbSet<Membership.Role> Roles { get; set; }
			public DbSet<Person> Persons { get; set; }
			public DbSet<Document> Documents { get; set; }
			public DbSet<LogMessage> Messages { get; set; }
		}

		public class VersionsContext: Context {
			public VersionsContext() : base() { }
			public VersionsContext(DbConnection db) : base(db) { }
			// public VersionsContext() { Load(); }

			//public List<ContextVersion> Versions;

			public int Version(DbContext context) {
				var type = context.GetType();
				var contextname = type.FullName;
				var assembly = type.AssemblyQualifiedName;
				var ctxver = Versions.Where(v => v.Context == contextname);
				var x = ctxver.DefaultIfEmpty();
				if (ctxver.Count() > 0) return ctxver.Max(v => v.Version);
				else return 0;
				// return Versions.Where().DefaultIfEmpty<ContextVersion>().Max(v => v.Version);
			}

			public void SetVersion(DbContext context) {
				var type = context.GetType();
				var contextname = type.FullName;
				var assembly = type.AssemblyQualifiedName;
				int version = ContextVersion(context);
				if (!Versions.Any(v => v.Context == contextname && v.Version== version)) {
					Versions.Add(new ContextVersion { Context = contextname, AssemblyQualifiedName = assembly, Version = version });
					SaveChanges();
				}
			}

			/*
			readonly string File = HostingEnvironment.MapPath(ConfigRoot + "/Versions.config");
			
			int N;
			public void Load() {
				Versions = new List<ContextVersion>();
				N = 0;
				using (var file = new FileStream(File, FileMode.OpenOrCreate, FileAccess.Read)) {
					var r = new BinaryReader(file);
					while (r.BaseStream.Position < r.BaseStream.Length) {
						var ver = new ContextVersion { AssemblyQualifiedName = r.ReadString(), Context = r.ReadString(), Version = r.ReadInt32() };
						Versions.Add(ver);
						N++;
					}
				}
			}

			public void SaveChanges() {
				using (var file = new FileStream(File, FileMode.OpenOrCreate,	FileAccess.Write)) {
					var w = new BinaryWriter(file);
					while (N < Versions.Count) {
						w.Write(Versions[N].AssemblyQualifiedName); w.Write(Versions[N].Context); w.Write(Versions[N].Version);
						N++;
					}
				}
			}
			
			public void Dispose() { } */
		}

		static HashSet<Type> Contexts = new HashSet<Type>();
		//static HashSet<Type> Initializers = new HashSet<Type>();
		static DbConnection CustomConnection = null;

		public static DatabaseProvider DatabaseProvider { get { return (DatabaseProvider)(StaticService<Database>.Provider); } }
		public static DatabaseConfiguration Configuration = new DatabaseConfiguration();

		public static int ContextVersion(DbContext context) {
			var version = context.GetType().GetAttribute<ContextVersionAttribute>();
			if (version != null) return version.Version;
			else return 1;
		}

		public static event EventHandler Changing;
		public static event EventHandler Changed;

		public static void Register(DbContext context) {
			if (!Contexts.Contains(context.GetType())) {
				if (!(context is VersionsContext)) {
					var ver = ContextVersion(context);
					int dbver = 0;
					using (var c = new VersionsContext()) {
						dbver = c.Version(context);
					}
					if (ver != dbver) {
						Update();
						using (var c = new VersionsContext()) {
							c.SetVersion(context);
							c.SaveChanges();
						}
					}
				}
				Contexts.Add(context.GetType());
			}
		}

		public static ConnectionStringSettingsCollection ConnectionStrings { get { return Configuration.ConnectionStrings; } }
		public static ConnectionStringSettings ConnectionString { get { return Configuration.ConnectionString; } }

		public static DbConnection Connection() { return Connection(ConnectionString); }
		public static DbConnection Connection(string ConnectionStringName) { return Connection(ConnectionStrings[ConnectionStringName]); }
		public static DbConnection Connection(ConnectionStringSettings settings) {
			lock (Contexts) {
				if (CustomConnection != null) return CustomConnection;
			}
			return DatabaseProvider.Connection(settings);
		}

		public static DbContext NewContext(Type context) { return Activator.CreateInstance(context) as DbContext; }
		public static DbContext NewContext(Type context, DbConnection db) {
			DbContext c = null;
			lock (Contexts) {
				try {
					CustomConnection = db;
					c = NewContext(context);
				} finally {
					CustomConnection = null;
				}
			}
			return c;
		}

		public void Backup(Stream s) {
			var f = new BinaryFormatter();
			foreach (var ctype in Contexts) {
				var context = NewContext(ctype);
				if (context != null) {
					var props = ctype.GetProperties().Where(p => p.PropertyType.IsSubclassOf(typeof(DbSet)));
					foreach (var p in props) {
						var set = (DbSet)p.GetValue(context, new object[0] { });
						foreach (var e in set) {
							if (e is ISerializable) {
								s.WriteByte(1);
								f.Serialize(s, e);
							} else {
								Log.Error("Backup: Persistent class {0} is not serializable.", e.GetType().FullName);
							}
						}
						s.WriteByte(0);
					}
				} else {
					Log.Error("Backup: Cannot create instance of {0}.", ctype.FullName);
				}
			}
		}

		public void Restore(Stream s) {
			var f = new BinaryFormatter();
			foreach (var ctype in Contexts) {
				var context = NewContext(ctype);
				if (context != null) {
					var props = ctype.GetProperties().Where(p => p.PropertyType.IsSubclassOf(typeof(DbSet)));
					foreach (var p in props) {
						var set = (DbSet)p.GetValue(context, new object[0] { });
						while (s.ReadByte() == 1) {
							var e = f.Deserialize(s);
							set.Add(e);
						}
					}
					context.SaveChanges();
				}
			}
		}

		static void Copy(DbConnection db, bool to) {
			foreach (var ctype in Contexts) {

				var src = NewContext(ctype);
				var dest = NewContext(ctype, db);

				var types = new HashSet<Type>();

				if (src != null && dest != null) {
					var props = ctype.GetProperties().Where(p => p.PropertyType.IsSubclassOf(typeof(DbSet)));
					foreach (var p in props) {

						if (p.PropertyType.IsGenericType) {
							var args = p.PropertyType.GetGenericArguments();
							if (args.Length == 1) {
								if (types.Contains(args[0])) continue;
								else types.Add(args[0]);
							}
						}

						var srcset = (DbSet)p.GetValue(src, new object[0] { });
						var destset = (DbSet)p.GetValue(dest, new object[0] { });

						if (to) {
							foreach (var e in destset) { destset.Remove(e); }
							foreach (var e in srcset) { destset.Add(e); }
							dest.SaveChanges();
						} else {
							foreach (var e in srcset) { srcset.Remove(e); }
							foreach (var e in destset) { srcset.Add(e); }
							src.SaveChanges();
						}
					}
				} else {
					Log.Error("Backup: Cannot create instance of {0}.", ctype.FullName);
				}
			}
		}

		public static void CopyTo(DbConnection dest) { Copy(dest, true); }
		public static void CopyFrom(DbConnection src) { Copy(src, false); }

		public static bool Exists() { return Exists(Connection()); }
		public static void Drop() { Drop(Connection()); }
		public static void Create() { Create(Connection()); }
		public static void Update() { Update(Connection()); }

		public static bool Exists(DbConnection db) { return DatabaseProvider.Exists(db); }
		public static void Drop(DbConnection db) { DatabaseProvider.DropDatabase(new Context(db)); }
		public static void Create(DbConnection db) {
			DatabaseProvider.CreateDatabase(new Context(db));
		}
		public static void Update(DbConnection db) { DatabaseProvider.UpdateDatabase(new Context(db)); }

		static int level = 0;
		public static void OnChanging() { if (Changing != null && level++ == 0) Changing(null, EventArgs.Empty); }
		public static void OnChanged() { if (Changed != null && --level == 1) Changed(null, EventArgs.Empty); level = Math.Max(0, level); }

		public void Init(HttpApplication context) {

			// Web.HttpModule.DependsOn(typeof(Providers), context);

			//			System.Data.Entity.Database.SetInitializer<Context>(new DropCreateDatabaseIfModelChanges<Context>());

			// if (!Exists()) Create();	
			/* ContextVersion ver;
			using (var c = new Context()) ver = c.Versions.FirstOrDefault();
			*/
		}
	}

	[Configuration.Section(Path = DatabaseConfiguration.Path)]
	public class DatabaseConfiguration: Configuration.Section {

		public new const string Path =  ConfigRoot + "/silversite.config";
		[ConfigurationProperty("connectionString", IsRequired = false, DefaultValue = "SilversiteDatabase")]
		public string ConnectionStringName { get { return this["connectionString"] as string ?? string.Empty; } set { this["connectionString"] = value; } }

		public ConnectionStringSettings ConnectionString {
			get {
				var settings = ConnectionStrings[ConnectionStringName];
				if (settings == null && ConnectionStrings.Count > 0) settings = ConnectionStrings[0];
				return settings;
			}
		}
	}

	[DefaultProvider]
	public class DatabaseProvider: Provider<Database> {

		public class Factory {
			public Factory() : this(Database.ConnectionString) { }
			public Factory(ConnectionStringSettings settings) {
				Settings = settings;
				ProviderFactory = null;

				string providerName = null;
				var csb = new DbConnectionStringBuilder { ConnectionString = Settings.ConnectionString };

				if (csb.ContainsKey("provider")) {
					providerName = csb["provider"].ToString();
				} else {
					providerName = Settings.ProviderName;
				}

				if (providerName != null) {
					try {
						ProviderFactory = DbProviderFactories.GetFactory(providerName);
					} catch { }
				}
			}

			public ConnectionStringSettings Settings;
			public DbProviderFactory ProviderFactory;
		}

		public class FactoryCollection: KeyedCollection<string, Factory> {
			protected override string GetKeyForItem(Factory f) { return f.Settings.Name; }
		}

		public DatabaseProvider() {
			// Factories.Add(new Factory());
		}

		static FactoryCollection Factories = new FactoryCollection();

		public virtual DbConnection Connection(ConnectionStringSettings settings) {
			if (settings == null) return null;
			Factory f = null;
			if (Factories.Contains(settings.Name)) f = Factories[settings.Name];
			else {
				f = new Factory(settings);
				Factories.Add(f);
			}
			var conn = f.ProviderFactory.CreateConnection();
			conn.ConnectionString = settings.ConnectionString;

			return conn;
		}

		public virtual bool Exists(DbConnection db) {
			return System.Data.Entity.Database.Exists(db);
		}
		public virtual void DropDatabase(Database.Context context) {
			Database.OnChanging();
			Providers.Message(new Providers.MessageInfo { Sender = this, Text = "Deleting database." });
			context.Database.Delete();
			Database.OnChanged();
		}
		public virtual void CreateDatabase(Database.Context context) {
			if (!context.Database.Exists()) {
				Database.OnChanging();
				Providers.Message(new Providers.MessageInfo { Sender = this, Text = "Creating database." });
				try {
					context.Database.Create();
					Providers.Message(new Providers.MessageInfo { Sender = this, Text = "Database created.", Finished = true });
				} catch (Exception ex) {
					Providers.Message(new Providers.MessageInfo { Sender = this, Text = "Error creating database.", Exception = ex, Finished = true });
				}
				Database.OnChanged();
			}
		}
		public virtual void UpdateDatabase(Database.Context context) {
			if (context.Database.Exists() && !context.Database.CompatibleWithModel(false)) {
				Database.OnChanging();
				DropDatabase(context);
			}
			CreateDatabase(context);
			Database.OnChanged();
		}

	}
}

