﻿using System.Web; 
using System.Web.UI;
using System.Web.UI.WebControls;
using System;  
using System.Collections.Generic; 
using System.ComponentModel;  
using System.Text; 

namespace Silversite.Web.UI { 

    public abstract class DbContextDataSource : QueryableDataSource { 
        private DbContextDataSourceView _view;  
  
		 
        protected ContextDataSource(IPage page)  
            : base(page) {  
  
        }  
  
        protected ContextDataSource(DbContextDataSourceView view) 
            : base(view) { 
        } 
  
        protected ContextDataSource() {  
        }  
  
        private DbContextDataSourceView View {  
            get { 
                if (_view == null) { 
                    _view = (DbContextDataSourceView)GetView("DefaultView"); 
                }  
                return _view; 
            }  
        }  
  
        public virtual string ContextTypeName {  
            get { 
                return View.ContextTypeName; 
            } 
            set {  
                View.ContextTypeName = value; 
            }  
        }  
  
        protected string EntitySetName {  
            get { 
                return View.EntitySetName; 
            } 
            set {  
                View.EntitySetName = value; 
            }  
        }  
  
        public virtual string EntityTypeName {  
            get { 
                return View.EntityTypeName; 
            } 
            set {  
                View.EntityTypeName = value; 
            }  
        }  
    } 
} 