﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using System.Web;
using System.Web.UI.WebControls;
using System.Collections;
using System.Threading.Tasks;
using System.Web.DynamicData;
using System.Web.UI;

namespace Silversite.Web.UI {

	public class DbDataSource<TContext, TElement>: AsyncDataSourceControl, IDynamicDataSource, IQueryableDataSource where TContext: Context {

		public static readonly string ViewName = "DbView";

		public DbDataSource(): base() {
			EnableDelete = EnableInsert = EnableUpdate = true; Projection = false;
		}
		public DbDataSource(string source) : this() { Source = source; }
 
		private DbDataSourceView<TContext, TElement> view;

		private DbDataSourceView<TContext, TElement> View {
			get {
				if (view == null) view = new DbDataSourceView<TContext, TElement>(this, ViewName);
				return view;
			}
		}

		protected override DataSourceView GetView(string viewName) {
			if (String.IsNullOrEmpty(viewName) || (String.Compare(viewName, ViewName, StringComparison.OrdinalIgnoreCase) == 0)) return View;
			throw new ArgumentOutOfRangeException("viewName");
		}

		protected override ICollection GetViewNames() {
			return new string[] { ViewName };
		}

		//public Func<IQueryable<TElement>, IQueryable> Query(Func<IQueryable<TElement>, IQueryable> query) { return new Func<IQueryable, IQueryable>(set => filter((IQueryable<T>)set)); }
		//public Func<IQueryable, IQueryable> Query(Func<IQueryable, IQueryable> query) { return query; }

		//public void SetFilter<T>(Func<IQueryable<T>, IQueryable> filter) where T: class { Filter = Query<T>(filter); }
		//public void SetFilter(Func<IQueryable, IQueryable> filter) { Filter = filter; }

		internal void RaiseChangedEvent() {
			if (view != null) view.RaiseChangedEvent();
		}

		private Func<DbSet<TElement>, IQueryable<object>> filter = null;
		public Func<DbSet<TElement>, IQueryable<object>> Filter { get { return filter; } set { filter = value; RaiseChangedEvent(); } }
		public string Set { get { return (string)ViewState["Set"]; } set { ViewState["Set"] = value; RaiseChangedEvent(); } }
		public Type ContextType { get { return (Type)ViewState["Context"]; } set { ViewState["Context"] = value; RaiseChangedEvent(); } }
		public bool Projection { get { return (bool)ViewState["Projection"]; } set { ViewState["Projection"] = value; } }
		public string Source {
			get { return (ContextType ?? typeof(DbContext)).FullName + "." + Set; }
			set { 
				string assembly = null;
				var comma = value.IndexOf(',');
				var type = value;
				if (comma >= 0) {
					assembly = value.Substring(comma);
					type = value.Substring(0, comma);
				}
				string set = null;
				var dot = type.LastIndexOf('.');
				if (dot == 0) throw new ArgumentException("Source must be the fully qualified name of a property of a DbContext.");
				set = type.Substring(dot+1);
				type = type.Substring(0, dot);
				
				if (assembly != null) type = type + assembly;

				var v = view;
				view = null;
				ContextType = Type.GetType(type);
				Set = set;
				view = v;
				RaiseChangedEvent();
			}
		}
	
		public bool  AutoGenerateWhereClause { get; set; }
		
		public bool  EnableDelete { get; set; } 
		public bool  EnableInsert { get; set; }
		public bool  EnableUpdate { get; set; } 
		public string EntitySetName { get { return Set; } set { Set = value; } }
		public event EventHandler<DynamicValidatorEventArgs>  Exception; // TODO

		public string  Where { get; set; }
		public ParameterCollection WhereParameters { get { throw new NotImplementedException(); } }
		public event EventHandler<QueryCreatedEventArgs> QueryCreated; // TODO
		public void  RaiseViewChanged() { RaiseChangedEvent(); }
	}
	
	public class DbDataSourceView<TElement>: AsyncDataSourceView {

		 private DbDataSource<TElement> owner;

		 public DbDataSourceView(DbDataSource<TElement> owner, string viewName): base(owner, viewName) {
			  this.owner = owner;
		 }

		 DbContext context = null;
		private IQueryable<object> Query(System.Web.UI.DataSourceSelectArguments arg) {
			 if (context == null) context = (DbContext)New.Object(owner.ContextType);
			var setprop = owner.ContextType.GetProperty(owner.Set);
			var set = (DbSet<TElement>)setprop.GetValue(context, null);
			if (owner.Filter == null) return set;
			return owner.Filter(set.OfType<TElement>());
		}

		private class SyncResult: IAsyncResult {
			public SyncResult(IQueryable query) { Query = query; }
			public IQueryable Query { get; set; }
			public object  AsyncState	{ get; set; }
			public System.Threading.WaitHandle  AsyncWaitHandle { 	get { throw new NotImplementedException(); } }
			public bool  CompletedSynchronously { get { return true; } }
			public bool  IsCompleted { get { return true; } }
		}

		protected override IAsyncResult  BeginExecuteSelect(System.Web.UI.DataSourceSelectArguments arguments, AsyncCallback asyncCallback, object asyncState) {
			if (owner.PerformAsyncDataAccess) {
				return Task.Factory.StartNew<IQueryable>(() => {
					var q = Query(arguments);
					if (arguments.RetrieveTotalRowCount) arguments.TotalRowCount = q.Count();
					if (arguments.StartRowIndex != 0) q = q.Skip(arguments.StartRowIndex);
					if (arguments.MaximumRows > 0) q = q.Take(arguments.MaximumRows);
					return q.ToList();
				});
			} else {
				var q = Query();
				if (arguments.RetrieveTotalRowCount) arguments.TotalRowCount = q.Count();
				if (arguments.StartRowIndex != 0) q = q.Skip(arguments.StartRowIndex);
				if (arguments.MaximumRows > 0) q = q.Take(arguments.MaximumRows);
				return new SyncResult(q.ToList());
			}
		}

		protected override IEnumerable EndExecuteSelect(IAsyncResult asyncResult) {
			IEnumerable res;
			if (asyncResult is Task<IQueryable>) res = ((Task<IQueryable>)asyncResult).Result;
			else return ((SyncResult)asyncResult).Query;
		}

		public override bool CanPage { get { return true; } }
		public override bool CanRetrieveTotalRowCount { get { return true; } }
		public override bool CanSort { get { return true; } } 
		public override bool CanDelete { get { return !owner.Projection; } }
		public override bool CanInsert { get { return !owner.Projection; } }
		public override bool  CanUpdate { get { return !owner.Projection; } }

		protected override int ExecuteDelete(IDictionary keys, IDictionary oldValues) {
			//base.Delete(keys, oldValues, callback);
			try {
				using (var context = (DbContext)New.Object(owner.ContextType)) {
					var setprop = owner.ContextType.GetProperty(owner.Set);
					var set = (DbSet)setprop.GetValue(context, null);
					var keynames = keys.Keys.OfType<string>().ToList();
					object x;
					if (keys.Count == 1) {
						x = set.Find(keynames[0]);
					} else {
						var keyindexes = keys.Keys.OfType<string>().Select(key => set.ElementType.GetProperties().Select(p => p.Name).ToList().IndexOf(key)).ToList();
						x = set.Find(keynames.OrderBy(name => keyindexes));
					}
					foreach (var prop in set.ElementType.GetProperties()) {
						var oldvalue = prop.GetValue(x, null);
						oldValues[prop.Name] = oldvalue;
					}
					set.Remove(x);
				}
				RaiseChangedEvent();
				return 1;
			} catch { return 0; }
		}

		protected override int ExecuteInsert(IDictionary values) {
	 		//base.ExecuteInsert(values);
			try {
				using (var context = (DbContext)New.Object(owner.ContextType)) {
					var setprop = owner.ContextType.GetProperty(owner.Set);
					var set = (DbSet)setprop.GetValue(context, null);
					var x = set.Create();
					foreach (string key in values.Keys) {
						var prop = set.ElementType.GetProperty(key);
						prop.SetValue(x, values[key], null);
					}
				}
				RaiseChangedEvent();
				return 1;
			} catch {
				return 0;
			}
		}

		protected override int ExecuteUpdate(IDictionary keys, IDictionary values, IDictionary oldValues) {
 			//base.ExecuteUpdate(keys, values, oldValues);
			if (keys.Count == 0) return 0;
			try {
				using (var context = (DbContext)New.Object(owner.ContextType)) {
					var setprop = owner.ContextType.GetProperty(owner.Set);
					var set = (DbSet)setprop.GetValue(context, null);
					var keynames = keys.Keys.OfType<string>().ToList();
					object x;
					if (keys.Count == 1) {
						x = set.Find(keynames[0]);
					} else {
						var keyindexes = keys.Keys.OfType<string>().Select(key => set.ElementType.GetProperties().Select(p => p.Name).ToList().IndexOf(key)).ToList();
						x = set.Find(keynames.OrderBy(name => keyindexes));
					}
					foreach (var prop in set.ElementType.GetProperties()) {
						var oldvalue = prop.GetValue(x, null);
						oldValues[prop.Name] = oldvalue;
					}
					foreach (string key in values.Keys) {
						var prop = set.ElementType.GetProperty(key);
						prop.SetValue(x, values[key], null);
					}
				}
				RaiseChangedEvent();
				return 1;
			} catch {
				return 0;
			}
		}

		internal void RaiseChangedEvent() {
			OnDataSourceViewChanged(EventArgs.Empty);
		}
	}
}