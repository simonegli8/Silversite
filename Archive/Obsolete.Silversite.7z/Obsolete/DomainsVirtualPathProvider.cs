﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Reflection;
using System.Security.Permissions;
using System.Text;
using System.IO;
using System.Web.Hosting;

namespace Silversite.Web {

	public class DomainsVirtualPathProvider: VirtualPathProvider, IAutostart {

		public class DomainsVirtualDirectory: System.Web.Hosting.VirtualDirectory {
		
			public DomainsVirtualDirectory(string path): base(path) { }

			public DomainsVirtualPathProvider Provider { get { return DomainsVirtualPathProvider.Current; } }

			public override System.Collections.IEnumerable Children {
				get {
					return Directories.OfType<object>().Concat(Files.OfType<object>());
				}
			}

			public override System.Collections.IEnumerable Directories {
				get {
					var dpath = Services.Paths.Domains(VirtualPath);
					IEnumerable<System.Web.Hosting.VirtualDirectory> dirs = new VirtualDirectory[0];
					if (Provider.Previous.DirectoryExists(VirtualPath)) {
						dirs = dirs.Concat(Provider.Previous.GetDirectory(VirtualPath).Directories.OfType<System.Web.Hosting.VirtualDirectory>());
					}
					if (Provider.Previous.DirectoryExists(dpath)) {
						dirs = dirs.Concat(Provider.Previous.GetDirectory(dpath).Directories.OfType<System.Web.Hosting.VirtualDirectory>());
					}
					return dirs.OrderBy(d => Services.Paths.File(d.VirtualPath));
				}
			}

			public override System.Collections.IEnumerable Files {
				get {
					var dpath = Services.Paths.Domains(VirtualPath);
					IEnumerable<System.Web.Hosting.VirtualFile> files = new VirtualFile[0];
					if (Provider.Previous.DirectoryExists(VirtualPath)) {
						files = files.Concat(Provider.Previous.GetDirectory(VirtualPath).Files.OfType<System.Web.Hosting.VirtualFile>());
					}
					if (Provider.Previous.DirectoryExists(dpath)) {
						files = files.Concat(Provider.Previous.GetDirectory(dpath).Files.OfType<System.Web.Hosting.VirtualFile>().Select(f => new DomainsVirtualFile(f.VirtualPath)));
					}
					return files.OrderBy(f => Services.Paths.File(f.VirtualPath));
				}
			}
		}

		public class DomainsVirtualFile: System.Web.Hosting.VirtualFile {

			public DomainsVirtualFile(string path) : base(path) { domain = Services.Domains.Current; }

			string domain;

			public override Stream Open() {
				return new FileStream(Services.Paths.Map(Services.Paths.Domains(domain, Services.Paths.FromVirtual(VirtualPath))), FileMode.Open, FileAccess.Read);
			}
		}

		public static string RootPath = Services.Domains.RootPath;

		/*
			public override string CombineVirtualPaths(string basePath, string relativePath) { 

			var bpath = base.CombineVirtualPaths(basePath, relativePath);

			var dpath = Services.Paths.Domains(bpath);
 
			if (Previous.DirectoryExists(dpath) || Previous.FileExists(dpath)) 
				return dpath;
			else return bpath;
		}
		 */

		public DomainsVirtualPathProvider() { }

		public string DPath(string virtualPath) { return Services.Paths.Virtual(Services.Paths.Domains(Services.Paths.FromVirtual(virtualPath))); }

		public override bool FileExists(string virtualPath) {
			var res = Previous.FileExists(virtualPath) || Previous.FileExists(DPath(virtualPath));
			return res;
		}

		public override bool DirectoryExists(string virtualPath) {
			var res = Previous.DirectoryExists(virtualPath) || Previous.DirectoryExists(DPath(virtualPath));
			return res;
		}

		public override System.Web.Caching.CacheDependency GetCacheDependency(string virtualPath, System.Collections.IEnumerable virtualPathDependencies, DateTime utcStart) {
			IEnumerable<string> files = new string[1] { virtualPath }
				.Concat(virtualPathDependencies.OfType<string>())
				.Select(p => Previous.FileExists(DPath(p)) ? DPath(p) : p)
				.Select(p => Services.Paths.Application(p))
				.Where(p => Services.Files.FileExists(p))
				.Select(p => Services.Paths.Map(p));
			return new System.Web.Caching.CacheDependency(files.ToArray(), utcStart);
		}

		public override System.Web.Hosting.VirtualDirectory GetDirectory(string virtualDir) {
			if (DirectoryExists(virtualDir)) return new DomainsVirtualDirectory(virtualDir);
			return null;
		}

		public override System.Web.Hosting.VirtualFile GetFile(string virtualPath) {
			var dpath = DPath(virtualPath);

			if (Previous.FileExists(dpath)) return new DomainsVirtualFile(virtualPath); 
			else if (Previous.FileExists(virtualPath)) return Previous.GetFile(virtualPath);
			return null;
		}

		public override string GetFileHash(string virtualPath, System.Collections.IEnumerable virtualPathDependencies) {
			var dpath = DPath(virtualPath);

			if (Previous.FileExists(dpath)) return virtualPath = dpath;
			var deps = virtualPathDependencies.OfType<string>().Select(p => Previous.FileExists(DPath(p)) ? DPath(p) : p);

			return Previous.GetFileHash(virtualPath, deps);
		}

		[ReflectionPermission(SecurityAction.Demand)]
		public virtual void RegisterWithReflection() {
			// any settings about your VirtualPathProvider may go here.

			// we get the current instance of HostingEnvironment class. We can't create a new one
			// because it is not allowed to do so. An AppDomain can only have one HostingEnvironment
			// instance.
			System.Web.Hosting.HostingEnvironment hostingEnvironmentInstance=(System.Web.Hosting.HostingEnvironment)typeof(System.Web.Hosting.HostingEnvironment).InvokeMember("_theHostingEnvironment", BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.GetField, null, null, null);
			if (hostingEnvironmentInstance== null)
				return;

			// we get the MethodInfo for RegisterVirtualPathProviderInternal method which is internal
			// and also static.
			MethodInfo mi = typeof(System.Web.Hosting.HostingEnvironment).GetMethod("RegisterVirtualPathProviderInternal", BindingFlags.NonPublic | BindingFlags.Static);
			if (mi == null)
				return;

			// finally we invoke RegisterVirtualPathProviderInternal method with one argument which
			// is the instance of our own VirtualPathProvider.
			mi.Invoke(hostingEnvironmentInstance, new object[] { (DomainsVirtualPathProvider)this });
		}

		public void Register() {
			System.Web.Hosting.HostingEnvironment.RegisterVirtualPathProvider(this);
		}

		public static readonly DomainsVirtualPathProvider Current = new DomainsVirtualPathProvider();

		public void Dispose() { }

		public void Init(HttpApplication context) { Current.Register(); }
	}
}