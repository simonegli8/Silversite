﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.Util;
using System.Web.Configuration;
using System.Configuration;
using System.Drawing.Design;
using System.Threading;
using Silversite.Web.Store;

namespace Silversite.Web.UI {

	public interface IContentEditor {
		void EditContent(IContentControl control);
	}

	public interface IClientContentEditor: IContentEditor {
		string EditClientCommand(IContentControl control);
	}

	public interface IContentControl {
		string ClientID { get; }
		string Content { get; set; }
		string Name { get; }
		Page Page { get; }
	}

	public interface IClientContentControl {
		string SetClientCommand { get; }
		string GetClientCommand { get; }
	}

	public static class ControlExtensions {
		public static Control FindControlRecursive(this Control root, string clientID) {
			if (root.ClientID == clientID || root.ID == clientID) return root;

			foreach (Control Ctl in root.Controls) {
				Control FoundCtl = FindControlRecursive(Ctl, clientID);
				if (FoundCtl != null) return FoundCtl;
			}
			return null;
		}
	}

	public class DynamicContentConfiguration: ConfigurationSection {

		private const string ConfigSectiongroupSection = "DynamicContent";

		[ConfigurationProperty("xmlns", IsRequired=false)]
		public string Xmlns { get { return (string)this["xmlns"]; } set { this["xmlns"] = value; } }

		[ConfigurationProperty("EditPage", IsRequired=false, DefaultValue=null)]
		public string EditPage { get { return (string)this["EditPage"]; } set { this["EditPage"] = value; } }

		[ConfigurationProperty("EditImageUrl", IsRequired=false, DefaultValue="~/img/edit.png")]
		public string EditImageUrl { get { return (string)(this["EditImageUrl"] ?? "~/img/edit.png"); } set { this["EditImageUrl"] = value; } }

		[ConfigurationProperty("EnableContentViewState", IsRequired=false, DefaultValue=true)]
		public bool EnableContentViewState { get { return (bool)(this["EnableContentViewState"] ?? true); } set { this["EnableContentViewState"] = value; } }

		public void CopyFrom(DynamicContentConfiguration config) {
			if (config != null && config != this) {
				foreach (ConfigurationProperty key in config.Properties) {
					this[key] = config[key];
				}
			}
		}

		static DynamicContentConfiguration config = null;
		
		public static DynamicContentConfiguration Read() {
			try {
				config = WebConfigurationManager.GetSection(ConfigSectiongroupSection) as DynamicContentConfiguration;
			} catch (Exception ex) {
				Log.Error("Fehler beim lesen der DynmaicContent Konfiguration.", ex);
			}
			return config;
		}

		public void Reset() {
			config = null;
			Read();
		}

		public DynamicContentConfiguration(): base() {
			if (config == null) {
				config = this;
				CopyFrom(Read());
			}
		}
	}

	[ToolboxData("<{0}:DynamicHtmlContent runat=\"server\" />")]
	public class DynamicHtmlContent: CompositeControl, IContentControl {

		class Span: WebControl {
			protected override HtmlTextWriterTag TagKey { get { return HtmlTextWriterTag.Span; } }
		}

		Literal literal = new Literal();
		System.Web.UI.WebControls.ImageButton button = new System.Web.UI.WebControls.ImageButton();
		LinkButton link = new LinkButton(); 
		Literal br = new Literal();
		Literal spacer = new Literal();
		Span span, contentspan;
		Panel panel;

		public static DynamicContentConfiguration Configuration = new DynamicContentConfiguration();
	
		public DynamicHtmlContent() { }

		[Bindable(true),
		Category("Behavior"),
		DefaultValue(string.Empty),
		Editor("System.Web.UI.Design.UrlEditor, SystemDesign", typeof(UITypeEditor)),
		UrlProperty()]
		public virtual string EditPage {
			get {
				return
					(string)ViewState["EditPage"] ?? 
					Configuration.EditPage ??
					string.Empty;
			}
			set { ViewState["EditPage"] = value; }
		}

		[Bindable(true),
		Category("Behavior"),
		DefaultValue(string.Empty),
		UrlProperty()]
		public virtual string Editor {
			get {
				return
					(string)ViewState["Editor"] ?? 
					string.Empty;
			}
			set { ViewState["Editor"] = value; }
		}

		[Browsable(true), DefaultValue(false), Category("Behavior")]
		public bool Panel { get; set; }

		[Bindable(true),
		Category("Behavior"),
		DefaultValue(string.Empty),
		Editor("System.Web.UI.Design.ImageUrlEditor, SystemDesign", typeof(UITypeEditor)),
		UrlProperty()]
		public virtual string EditImageUrl {
			get {
				return
					(string)ViewState["EditImageUrl"] ?? 
					Configuration.EditImageUrl ??
					"~/img/edit.png";
			}
			set { ViewState["EditImageUrl"] = value; }
		}

		[Bindable(true),
		Category("Behavior"),
		DefaultValue(string.Empty)]
		public virtual string ContentID {
			get {
				return (string)ViewState["ContentID"];
			}
			set { ViewState["ContentID"] = value; }
		}

		[Bindable(true),
		Category("Behavior"),
		DefaultValue("true")]
		public virtual bool EnableContentViewState {
			get {
				return
					(bool)(ViewState["EnableContentViewState"] ?? 
					Configuration.EnableContentViewState) && EnableViewState;
			}
			set { ViewState["EnableContentViewState"] = value; }
		}

		protected virtual string FullContentID {
			get { return ContentID ?? (Page.AppRelativeVirtualPath + "/" + ClientID); }
		}

		[Bindable(true),
		Category("Appearance"),
		DefaultValue(string.Empty)]
		public string Name {
			get {
				return (string)ViewState["Name"] ?? string.Empty;
			}
			set {
				ViewState["Name"] = value;
			}
		}

		protected override void CreateChildControls() {
			Controls.Clear();
			br.Text = "<br/>";
			button.ImageUrl = EditImageUrl;
			button.Click += EditClick;
			spacer.Text = "&nbsp; &nbsp;";
			link.Text = Name;
			link.Font.Italic = true;
			link.Click += EditClick;
			
			contentspan = new Span();
			foreach (string key in Style.Keys) {
				contentspan.Style.Add(key, Style[key]);
			}
			contentspan.Controls.Add(literal);

			WebControl p;
			if (Panel) {
				p = panel = new Panel();
			} else {
				p = span = new Span();
			}
			foreach (string key in Style.Keys) {
				p.Style.Add(key, Style[key]);
			}
			p.ID = "DynamicContent";
			p.Controls.Add(button);
			p.Controls.Add(spacer);
			p.Controls.Add(link);
			p.Controls.Add(br);
			p.Controls.Add(contentspan);
			Controls.Add(p);
		}

/*		public string GetClientCommand {
			get {
				return @"
return $('#" + contentspan.ClientID + "').
		*/
		public override ControlCollection Controls {
			get {
				EnsureChildControls();
				return base.Controls;
			}
		}

		protected override void OnInit(EventArgs e) {
			if (!Page.IsPostBack) BeginLoadFromStore();
			br.Visible = button.Visible = link.Visible = spacer.Visible = Page.Request.IsAuthenticated;
			base.OnInit(e);
			ViewState["Dummy"] = false;
			if (!Page.IsPostBack || !EnableContentViewState) {
				Loaded = false;
				BeginLoadFromStore();
			}
		}

		protected override void LoadViewState(object savedState) {
			base.LoadViewState(savedState);
			Loaded = Loaded;
			BeginLoadFromStore();
		}


		protected override object SaveViewState() {
			BeginLoadFromStore();
			link.Text = Name;
			spacer.Visible = link.Visible = (Name != string.Empty && Page.Request.IsAuthenticated);
			var editor = GetEditor();
			if (editor is IClientContentEditor) {
				var cmd = ((IClientContentEditor)editor).EditClientCommand(this);
				link.Attributes["onclick"] = cmd;
			}
			EndLoadFromStore();
			LoadedContent = LoadedContent;
			return base.SaveViewState();
		}

		private IContentEditor FindParentEditor(Control c) {
			var editor = c.Controls.OfType<IContentEditor>().FirstOrDefault();
			if (editor != null) return editor;
			if (c.Parent != null) return FindParentEditor(c.Parent);
			return null;
		}

		private IContentEditor FindMasterEditor(MasterPage p) {
			if (p is IContentEditor) return (IContentEditor)p;
			if (p.Master != null) return FindMasterEditor(p.Master);
			return null;
		}

		private IContentEditor GetEditor() {
			if (!string.IsNullOrEmpty(Editor)) {
				var ec = Page.FindControlRecursive(Editor);
				if (ec is IContentEditor) return (IContentEditor)ec;
			}
			if (Page is IContentEditor) return (IContentEditor)Page;
			var me = FindMasterEditor(Page.Master);
			if (me != null) return me;
			return FindParentEditor(Parent);
		}

		protected virtual void EditClick(object sender, EventArgs e) {
			if (!string.IsNullOrEmpty(EditPage)) {
				Page.Response.Redirect(Page.ResolveClientUrl(string.Format(EditPage, HttpUtility.UrlEncode(FullContentID), HttpUtility.UrlEncode(Page.AppRelativeVirtualPath))));
			} else {
				var editor = GetEditor();
				if (editor != null) editor.EditContent(this);
			}
		}
	
		protected virtual string LoadedContent {
			get {
				lock (this) {
					if (EnableContentViewState) {
						return (string)(ViewState["LoadedContent"] ?? string.Empty);
					} else return literal.Text;
				}
			}
			set {
				lock (this) {
					literal.Text = value;
					if (EnableContentViewState) {
						ViewState["LoadedContent"] = value;
					}
					Loaded = true;
				}
			}
		}

		Thread thread = null;
		Queue<Thread> oldThreads = new Queue<Thread>();
		protected virtual bool Loaded {
			get {
				lock (this) {
					return (bool)(ViewState["Loaded"] ?? false);
				}
			}
			set {
				lock (this) {
					if (!value) {
						if (thread != null) oldThreads.Enqueue(thread);
						thread.Abort();
						thread = null;
					}
					ViewState["Loaded"] = value;
				}
			}
		}

		protected virtual void BeginLoadFromStore() {
			if (!Loaded && thread == null) {
				thread = new Thread(new ThreadStart(DoLoadFromStore));
				thread.Name = "DynamicContent.LoadFromStore";
				thread.Start();
			}
		}

		void DoLoadFromStore() {
			try {
				LoadFromStore();
			} catch (ThreadAbortException) {
			} catch (Exception ex) {
				Log.Error(string.Format("Fehler beim Lesen des dynamischen Inhalts von {0} aus der Datenbank.", ContentID), ex);
				LoadedContent = "Fehler beim Lesen des dynamischen Inhalts aus der Datenbank.";
			} finally {
				Loaded = true;
			}
		}

		protected virtual void LoadFromStore() {
			using (var db = new DB()) {
				Pagecontent content = db.ThisPagecontent(FullContentID);
				if (content != null) LoadedContent = content.Text;
			}
		}

		void DoSaveToStore() {
			try {
				SaveToStore();
			} catch (Exception ex) {
				Log.Error(string.Format("Fehler beim Schreiben des dynamischen Inhalts von {0} in die Datenbank.", ContentID), ex);
			}
		}

		protected virtual void SaveToStore() {
			using (var db = new DB()) {
				Pagecontent content = db.ThisPagecontent(FullContentID);
				if (content == null) {
					content = new Pagecontent { Url = FullContentID, Text = LoadedContent ?? string.Empty };
					db.AddToPagecontents(content);
				} else {
					content.Text = LoadedContent ?? string.Empty;
				}
				db.SaveChanges();
			}
		}

		protected virtual void EndLoadFromStore() {
			if (!Loaded && thread != null) {
				Timers.Start("Load Content from Store");
				thread.Join();
				Timers.Stop("Load Content from Store");
				thread = null;
			}
			Loaded = true;
		}

		public virtual void ReloadFromStore() {
			Loaded = false;
			BeginLoadFromStore();
		}

		public virtual string Content {
			get {
				EndLoadFromStore();
				return LoadedContent;
			}
			set {
				if (thread != null) thread.Abort();
				LoadedContent = value ?? string.Empty;
				DoSaveToStore();
			}
		}

		protected override void OnUnload(EventArgs e) {
			while (oldThreads.Count > 0) {
				oldThreads.Dequeue().Join();
			}
			base.OnUnload(e);
		}
	}

}
