﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Silversite.cs.Obsolete {

	/*
	class EntityDataService {
	
		public static void Backup<E>(Stream stream, EntityContext c) where E: IEntity {
			var q = c.Query<E>();
			var f = new BinaryFormatter();
			var t = typeof(E);
			if (!t.IsInterface) throw new NotSupportedException();
			foreach (E e in q) {
				stream.WriteByte(1);
				foreach (var p in t.GetProperties()) {
					var val = p.GetValue(e, new object[0]);
					f.Serialize(stream, p.GetValue(e, new object[0]));
				}
			}
			stream.WriteByte(0);
		}

		public static void Restore<E>(Stream stream, EntityContext c, Func<E> New) where E: IEntity {
			var q = c.Query<E>();
			foreach (E e in q) c.Remove(e);

			var f = new BinaryFormatter();
			var t = typeof(E);
			if (!t.IsInterface) throw new NotSupportedException();
			while (stream.ReadByte() != 0) {
				var e = New();
				foreach (var p in t.GetProperties()) {
					p.SetValue(e, f.Deserialize(stream), new object[0]);
				}
				c.Add(e);
			}
		}
	}

	public class EntityService<T>: Service, IDataService
		where T: EntityService<T>, new() {

		public EntityProvider<T> EntityProvider { get { return (EntityProvider<T>)Provider; } }

		public EntityContext NewContext() { return (EntityContext)EntityProvider.NewContext(); }
		public E New<E>() where E: IEntity { return EntityProvider.New<E>(); }

		public virtual void Backup<E>(Stream stream) where E: IEntity {
			using (var c = NewContext()) {
				EntityDataService.Backup<E>(stream, c);
			}
		}

		public virtual void Restore<E>(Stream stream) where E: IEntity {
			using (var c = NewContext()) {
				EntityDataService.Restore<E>(stream, c, New<E>);
			}
		}

		public virtual void Backup(Stream stream) { }
		public virtual void Restore(Stream stream) { }
	}

	public class StaticEntityService<T>: StaticService<T>, IDataService
		where T: StaticEntityService<T>, new() {

		public new static EntityProvider<T> Provider { get { return (EntityProvider<T>)StaticService<T>.Provider; } }
		public static EntityContext NewContext() { return (EntityContext)Provider.NewContext(); }
		public static E New<E>() where E: IEntity { return Provider.New<E>(); }

		public virtual void Backup<E>(Stream stream) where E: IEntity {
			using (var c = NewContext()) {
				EntityDataService.Backup<E>(stream, c);
			}
		}

		public virtual void Restore<E>(Stream stream) where E: IEntity {
			using (var c = NewContext()) {
				EntityDataService.Restore<E>(stream, c, New<E>);
			}
		}
		public virtual void Backup(Stream stream) { }
		public virtual void Restore(Stream stream) { }
	}

	*/
}