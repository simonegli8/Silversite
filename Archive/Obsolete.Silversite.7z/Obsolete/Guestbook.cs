﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using Silversite;
using Services = Silversite.Services;
using System.ComponentModel.DataAnnotations;

namespace johnshope.david {

	public class GuestbookMessage {
		[Key]
		public long Key { get; set; }
		public string Name { get; set; }
		public string Message { get; set; }
		public string Image { get; set; }
	}

	public class Guestbook {

		public class Context: Services.Database.Context {
			public Context() : base() { }
			public Context(System.Data.Common.DbConnection db) : base(db) { }
			//public DbSet<GuestbookMessage> GbMessages { get { return GuestbookMessages; } }
		}

		public void Post(string name, string message, string image) {
			using (var c = new Context()) {
				c.GbMessages.Add(new GuestbookMessage { Name = name, Message = message, Image = image });
			}
		}

	}
}