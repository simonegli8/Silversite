﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Silversite.Services {
	public class Home {

		public static Uri Uri { get { return new Uri(Url); } }

		public static string Url {
			get {
				try {
					var request = HttpContext.Current.Request;
					string home = request.Url.AbsoluteUri, app = request.ApplicationPath;
					if (app.StartsWith("~")) app = app.Substring(1);
					if (app != "/") {
						home = home.Substring(0, home.IndexOf(app)) + app;
					} else {
						home = request.Url.Scheme + "://" + request.Url.Authority;
					}
					return home;
				} catch { return null; }
			}
		}
		 
	}
}
