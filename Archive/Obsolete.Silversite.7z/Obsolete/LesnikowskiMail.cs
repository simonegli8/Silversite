﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using Lesnikowski.Client;
using Lesnikowski.Mail;
using Lesnikowski.Mail.Headers;
using Lesnikowski.Mail.Headers.Constants;
using System.Net;
using System.Web.Configuration;
using System.Collections.Generic;
using System.Text;

namespace Silversite.Web {

	public class MailAddress: MailBox {
		public MailAddress(string address, string name) : base(address, name) { }
		public MailAddress(string address) : base(address, address) { }
	}

	public class MailConfiguration: Configuration.ConfigurationSection {

		[ConfigurationProperty("PopServer", IsRequired=false)]
		public string PopServer { get { return (string)this["PopServer"]; } set { this["PopServer"] = value; } }

		[ConfigurationProperty("PopPort", IsRequired=false, DefaultValue=110)]
		public int PopPort { get { return (int)(this["PopPort"] ?? 110); } set { this["PopPort"] = value; } }

		[ConfigurationProperty("PopUsername", IsRequired=false)]
		public string PopUsername { get { return (string)this["PopUsername"]; } set { this["PopUsername"] = value; } }

		[ConfigurationProperty("PopPassword", IsRequired=false)]
		public string PopPassword { get { return (string)this["PopPassword"]; } set { this["PopPassword"] = value; } }

		[ConfigurationProperty("SmtpServer", IsRequired=false)]
		public string SmtpServer { get { return (string)this["SmtpServer"]; } set { this["SmtpServer"] = value; } }

		[ConfigurationProperty("SmtpPort", IsRequired=false, DefaultValue=25)]
		public int SmtpPort { get { return (int)(this["SmtpPort"] ?? 110); } set { this["SmtpPort"] = value; } }

		[ConfigurationProperty("SmtpUsername", IsRequired=false)]
		public string SmtpUsername { get { return (string)this["SmtpUsername"]; } set { this["SmtpUsername"] = value; } }

		[ConfigurationProperty("SmtpPassword", IsRequired=false)]
		public string SmtpPassword { get { return (string)this["SmtpPassword"]; } set { this["SmtpPassword"] = value; } }

		[ConfigurationProperty("OwnerEmail", IsRequired=false)]
		public string OwnerEmail { get { return (string)this["OwnerEmail"]; } set { this["OwnerEmail"] = value; } }

		[ConfigurationProperty("OwnerName", IsRequired=false)]
		public string OwnerName { get { return (string)this["OwnerName"]; } set { this["OwnerName"] = value; } }

		[ConfigurationProperty("AdminEmail", IsRequired=false)]
		public string AdminEmail { get { return (string)this["AdminEmail"]; } set { this["AdminEmail"] = value; } }

		[ConfigurationProperty("AdminName", IsRequired=false)]
		public string AdminName { get { return (string)this["AdminName"]; } set { this["AdminName"] = value; } }

		[ConfigurationProperty("TestNewsletter", IsRequired=false, DefaultValue=false)]
		public bool TestNewsletter { get { return (bool)this["TestNewsletter"]; } set { this["TestNewsletter"] = value; } }

		private MailBox ownerAddress = null;
		public MailBox OwnerAddress {
			get { return ownerAddress ?? new MailBox(OwnerEmail, OwnerName); }
		}

		private MailBox adminAddress = null;
		public MailBox AdminAddress {
			get { return adminAddress ?? new MailBox(AdminEmail, AdminName); }
		}

		public virtual void CopyFrom(MailConfiguration config) {
			base.CopyFrom(config);
			ownerAddress = null;
			adminAddress = null;
		}

	}
	
	/// <summary>
	/// A class that implements sending of mails.
	/// </summary>

	public class Attachment {

		public enum Classes { MimeData, File, Buffer };

		MimeData mimeData;
		string filename;
		byte[] buffer;

		public Classes Class; 

		public Attachment(string filename) {
			Class = Classes.File;
			this.filename = filename;
		}

		public Attachment(MimeData data) {
			Class = Classes.MimeData;
			mimeData = data;
		}

		public Attachment(byte[] buf) {
			Class = Classes.Buffer;
			buffer = buf;
		}

		public void AddToAttachments(SimpleMailMessageBuilder builder) {
			switch (Class) {
			case Classes.MimeData: builder.AddAttachment(mimeData); break;
			case Classes.File: builder.AddAttachment(filename); break;
			case Classes.Buffer: builder.AddAttachment(buffer); break;
			default: break;
			}
		}

		public void AddToVisuals(SimpleMailMessageBuilder builder) {
			switch (Class) {
			case Classes.MimeData: builder.AddVisual(mimeData); break;
			case Classes.File: builder.AddVisual(filename); break;
			case Classes.Buffer: builder.AddVisual(buffer); break;
			default: break;
			}
		}
	}

	public class Mail {

		public static MailConfiguration Configuration = new MailConfiguration();

		private string eml = null;
		public string Eml {
			get {
				if (eml == null) eml = Message.GetSmtpData();
				return eml;
			}
			set {
				eml = value;
			}
		}

		private ISimpleMailMessage msg = null;
		public ISimpleMailMessage Message {
			get {
				if (msg == null) {
					if (eml == null) {
						msg = Builder.Create();
					} else {
						msg = new SimpleMailMessageBuilder().CreateFromEml(eml);
					}
				}
				return msg;
			}
		}

		public List<MailBox> Bcc = new List<MailBox>(), Cc = new List<MailBox>(), From = new List<MailBox>(), To = new List<MailBox>(), ReplyTo = new List<MailBox>(), NotificationTo = new List<MailBox>();
		public MailBox Sender;
		public MimePriority? Priority;
		public DateTime? Date;
		public MimeImportance? Importance;
		public string MessageID, Subject;
		public List<Attachment> Attachments = new List<Attachment>(), Visuals = new List<Attachment>();
		public string Html, Text, InReplyTo;

		public bool IsHtml { get { return !string.IsNullOrEmpty(Html); } }

		public void ParseMessage() {
			Bcc.Clear();
			Bcc.AddRange(Message.Bcc);
			Cc.Clear();
			Cc.AddRange(Message.Cc);
			Date = Message.Date;
			From.Clear();
			From.AddRange(Message.From);
			Importance = Message.Importance;
			InReplyTo = Message.InReplyTo;
			MessageID = Message.MessageID;
			NotificationTo.Clear();
			NotificationTo.AddRange(Message.NotificationTo);
			Priority = Message.Priority;
			ReplyTo.Clear();
			ReplyTo.AddRange(Message.ReplyTo);
			Sender = Message.Sender;
			Subject = Message.Subject;
			To.Clear();
			To.AddRange(Message.To);
			Attachments.Clear();
			foreach (var at in Message.Attachments)  Attachments.Add(new Attachment(at));
			Visuals.Clear();
			foreach (var visual in Message.Visuals) Visuals.Add(new Attachment(visual));

			Html = Message.HtmlDataString;
			Text = Message.TextDataString;
		}

		public SimpleMailMessageBuilder Builder {
			get {
				SimpleMailMessageBuilder builder = new SimpleMailMessageBuilder();
				builder.Bcc.AddRange(Bcc);
				builder.Cc.AddRange(Cc);
				builder.Date = Date;
				builder.From.AddRange(From);
				builder.Importance = Importance;
				builder.InReplyTo = InReplyTo;
				builder.MessageID = MessageID;
				builder.NotificationTo.AddRange(NotificationTo);
				builder.Priority = Priority;
				builder.ReplyTo.AddRange(ReplyTo);
				builder.Sender = Sender;
				builder.Subject = Subject;
				builder.To.AddRange(To);
				foreach (var at in Attachments) at.AddToAttachments(builder);
				foreach (var vs in Visuals) vs.AddToVisuals(builder);
				builder.SetHtmlData(Html);
				builder.SetTextData(Text);
				return builder;
			}
		}

		public void Rebuild() { msg = null; eml = null; }

		/// <summary>
		/// The default constructor.
		/// </summary>
		public Mail() {
			From.Add(Configuration.OwnerAddress);
			ReplyTo.Add(Configuration.OwnerAddress);
			Sender = Configuration.OwnerAddress;
		}

		/// <summary>
		/// Creates a new mail.
		/// </summary>
		public Mail(string subject, string body): this() {
			Html = body;
			Text = string.Empty;
			Subject = subject;
		}

		/// <summary>
		/// Creates a new mail.
		/// </summary>
		public Mail(string eml): this() {
			Eml = eml;
			ParseMessage();
		}

		/// <summary>
		/// Creates a new mail.
		/// </summary>
		public Mail(string subject, string body, MailBox to): this(subject, body) {
			To.Add(to);
		}

		public Mail(Mail mail) {
			Eml = mail.eml;
			msg = mail.Message;
			ParseMessage();
		}

		/*
		public string FromKunde {
			set {
				Kunde kunde = Kunde.Find(value);
				if (kunde != null) From = kunde.MailAddress;
				else if (value.Contains("@")) From = new MailAddress(value);
				else From = new MailAddress(OwnerEmail, value);
			}
		}
		*/

		public Exception Exception = null;

		public class SmtpServer: Smtp, IDisposable {

			public SmtpServer() {
				try {
					User = Configuration.SmtpUsername;
					Password = Configuration.SmtpPassword;
					Connect(Configuration.SmtpServer);        // Connect to the server   
					Ehlo(HeloType.EhloHelo, Configuration.OwnerName); // Say hello    
					Login();
				} catch (Exception ex) {
					Services.Log.Error("Fehler beim Verbinden mit SMTP Server.", ex);
				}
			}

			public bool Test { get; set; }
		}

		public class Pop3Server: Pop3, IDisposable {

			public Pop3Server() {
				User = Configuration.PopUsername;
				Password = Configuration.PopPassword;

				Connect(Configuration.PopServer);
				Login();
 
				GetAccountStat();   
			}

		}

		public bool Send(SmtpServer smtp) {
			try {
				smtp.SendMessage(Message);                 // Send   
			} catch (Exception ex) {
				Exception = ex;
				Services.Log.Error("Fehler beim senden von Email:", ex);
				return false;
			}
			return true;
		}

		public bool Send() {
			using (var smtp = new SmtpServer()) return Send(smtp);
		}

		public static List<Mail> Pop() {
			var list = new List<Mail>();
			using (var pop = new Pop3Server()) {
				for (int i = 1; i <= pop.MessageCount; i++) {
					try {
						list.Add(new Mail(pop.GetMessage(i)));
						pop.DeleteMessage(i);
					} catch (Exception ex) {
						Services.Log.Error("Fehler beim lesen der Emails.", ex);
					}
				}
			}
			return list;
		}

	}
}
