﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Silversite.LightDb {

	public enum LdbFormats { Text, Raw, Compressed };

	public abstract class TableName {
		public abstract LdbTable<T, K> Table<T, K>() { get; }
	}

	public abstract class LdbKey {
		public abstract string Name { get; }
		public abstract int Index { set; }
	}

	public abstract class IntDbKey {
		public abstract int File { get; set; }
		public string Name { get { return File.ToString("X8"); } }
	}

	public abstract class DateDbKey {
		public abstract Date Date { get; set; }
		public string Name { get { return HttpUtility.UrlEncode(Date.ToShortDateStringString(CulutreInfo.InvariantCulture)); } }
	}

}
