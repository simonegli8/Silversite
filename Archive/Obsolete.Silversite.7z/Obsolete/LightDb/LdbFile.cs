﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Silversite.LightDb {

	public class LdbFile<T, K, F>: F where K: LdbKey, F: Stream {
	
		public class ZipStream: DeflateStream {
			long position = 0;
			DeflateStream dest = null;
			public ZipStream(Stream d): base(d, CompressionLevel.Optimal, true) { }
			public override long Position { get { return position; } set { throw NotSupportedException(); } } 
			public override void Write(byte[] array, int offset, int count) { (dest ?? base).Write(array, offset, count); position += count; }
			public override void WriteByte(byte value) { (dest ?? base).WriteByte(value); position++; }
			public override Task WriteAsync(byte[] buffer, int offset, int count, System.Threading.CancellationToken cancellationToken) { return (dest ?? base).WriteAsync(buffer, offset, count, cancellationToken); position += count; }
			public void Seek(long pos) {
				if (pos != 0) throw new NotSupportedException();
				if (position != 0) {
					BaseStream.Seek(0, SeekOrigin.Begin);
					dest = new DeflateStream(BaseStream, CompressionLevel.Optimal, true);
					position = 0;
				}
			}
		}

		public class UnzipStream: DeflateStream {
			const int M = 4096;
			long position = 0;
			DeflateStream src;
			static buf = new byte[M];
			public override long Position { get { return position; } set { throw NotSupportedException(); } } 
			public UnzipStream(Stream src): base(src, CompressionMode.Decompress, true) { }
			public override int Read(byte[] array, int offset, int count) { (src ?? base).Read(array, offset, count); position += count; }
			public override int ReadByte() { position++; return (src ?? base).ReadByte(); }
			public override Task<int> ReadAsync(byte[] buffer, int offset, int count, System.Threading.CancellationToken cancellationToken) { position += count; return (src ?? base).ReadAsync(buffer, offset, count, cancellationToken); }
			public long Seek(long offset) {
				if (offset < position) { position = 0; BaseStream.Seek(0, SeekOrigin.Begin); src = new DeflateStream(BaseStream, CompressionMode.Decompress, true); }
				while (offset > position) Read(buf, 0, Math.Max(M, offset - position));
			}
		}

		long DateLength;
		Dictionary<int, long> Index = null;
		LightDb<T, K> db = null; 
		bool RefreshIndex = false;
		bool IsTemp = false;
		DbFile<T, K> Temp == null;
		string name = null;
		bool CanAppend;
		Stream Write;
		Stream Read;
		public double TruncateTreshold { get; set; }

		public LdbFile(LightDb<T> db, string name, FileMode mode): base(Paths.Map(Paths.Combine(db.Path, name)), mode, FileAccess.ReadWrite) { Init(db); this.db = db; ReadIndex(); }
		public LdbFile(LightDb<T> db, LdbKey key, FileMode mode): this(db, key.Name, mode) { }
		public LdbFile(DbFile source): base(Paths.Map(Paths.Combine(db.Path, key.Name + ".tmp")), FileMode.Create, FileAccess.ReadWrite) { IsTemp = true; this.db = db; ReadIndex(); }
		public void Init(DbFile db) {
			TruncateTreshold = 0.7;
			this.db = db;
			ReadIndex();
			if (Format == Formats.Compressed) {
				Write = new ZipStream(this);
				Read = new UnzipStream(this);
			} else { Write = this; Read = this; }
		}

		public bool HasIndex { get { return db.Format >= Formats.Binary; } }
		public void Seek(long pos) {
			if (Format == Formats.Compressed) {
				if (pos == 0) Write.Seek(0);
				Read.Seek(pos);
			} else {
				Seek(pos, SeekOrigin.Begin);
			}
		}

		public ReadIndex() {
			if (HasIndex) {
				Index = new Dictionary<int,long>();
 				if (Length > 0) {
					Seek(-8, SeekOrigin.End);
					DataLength = r.ReadInt64();
					Seek(DataLength, SeekOrigin.Begin);
					while (Position < Length - 8) index.Add(r.ReadInt32(), r.ReadInt64());
				} else DataLength = 0;
			} else {
				DataLength = Length;
			}
		}
		public WriteIndex() {
			if (HasIndex) {
				Seek(DataLength, SeekOrigin.Begin);
				using (var w = new BinaryWriter(this)) {
					index.Keys.Each(x => { w.Write(x); w.Write(index[x]); });
				}
			}
		}

		public IEnumerable<T> All() {
			Seek(0);
			while (Position < DataLength) yield return db.Deserialize(Read);
		}

		public T This(LdbKey key) {
			if (HasIndex) {
				if (Index.ContainsKey(key.Index)) {
					Seek(Index[key.Index]);
					return db.Deserialize(Read);
				} else return null;
			} else return This(item => db.Key(item).Index == key.Index);
		}
		public T This(Func<T, bool> where) { return All().FirstOrDefault(item => where(item)); }

		public void CopyTo(LdbFile dest, Func<T, bool> filter = null) {
			dest.Add(All().Where(item => filter == null || filter(item));
			Close();
		}

		public void Add(IEnumerable<T> items) {
			if (Temp != null) Temp.Add(items);
			else if (db.CanAppend || Length == 0) {
				Seek(DataLength);
				items.Each(item => {
					db.Serialize(item, Write);
					if (Position > DataLength) DataLength = Position;
				});
			} else {
				if (Temp == null) {
					CopyTo(Temp = new DbFile(this));
				}
				Temp.Add(items);
			}
		}
		public void Add(params T[] items) { Add(items); }

		public void Remove(LdbKey key) {
			if (Temp != null) Temp.Remove(key);
			else if (key.Name == name && Index.ContainsKey(key.Index)) {
				Index[key.Index = -1];
				if (Index.Count == 0) { Close(); File.Delete(Name); }
				if (Index.Count > 100 && (Index.Count(index == -1) > Index.Count*(1-TruncateTreshold)) { // Truncate (more than TruncateTreshold% items have been deleted)
					CopyTo(Temp = new DbFile(this), item => db.Key(item).Index != key.Index);
				}
			}
		}
		public void Remove(Func<T, bool> where) {
			if (Temp == null) Temp = new DbFile(this);
			else CopyTo(Temp = new DbFile(this), item => !where(item));
		}

		public void Clear() { Close(); File.Delete(Name); }

		public override void Close() {
			WriteIndex();
			base.Close();
			if (IsTemp) Files.Move(Name, Paths.WithoutExtension(Name));
		}
	}
}
