﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.IO.Compression;
using System.Globalization;
using System.Web;
using System.Collections.ObjectModel;
using System.Threading.Tasks;

namespace Silversite.LightDb {

	public class LdbSegmentedSet<T, K> where K: LdbKey {

		public enum Formats { Text, Html, Xml, Binary, Compressed };
		public string Path { get; set; }
		public Formats Format { get; set; }
		public string Extension { get { return Mode == Formats.Text ? ".txt" :Formats Mode == Formats.Html ? ".html" : "db.img"; } }
		public Func<T, LdbKey> Key { get; set; }

		public LightDb(string path) { Path = path; Key = key; }

		public virtual FileStream File(Key key, FileMode mode) { return new FileStream(Paths.Map(Paths.Combine(Path, key.Name)), mode, FileAccess.ReadWrite); }
	
		void Serialize(T item, DbFile file) {
			file.AddIndex(item);
			Serialize(item, file);
		}

		public virtual void Serialize(T item, Stream s) {
		}
		public virtual T Deserialize(Stream s, LdbKey key = null) {
		}
		public virtual void WriteIndex(T item, Stream s) {
			if (Format >= Formats.Binary) {
				using (var w = new BinaryWriter(s)) w.Write(index);
			}
		}

		public virtual bool CanAppend { get { return Mode != Modes.Compress; } }

		void AddRaw(IEnumerable<T> items) {
			var files = items.GroupBy(item => Key(item).Name);
			files.Each(itemsbyfile => {
				using (var dbfile = new DbFile<T, K>(this, file.Key, FileMode.OpenOrCreate)) {
					dbfile.Add(itemsbyfile);
				}
			});
		}
		public virtual void Add(IEnumerable<T> items) {
			try {
				lock (this) AddRaw(items);
			} catch {
				if (!Files.DirectoryExists(Path)) Files.CreateDirectory(Path);
				lock (this) AddRaw(items);
			}
		}
		public void Add(params T[] items) { Add((IEnumerable<T>)items); }

		public void Remove(Func<T, bool> where) {
			Files.All(Paths.Combine(Path, "*" + Extension))
				.Each(file => {
					using (var src = File(Key(items), FileMode.OpenOrCreate))
					using (var tmp = new TempFile(src)) {
						while (src.Position < src.Lenght) Serialize(Deserialize(src), tmp);
						Add(tmp, items);
					}
				});
		}
	
		public void Clear() { Files.Delete(Path); }

		public virtual T This(LdbKey key) {
			try {
				using (var src = File(key, FileMode.Open)) return Deserialize(src);
					while (Key(item).Index != key.Index

		}

		public virtual IEnumerable<T> AllDescending() {
		}

		public virtual IEnumerable<T> AllAscending() {
		}
	}
}
