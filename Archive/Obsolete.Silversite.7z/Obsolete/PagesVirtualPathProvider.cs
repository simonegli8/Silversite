﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Reflection;
using System.Security.Permissions;
using System.Text;
using System.IO;
using System.Web.Hosting;
using System.Configuration;

namespace Silversite.Web {

	public class PagesVirtualPathProvider: VirtualPathProvider, IHttpAutostartModule {

		public const string RootPath = "~/silversite/pages";

		public override string CombineVirtualPaths(string basePath, string relativePath) {
			// If the path is relative, let normal processing happen 
      if (!VirtualPathUtility.IsAbsolute(relativePath)) 
				return base.CombineVirtualPaths(basePath, relativePath); 
         
      string authority = HttpUtility.UrlEncode(HttpContext.Current.Request.Url.Authority); 
				
 			var localPath = VirtualPathUtility.ToAppRelative(relativePath).Substring(1);

			string path;
			path = RootPath + "/" + authority + localPath;
			if (File.Exists(HostingEnvironment.MapPath(path))) return path;

			path = RootPath + localPath;
			if (File.Exists(HostingEnvironment.MapPath(path))) return path;
			
			return base.CombineVirtualPaths(basePath, relativePath);
		}

		public void Dispose() { }

		public void Init(HttpApplication context) {
			HostingEnvironment.RegisterVirtualPathProvider(new PagesVirtualPathProvider());
		}
	}
}