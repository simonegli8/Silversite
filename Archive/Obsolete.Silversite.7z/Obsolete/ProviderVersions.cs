﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using System.ComponentModel.DataAnnotations;

namespace Silversite.Services {

	public class ProviderVersions: StaticEntityService<ProviderVersions> {
	
		public class Version {
			[Key]
			string Assembly { get; set; }
			string VersionString { get; set; }
			Version Version { get; set; }
			bool IsInstalledVersion { get; set; }
		}

		public static string AssemblyName(IVersionedProvider provider) {
			return provider.GetType().Assembly.GetName().Name;
		}

		public static IQueryable<IEntity> Versions(string assembly) {
			using (var c = NewContext()) {
				return c.Query<IEntity>().Where(w => w.Assembly == assembly).ToArray().AsQueryable();
			}
		}
		public static IQueryable<IEntity> Versions(IVersionedProvider provider) { return Versions(AssemblyName(provider)); }

		public static int VersionsCount(IVersionedProvider provider) { return Versions(provider).Count(); }
		public static int VersionsCount(string assembly) { return Versions(assembly).Count(); }


		public static Version StoreVersion(string assembly) {
			using (var c = NewContext()) {
				try {
					var v = c.Query<IEntity>().FirstOrDefault(w => w.Assembly == assembly && w.IsInstalledVersion);
					if (v != null) return Version.Parse(v.VersionString);
				} catch (Exception) { }
				return new Version(0, 0);
			}
		}
		public static Version StoreVersion(IVersionedProvider provider) { return StoreVersion(AssemblyName(provider)); }

		public static Version CodeVersion(IVersionedProvider provider) {
			return provider.GetType().Assembly.GetName().Version;
		}
		public static Version CodeVersion(string assembly) {
			var a = AppDomain.CurrentDomain.GetAssemblies().FirstOrDefault(b => b.GetName().Name == assembly);
			if (a == null) return new Version(0, 0);
			return a.GetName().Version;
		}


		public static IQueryable<IEntity> All() {
			using (var c = NewContext()) {
				return c.Query<IEntity>().Where(e => e.IsInstalledVersion).ToArray().AsQueryable();
			}
		}
		
		public static int Count() { 
			return All().Count();
		}

		public static void ChangeVersion(IVersionedProvider provider, Version version) { ChangeVersion(AssemblyName(provider), version); }
		public static void ChangeVersion(string assembly, Version version) {
	
			using (var c = NewContext()) {
				IEntity oldv;
				try {
					oldv = c.Query<IEntity>().FirstOrDefault(w => w.Assembly == assembly && w.IsInstalledVersion);
					if (oldv == null) {
						oldv = New<IEntity>();
						oldv.VersionString = "0.0.0.0";
					}
				} catch {
					oldv = New<IEntity>();
					oldv.VersionString = "0.0.0.0";
				}
				try {
					if (oldv != null && oldv.Version != version) {
						var ps = Providers.Registered.Where(p => p is IVersionedProvider && p.GetType().Assembly.GetName().Name == assembly).OfType<IVersionedProvider>();
						foreach (var provider in ps) {
							provider.ChangeVersion(version);
						}
						oldv.IsInstalledVersion = false;
						var vs = version.ToString();
						var v = c.Query<IEntity>().FirstOrDefault(w => w.Assembly == assembly && w.VersionString == vs);
						if (v == null) {
							v = New<IEntity>();
							v.Assembly = assembly;
							v.VersionString = version.ToString();
							v.IsInstalledVersion = true;
							c.Add(v);
						} else {
							v.IsInstalledVersion = true;
						}
					}
				} catch { }
			}
		}

		public static void ChangeVersionData(string assembly, Version version) {

			using (var c = NewContext()) {
				IEntity oldv;
				try {
					oldv = c.Query<IEntity>().FirstOrDefault(w => w.Assembly == assembly && w.IsInstalledVersion);
					if (oldv == null) {
						oldv = New<IEntity>();
						oldv.VersionString = "0.0.0.0";
					}
				} catch {
					oldv = New<IEntity>();
					oldv.VersionString = "0.0.0.0";
				}
				try {
					if (oldv != null && oldv.Version != version) {
						oldv.IsInstalledVersion = false;
						var vs = version.ToString();
						var v = c.Query<IEntity>().FirstOrDefault(w => w.Assembly == assembly && w.VersionString == vs);
						if (v == null) {
							v = New<IEntity>();
							v.Assembly = assembly;
							v.VersionString = version.ToString();
							v.IsInstalledVersion = true;
							c.Add(v);
						} else {
							v.IsInstalledVersion = true;
						}
					}
				} catch { }
			}
		}

		public class ChangeVersionThread: IAsyncResult {
			public string Assembly { get; set; }
			public Version Version { get; set; }
			public AsyncCallback UserCallback {get; set; }	
			public object  AsyncState { get; set; }
			System.Threading.AutoResetEvent signal = new System.Threading.AutoResetEvent(false);
			public System.Threading.WaitHandle  AsyncWaitHandle { get { return signal; } }
			public bool  CompletedSynchronously { get { return false; } }
			public bool  IsCompleted { get; protected set; }
			
			public ChangeVersionThread() { IsCompleted = false; }

			public void Start(object par) {
				ProviderVersions.ChangeVersion(Assembly, Version);
				IsCompleted = true;
				signal.Set();
				if (UserCallback != null) UserCallback(this);
			}
		}

		public static IAsyncResult BeginChangeVersion(string assembly, Version version, AsyncCallback userCallback, object stateObject) {
			var thread = new ChangeVersionThread();
			thread.Assembly = assembly;
			thread.Version = version;
			thread.UserCallback = userCallback;
			thread.AsyncState = stateObject;

			System.Threading.ThreadPool.QueueUserWorkItem(new System.Threading.WaitCallback(thread.Start));
			return thread;
		}

		public static void EndChangeVersion(IAsyncResult result) {
			result.AsyncWaitHandle.WaitOne();
		}

	}
}