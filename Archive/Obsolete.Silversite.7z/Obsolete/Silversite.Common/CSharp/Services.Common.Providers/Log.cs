﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Threading;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text.RegularExpressions;

namespace Silversite.Services.Providers {

	/// <summary>Returns all log entries ordered after Date in descending order.</summary>
	public abstract class LogDbProvider: Services.Provider<LogProvider> {
		public override IEnumerable<LogMessage> All() {
			using (var db = new Silversite.Context()) {
				foreach (var log in db.LogMessages()) {
					db.Detach(log);
					yield return log;
				}
			}
		}
		/// <summary>Returns a specific log entry.</summary>
		public override LogMessage This(long key) {
			using (var db = new Silversite.Context()) {
				return db.LogMessages.
			}
		}
		/// <summary>Writes a message to the custom log.</summary>
		/// <param name="msg">The message to log.</param>
		public override void Message(LogMessage msg) {
			using (var db = new Silversite.Context()) {
				db.LogMessages.Add(msg);
				db.SaveChanges();
			}
		}
		/// <summary>Deletes old entries.</summary>
		public override void Cleanup() {
			using (var db = new Silversite.Context()) {
				var olddate = DateTime.Now - Services.Log.Configuration.DaysToArchive.Days();
				var old = db.LogMessages.Where(log => log.Date < olddate);
				db.LogMessages.Delete(old);
			}
		}
		/// <summary>Clears the entire log.</summary>
		public override void Clear() {
			using (var db = new Silversite.Context()) {
				db.LogMessages.Delete(db.LogMessages);
			}
		}
		/// <summary>Clears a log category.</summary>
		/// <param name="category">The log category.</param>
		public override void Clear(string category) {
			using (var db = new Silversite.Context()) {
				db.LogMessages.Delete(db.LogMessages.Where(log => log.Category == category));
			}
		}

		override bool  
	
	}

}
