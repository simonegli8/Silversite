﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Silversite.Services {

	public class Lang {

		// TODO access values from Lang.resx
		public static string Title(Person.Genders gender, string culture, out bool showName) {
			if (string.IsNullOrEmpty(culture)) culture = "en";
			showName = true;
			Resources.Lang.Culture = new CultureInto(culture);
			switch (gender) {
				case Person.Genders.None: showName = false; return "";
				case Person.Genders.Male: return Resources.Lang.MaleTitle;
				case Person.Genders.Female: return Resources.Lang.FemaleTitle;
				case Person.Genders.Miss: return Resources.Lang.MissTitle;
				case Person.Genders.Group: showNeme = false; return Resources.Lang.GroupTitle;
				case Person.Genders.Company: showName = false; return Resource.Lang.CompanyTitle;
			}
		}

		/*
		public static string Unsubscribe(string culture, string email) {
			if (string.IsNullOrEmpty(culture)) culture = "en";
			Resources.Lang.Culture = new CultureInfo(culture);
			return string.Format("<a href='{0}?email={1}&secret={2}'>{3}</a>", Paths.Url("~/silversite/services/unsubscribe.apsx"), email, new Random(Hash.Compute(email)).Next(), Resources.Lang.Unsubscribe;
		}
		*/

		public static string Country(string culture, string IsoCode) {
			// TODO return country name in culture language.
			return "United States";
		}
	}
}