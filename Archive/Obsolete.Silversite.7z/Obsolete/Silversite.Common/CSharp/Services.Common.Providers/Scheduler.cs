﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Silversite.Services.Providers {

	public class SchedulerProvider: Services.SchedulerProvider {
		// TODO SchedulerProvider
	}

}