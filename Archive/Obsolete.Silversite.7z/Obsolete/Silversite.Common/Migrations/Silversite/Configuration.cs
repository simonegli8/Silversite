namespace Silversite.Migrations.Silversite {

    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<Data.MigrationContext<Context>> {

        public Configuration() {
            AutomaticMigrationsEnabled = false;
			MigrationsNamespace = "Silversite.Migrations.Silversite";
			MigrationsDirectory = "Migrations\\Silversite";
        }

    }
}
