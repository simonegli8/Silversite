namespace Silversite.Migrations.WebCrawler {

    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<Data.MigrationContext<Services.WebCrawlerContext>> {

        public Configuration() {
            AutomaticMigrationsEnabled = false;
			MigrationsNamespace = "Silversite.Migrations.WebCrawler";
			MigrationsDirectory = "Migrations\\WebCrawler";
        }

    }
}
