﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Data.Common;
using System.Data.Objects;
using System.Data.Objects.DataClasses;
using System.IO;
using System.Web;
using Silversite;
using Silversite.Services;

namespace Silversite.Services {

	public class ErrorArgs: EventArgs {
		public Exception Exception { get; set; }
		public string Message { get; set; }
	}

	public delegate void ErrorHandler(object sender, ErrorArgs args);

	public class SqlEntityProvider<T, C>: EntityProvider<T>
		where C: SqlEntityContext, new() {

		public override EntityContext NewContext() { var c = new C(); c.Provider = this; return c; }
		
		// versioning support
		public override Version StoreVersion { get { return ProviderVersions.StoreVersion(this); } }

		public virtual Version ResVersion(string resname, out bool create) {
			var match = Regex.Match(resname, "(Create|Drop)[\\s.]*([0-9]+(.[0-9]+)*)");
			if (!match.Success) { create = false; return null; }
			create = match.Groups[1].Value == "Create";
			Version version = null;
			try {
				version = new Version(match.Groups[2].Value);
			} catch { }
			return version;
		}

		void WriteErrorToProviders(object sender, ErrorArgs args) {
			Providers.Exception(sender, args.Message, args.Exception);
		}

		public override void ChangeVersion(Version version) {
			var assembly = GetType().Assembly;
			var storeVersion = ProviderVersions.StoreVersion(assembly.GetName().Name);
			while (storeVersion != version) {
				using (var c = (SqlEntityContext)NewContext()) {
					c.Error += WriteErrorToProviders;
					bool create;
					var files = assembly.GetManifestResourceNames()
						.Select(n => new { File = n, Version = ResVersion(n, out create), Upgrade = create })
						.OrderBy(n => n.Version)
						.Where(n => n.Version != null && n.Version != new Version("0.0.0.0"));
					var exefiles = files;
					if (storeVersion < version) {
						exefiles = exefiles.Where(n => n.Version > storeVersion && n.Version <= version && n.Upgrade);
					} else {
						exefiles = exefiles.Reverse().Where(n => n.Version <= storeVersion && n.Version > version && !n.Upgrade);
 					}
					var file = exefiles.FirstOrDefault();
					Version nv;
					string msg;	
					if (file == null) break;
					if (file.Upgrade) {
						msg = "Upgrading";
						nv = file.Version;
					} else {
						msg = "Downgrading";
						var prevver = files.Where(n => n.Version < file.Version).LastOrDefault();
						if (prevver != null) nv = prevver.Version;
						else nv = new Version(0, 0, 0, 0);
					}
					base.ChangeVersion(nv);
					Providers.Message(this, msg +" Database for " + assembly.GetName().Name + " to version " + nv.ToString() + ": ");
					c.ExecuteSqlResource(file.File);
					if (c.Exceptions.Count == 0) Providers.Message(this, "<span style='color:green'>Success.</span><br/>");
					else Providers.Message(this, "<span style='color:red'>" + c.Exceptions.Count.ToString() + " Errors.</span><br/>");
					storeVersion = nv;
					ProviderVersions.ChangeVersionData(GetType().Assembly.GetName().Name, nv);
					OnVersionChanged(nv, storeVersion);
				}
			}
			Providers.Finished(this);
		}
	}

	[AttributeUsage(AttributeTargets.Class)]
	public class EntitySetAttribute: Attribute {
		public EntitySetAttribute(string set) { EntitySet = set; }
		public string EntitySet { get; set; }
	}

	public abstract class SqlEntityContext: EntityContext {
		
		public virtual string ConnectionString(string EdmxResourceFile) { return ConnectionStrings.Get(EdmxResourceFile); }

		public SqlEntityContext() : base() { Exceptions = new List<Exception>();  }
		public SqlEntityContext(Provider p) : base(p) { Exceptions = new List<Exception>(); }

		public ObjectContext context = null;
		public ObjectContext Context {
			get {
				if (context == null) {
					context = CreateContext();
					context.MetadataWorkspace.LoadFromAssembly(context.GetType().Assembly);
				}
				return context;
			}
		}

		public abstract ObjectContext CreateContext();

		public string EntitySetName(Type e) {
			var t = ((IEntityProvider)Provider).ProviderType(e);
			var es = (EntitySetAttribute)(t.GetCustomAttributes(typeof(EntitySetAttribute), false).FirstOrDefault());

			if (es == null) throw new NotSupportedException("The type " + t.FullName + " is no proper entity type.");
			return es.EntitySet;
		}

		public override void Save() { if (Context != null) Context.SaveChanges(); }
		public override IQueryable<E> Query<E>() { return Context.CreateQuery<E>("[" + EntitySetName(typeof(E)) + "]"); }
		
		public override void Add(object e) {
			e = ProviderTypeClone(e);
			var set = EntitySetName(e.GetType());
			if (set != null) Context.AddObject(set, e);
		}

		public override void Remove(object e) {
			Context.DeleteObject(e);
		}

		public List<Exception> Exceptions { get; protected set; }
		public class DbException: System.Data.Common.DbException {
			public DbException(string message, Exception innerException) : base(message, innerException) { }
		}

		public event ErrorHandler Error;

		public void Execute(string sql, string file) {
			var batches = sql.Split(new string[1] { "GO" }, StringSplitOptions.RemoveEmptyEntries);
			int line = 1;
			Exceptions.Clear();
			foreach (var batch in batches) {
				try {
					var n = Context.ExecuteStoreCommand(batch);
					line += batch.Count(ch => ch == '\n');
				} catch (Exception ex) {
					var msg = "Database SQL Execute error";
					if (file != null) msg += " in file " + file;
					msg += " on line " + line.ToString();
					Log.Error(msg, ex);
					DbException dbex = new DbException(msg, ex);
					Exceptions.Add(dbex);
					if (Error != null) Error(this, new ErrorArgs { Exception = dbex, Message = msg });
				}
			}
		}

		public void Execute(string sql) { Execute(sql, null); }

		public void ExecuteProc(string func, params object[] par) {
			var cmd = new StringBuilder("EXEC [").Append(((IEntityProvider)Provider).AssemblyName).Append("].[").Append(func).Append("]");
			if (par.Length > 0) {
				cmd.Append("(");
				for (int i = 0; i < par.Length; i++) {
					if (par.GetType() == typeof(int) || par.GetType() == typeof(short) || par.GetType() == typeof(long) || par.GetType() == typeof(double) || par.GetType() == typeof(float)) {
						cmd.Append(par.ToString());
					} else {
						cmd.Append("'").Append(par.ToString()).Append("'");
					}
					if (i < par.Length-1) cmd.Append(", ");
				}
				cmd.Append(")");
			}
			cmd.Append(";");
			Execute(cmd.ToString());
		}

		public string GetResourceScript(string res) {
			if (string.IsNullOrEmpty(res)) return string.Empty;
			var a = ((IEntityProvider)Provider).Assembly;
			//if (!res.StartsWith(AssemblyName)) res = AssemblyName + "." + res;

#if DEBUG
			var resx = a.GetManifestResourceNames();
#endif

			using (var r = new StreamReader(a.GetManifestResourceStream(res))) {
				return r.ReadToEnd();
			}
		}

		public void ExecuteSqlResource(string resource) {
			Execute(GetResourceScript(resource), resource);
		}

		public override void Dispose() {
			if (Context != null) {
				try {
					Context.SaveChanges();
				} catch { }
				Context.Dispose();
				context = null;

			}
		}
	}

	public class SqlEntityCollection<T, U>: IEntityCollection<T>
		where T: class
		where U: class, T {

		public System.Data.Objects.DataClasses.EntityCollection<U> Base { get; private set; }
		public SqlEntityCollection(System.Data.Objects.DataClasses.EntityCollection<U> Base) { this.Base = Base; }

		public void Load() { Base.Load(); }
		public void Add(T e) { Base.Add((U)e); }
		public void Remove(T e) { Base.Remove((U)e); }
		public void Clear() { Base.Clear(); }
		public bool Contains(T e) { return Base.Contains((U)e); }
		public void CopyTo(T[] array, int arrayIndex) { Base.CopyTo(array.OfType<U>().ToArray(), arrayIndex); }
		public int Count { get { return Base.Count; } }
		public bool IsReadOnly { get { return Base.IsReadOnly; } }
		public IEnumerator<T> GetEnumerator() {
			foreach (U e in Base) {
				yield return e;
			}
		}
		System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator() { return ((System.Collections.IEnumerable)Base).GetEnumerator(); }
		public bool ContainsListCollection { get { return true; } }
		public System.Collections.IList GetList() { return Base.ToList(); }
		bool ICollection<T>.Remove(T item) { return ((ICollection<U>)Base).Remove((U)item); }
	}
}