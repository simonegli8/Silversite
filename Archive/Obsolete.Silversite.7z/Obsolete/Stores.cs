﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Web.Configuration;

namespace Silversite.Services {
	
	public class DatabaseConfiguration: Silversite.Configuration.ConfigurationSection {

		[ConfigurationProperty("ConnectionString", IsRequired=false, DefaultValue="SilversiteDatabase")]
		public string ConnectionString { get { return this["ConnectionString"] as string ?? string.Empty; } set { this["ConnectionString"] = value; } }

		public static DatabaseConfiguration Current = new DatabaseConfiguration();

		public static ConnectionStringSettings GetConnectionStringSettings() {
			ConnectionStringSettings settings;
			settings = WebConfigurationManager.ConnectionStrings[Current.ConnectionString];
			if (settings == null && WebConfigurationManager.ConnectionStrings.Count > 0) settings = WebConfigurationManager.ConnectionStrings[0];
			return settings;
		}

		static string GetConnectionString(string conntemplate) {
			if (string.IsNullOrEmpty(Current.ConnectionString)) {
				throw new Exception("Silversite.Web.Store: No ConnectionString configured.");
			}
			var cstring = GetConnectionStringSettings();
			if (cstring != null) {
				if (conntemplate.Contains('{')) return string.Format(conntemplate, cstring.ProviderName, cstring.ConnectionString);
				else if (conntemplate.EndsWith(".edmx")) {
					string edmxfile = conntemplate;
					if (edmxfile.StartsWith("~")) edmxfile = edmxfile.Substring(1);
					if (edmxfile.StartsWith("/")) edmxfile = edmxfile.Substring(1);
					edmxfile = edmxfile.Replace('/', '.');
					edmxfile = System.IO.Path.GetFileNameWithoutExtension(edmxfile);
					return string.Format("metadata=res://*/{0}.csdl|res://*/{0}.ssdl|res://*/{0}.msl;provider={1};provider connection string=\"{2}\"", edmxfile, cstring.ProviderName, cstring.ConnectionString);
				} else {
					return cstring.ConnectionString;
				}
			} else {
				throw new Exception("Silversite.Web.Store: Failed to retrieve ConnectionString.");
			}
		}
		
	}

}
