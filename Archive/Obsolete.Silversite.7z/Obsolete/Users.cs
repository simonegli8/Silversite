﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Net.Mail;
using System.Collections.Generic;
using Silversite;

namespace Silversite.Services {
	
	public class Users {

		const string SuperAdminRole = "SuperAdmin";

		public static IQueryable<MembershipUser> All() {
			return Membership.GetAllUsers().OfType<MembershipUser>().AsQueryable();
		}

		public static int AllCount() { return All().Count(); }

		/// <summary>
		/// Returns a window from the client users.
		/// </summary>
		/// <param name="maximumRows">The maximum number of users to return.</param>
		/// <param name="startRowIndex">The starting index of the first user to return.</param>
		public static IQueryable<MembershipUser> All(int pageIndex, int pageSize, out int totalRecords) {
			return Membership.GetAllUsers(pageIndex, pageSize, out totalRecords).OfType<MembershipUser>().AsQueryable();
		}

		public static void Delete(string username) {
			string admin = Membership.GetUser().UserName;
			Log.Write("Deleted User " + username + " by " + admin, "Administration");
			var user = Membership.GetUser(username);
			if (!Roles.IsUserInRole(SuperAdminRole)) Membership.DeleteUser(username, true);
			using (var c = Persons.NewContext()) {
				var person = c.Query<Persons.IEntity>().FirstOrDefault(p => p.Email == username);
				c.Remove(person);
			}
		}

		public static void Update(MembershipUser user) {
			Membership.UpdateUser(user);
			using (var c = Persons.NewContext()) {
				var person = c.Query<Persons.IEntity>().FirstOrDefault(p => p.Email == user.UserName);
				person.Email = user.Email;
			}
		}

		public static void Unlock(string username) {
			MembershipUser u = Membership.GetUser(username);
			if (u.IsLockedOut) {
				u.UnlockUser();
				Log.Write("Unlocked User " + username, "Administration");
			}
		}

		public static void Create(string email, string password) { Create(email, password, new string[] { }); }
		public static void Create(string email, string password, string[] roles) {
			Membership.CreateUser(email, password);
			var user = Membership.GetUser(email);
			user.Email = email;
			Membership.UpdateUser(user);
			Roles.AddUserToRoles(email, roles);
			using (var c = Persons.NewContext()) {
				var person = c.Query<Persons.IEntity>().FirstOrDefault(p => p.Email == email);
				if (person == null) {
					person = Persons.New<Persons.IEntity>();
					person.Email = email;
					c.Add(person);
				}
			}
		}
	}
}
