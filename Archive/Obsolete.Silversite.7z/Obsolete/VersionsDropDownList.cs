﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Silversite.Web.UI {
	public class VersionsDropDownList: System.Web.UI.WebControls.DropDownList {

		public VersionsDropDownList(): base() {
		}

		string assembly;
		public string Assembly {
			get { return assembly; }
			set {
				assembly = value;
				var versions = Services.ProviderVersions.Versions(assembly).Select(x => x.VersionString).ToList();
				versions.Insert(0, "0.0.0.0");
				DataSource = versions;
				SelectedValue = Services.ProviderVersions.StoreVersion(assembly).ToString();
			}
		}

		public Version Value { get { return new Version(base.Text); } set { base.Text = value.ToString(); } }
	}
}