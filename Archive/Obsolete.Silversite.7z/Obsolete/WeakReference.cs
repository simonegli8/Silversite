﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace Silversite.Services {
	
	/*
	[Serializable]
	public class WeakReference<T> where T: class {

		public WeakReference(T target) { r = new WeakReference(target); }

		WeakReference r = null;

		public virtual bool IsAlive { get { return r.IsAlive; } }
		public virtual bool TrackResurrection { get { return r.TrackResurrection; } }
		public virtual T Target { get { return (T)r.Target; } set { r.Target = value;  } }
		public override bool Equals(object obj) { return IsAlive && Target.Equals(obj); }
		public override int GetHashCode() { return IsAlive ? Target.GetHashCode() : 0; }
		
	}
	*/
}