﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;

namespace Silversite.WebServices {
	/// <summary>
	/// Summary description for css
	/// </summary>
	public class Css: IHttpHandler {

		public void ProcessRequest(HttpContext context) {
			context.Response.ContentType = "text/css";
			var files = context.Request.QueryString["files"].Split(';');
			foreach (var file in files) {
				using (var stream = Silversite.Services.Files.Open(file)) {
					using (var r = new StreamReader(stream)) {
						var text = r.ReadToEnd();
						context.Response.Write(text);
						context.Response.Write("\r\n");
					}
				}
			}
		}

		public bool IsReusable { get { return true; } }
	}
}