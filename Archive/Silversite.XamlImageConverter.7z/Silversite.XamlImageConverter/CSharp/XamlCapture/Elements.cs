﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.ComponentModel;
using System.Windows.Markup;

namespace Silversite.XamlImageConverter.Elements {

	[ContentProperty("Children")]
	[DefaultProperty("Children")]
	public class SkinBuilder: UserControl {
		public SkinBuilder(): base() { }

		// Summary:
		//     Gets or sets the content of a System.Windows.Controls.ContentControl.
		//
		// Returns:
		//     An object that contains the control's content. The default value is null.
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
		public List<Scene> Children { get; set;}
	}

	[ContentProperty("Children")]
	[DefaultProperty("Children")]
	public class Scene {
		public double Width { get; set; }
		public double Height { get; set; }
		public string Cultures { get; set; }
		public string OutputPath { get; set; }
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
		public List<ISceneElement> Children { get; set; }
	}

	public interface ISceneElement { }

	[ContentProperty("Children")]
	[DefaultProperty("Children")]
	public class Group: ISceneElement {
		public double? Left { get; set; }
		public double? Right { get; set; }
		public double? Top { get; set; }
		public double? Bottom { get; set; }
		public double? Width { get; set; }
		public double? Height { get; set; }
		public string Element { get; set; }
		public string OutputPath { get; set; }
		public DateTime Version { get; set; }
		public string Cultures { get; set; }
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
		public List<ISceneElement> Children { get; set; }

	}

	[ContentProperty("Content")]
	[DefaultProperty("Content")]
	public class Xaml: ISceneElement {
		public string Source { get; set; }
		public string Type { get; set; }
		public string Assembly { get; set; }
		public bool Dynamic { get; set; }
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
		public List<System.Windows.FrameworkElement> Content { get; set; }
	}

	public class Snapshot: Group {

		public string Storyboard {get; set; }
		public int? Frames { get; set;}
		public bool? Filmstrip {get; set;}
		public double?	Dpi { get; set; }
		//public double? RenderDpi { get; set; }
		public int? Quality { get; set; }
		public string Filename { get; set; }
		public string Page { get; set; }
		public bool FitToPage { get; set; }
	}

	public class Set: ISceneElement {
	}

	public class Undo: ISceneElement {
	}

	public class Reset: ISceneElement {
	}

}
