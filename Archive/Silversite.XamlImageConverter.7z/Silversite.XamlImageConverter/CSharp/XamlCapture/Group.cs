﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media.Animation;
using System.Reflection;
using System.Xml.Linq;
using System.IO;

namespace Silversite.XamlImageConverter
{
	public static class GroupExtensions
	{
		/// <summary>
		/// Returns the ancestors of a FrameworkElement
		/// </summary>
		/// <param name="element">Child element</param>
		/// <param name="includeVisual">True to include Visual elements, otherwise false</param>
		/// <returns>Returns the ancestors of the specified <see cref="FrameworkElement"/></returns>
		public static IEnumerable<FrameworkElement> Ancestors( this FrameworkElement element, bool includeVisual )
		{
			if ( element == null ) yield break;

			var group = element as Group;

			var parent = ( group != null && includeVisual )
				? ( group.Element ?? group.Parent as FrameworkElement )
				: group.Parent as FrameworkElement;

			if ( parent != null ) foreach ( var p in Ancestors( parent, includeVisual ) ) yield return p;
			yield return element;
		}
	}

	public interface Step {
		void Process();
	}

	public class Group: Canvas
	{

		public Group Root { get; set; }

		public string CreateTempPath(string file) {
			TempPath = System.IO.Path.GetTempPath();
			var name = System.IO.Path.GetFileName(file);
			TempPath = System.IO.Path.Combine(TempPath, name + "." + DateTime.Now.Ticks.ToString());
			if (!System.IO.Directory.Exists(TempPath)) System.IO.Directory.CreateDirectory(TempPath);
			TempPaths.Add(TempPath);
			Scene.XamlPath = TempPath;
			return System.IO.Path.Combine(TempPath, System.IO.Path.ChangeExtension(name, ".xaml"));
		}

		FrameworkElement element = null;

		static List<string> TempPaths = new List<string>();
		public string XamlFile = null;
		public string XamlPath = null;

		public FrameworkElement Element {
			get {
				if (element == null) {
					if (Source != null) {
						var info = new FileInfo(Compiler.MapPath(Source));

						var file = info.FullName;
						string xaml = null;

						bool psd;
						if ((psd = Source.ToLower().EndsWith(".psd")) || Source.ToLower().EndsWith(".swf")) {
						
							xaml = CreateTempPath(file);

							var apath = Assembly.GetExecutingAssembly().CodeBase
								.Substring("file:///".Length)
								.Replace('/', '\\');
							apath = Path.GetDirectoryName(apath);
							Type doctype;
							if (psd) {
								var a = Assembly.LoadFrom(Path.Combine(apath, "psd2xaml\\Endogine.Codecs.Photoshop.dll"));
								doctype = a.GetType("Endogine.Codecs.Photoshop.Document");
							} else {
								var a = Assembly.LoadFrom(Path.Combine(apath, "psd2xaml\\Endogine.Codecs.Flash.dll"));
								doctype = a.GetType("Endogine.Codecs.Flash.Document");
							}
								
							dynamic doc = Activator.CreateInstance(doctype, file);
							doc.SaveXaml(xaml);
							file = xaml;

						}

						if (Source.ToLower().EndsWith(".svg")) {
							element = XamlTune.ConvertUtility.LoadSvg(file);
							/*xaml = CreateTempPath(file);
							var xamlxml = XamlTune.ConvertUtility.ConvertSvg(file);
							File.WriteAllText(xaml, xamlxml);
							file = xaml;*/
						} else {

							Scene.XamlFile = file;

							using (var stream = File.OpenRead(file)) {
								if (Source.ToLower().EndsWith(".xaml") || Source.ToLower().EndsWith(".psd") || Source.ToLower().EndsWith(".svg")) {
									ParserContext context;
									if (string.IsNullOrEmpty(XamlElement.BaseUri)) context = new ParserContext { BaseUri = new Uri("file:///" + file) };
									else context = new ParserContext { BaseUri = new Uri(XamlElement.BaseUri) };
									element = XamlReader.Load(stream, context) as FrameworkElement;
								} else {
									throw new CompilerException("Input format not supported.", 20, XElement);
								}
							}
						}
					} else {
						string assemblyName = AssemblyName;
						string typeName = TypeName;
						if (assemblyName != null) assemblyName = Compiler.MapPath(assemblyName);
						Assembly assembly;
						Type type = null;
						if (typeName != null) {
							if (assemblyName != null) {
								try {
									var assemblies = AppDomain.CurrentDomain.GetAssemblies();
									assembly = assemblies.FirstOrDefault(a => a.FullName == assemblyName);
									if (assembly == null) lock(Compiler.DllLock) assembly = Assembly.LoadFrom(assemblyName);
									if (assembly != null) {
										int i = TypeName.IndexOf(',');
										if (i > -1) typeName = typeName.Substring(0, i);
										type = assembly.GetType(typeName);
									}
								} catch {
									throw new CompilerException(string.Format("Error loading assembly {0}.", assemblyName), 12, XamlElement);
								}
							} else {
								try {
									type = Type.GetType(typeName, false);
									if (type == null) {
										var assemblies = AppDomain.CurrentDomain.GetAssemblies();
										/*	foreach (var a in assemblies.Reverse()) {
												var types = a.GetTypes();
												var tx = types.Where(p => p.FullName == typename).FirstOrDefault();
											} */
										type = assemblies.Reverse().SelectMany(a => a.GetTypes()).FirstOrDefault(t => t.FullName == typeName);
									}
								} catch {
									throw new CompilerException(string.Format("Invalid type name {0}.", typeName), 13, XamlElement);
								}
							}
							if (type != null) {
								try {
									element = Activator.CreateInstance(type) as FrameworkElement;
								} catch (Exception ex) {
									throw new CompilerInnerException(string.Format("Error creating type {0}.", typeName), 14, XamlElement, ex);
								}
							} else {
								throw new CompilerException(string.Format("Type {0} not found.", typeName), 15, XamlElement);
							}
						} else if (InnerXaml != null) {
							element = XamlReader.Load(InnerXaml.CreateReader()) as FrameworkElement;
						} else {
							element = null;
						}
					}

					if (ElementName != null) {
						//element = Root.Element.FindName<FrameworkElement>(ElementName);
						element = LogicalTreeHelper.FindLogicalNode(Root.Element, ElementName) as FrameworkElement;
					}

					if (element != null) {
						element.LayoutUpdated += delegate {
							Width = Element.ActualWidth;
							Height = Element.ActualHeight;
							this.MeasureAndArrange(new Size(Width, Height));
						};
						element.MeasureAndArrange(PreferredSize);

						// element.MeasureAndArrange(PreferredSize);
						Scene.MeasureAndArrange(PreferredSize);
					}
				}
				return element;
			}
			set { element = value; }
		}
		
		public void LoadElement() { element = Element; }

		public string Source { get; set; }
		public string AssemblyName { get; set; }
		public string TypeName { get; set; }
		public XElement InnerXaml { get; set; }
		public XElement XamlElement { get; set; }
		public XElement SourceElement { get; set; }
		public string ElementName { get; set; }
		public Size PreferredSize { get; set; }
		public Compiler Compiler { get; set; }
		public List<string> DependsOn { get; set; }
		public Errors Errors { get { return Compiler.Errors; } }

		public XElement XElement { get; set; }
		public string OutputPath { get; set; }
		public DateTime Version { get; set; }
		public virtual bool ParseChildren { get { return true; } }

		public string TempPath { get; set; }

		public Group Scene {
			get {
				if (Parent != null && Parent is Group) return ((Group)Parent).Scene;
				else return this;
			}
		}

		//public FileInfo FileInfo { get; set; }

		/// <summary>
		/// Returns all child groups and snapshots
		/// </summary>
		/// <returns></returns>
		protected virtual IEnumerable<Group> FlattenChildren()
		{
			return from c in Children.Cast<Group>()
				   from s in c.Flatten()
				   select s as Group;
		}

		/// <summary>
		/// Return all child steps
		/// </summary>
		/// <returns>Returns all child steps</returns>
		public virtual IEnumerable<Step> Flatten()
		{
			return FlattenChildren().OfType<Step>();
		}

		public IEnumerable<Step> Steps() { return Flatten(); }

		/// <summary>
		/// Returns all ancestor <see cref="Group"/>s
		/// </summary>
		/// <returns>Returns all ancestor <see cref="Group"/>s</returns>
		public IEnumerable<Group> AncestorGroups
		{
			get { return this.Ancestors( false ).OfType<Group>(); }
		}

		public string cultures;

		public virtual string Cultures { get { return cultures; } set { cultures = value; } }

		public void Cleanup() {
			if (!string.IsNullOrEmpty(TempPath)) {
				System.IO.Directory.Delete(TempPath, true);
				TempPath = null;
			}
		}

		public static void Close(Errors errors) {
			Snapshot.SaveXps(errors);
			ImageMagickEncoder.SaveAll(errors);
			foreach (var path in TempPaths) Directory.Delete(path, true);
		}
	}

}