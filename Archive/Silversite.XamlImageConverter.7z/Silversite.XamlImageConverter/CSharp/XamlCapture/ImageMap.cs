﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace Silversite.XamlImageConverter.XamlCapture {

	public class AttributeCollection: KeyedCollection<string, XAttribute> {
		public override string GetKeyForItem(XAttribute a) { return a.Name.ToString().ToLower(); }
  	}
	
	public class ImageMap: Group, Step {
		public string Image { get; set; }
		public double Scale { get; set; }
		public string File { get { return Filename; } set { Filename = value; } }
		public string Filename { get; set; }
		public string ID { get; set; }

		AttributeCollection attributes = new AttributeCollection();
		public AttributeCollection Attributes { get { return attributes; } }

		List<XElement> children = new List<XElement>();
		public List<XElement> Children { get { return children; } }

		public Snapshot Snapshot { get { return Scene.Steps().OfType<Snapshot>().FirstOrDefault(s => s.File == Image); } }

		public void Save() {
			var str = new StringBuilder();
			str.Append("<%@ Control ");
			var res = new List<string>() { "AutoEventWireup", "ClassName", "ClientIDMode", "CodeBehind", "CodeFile", "CodeFileBaseClass", "CompilationMode", "CompilerOptions", "Debug", "EnableTheming",
				"EnableViewState", "Explicit", "Inherits", "Language", "LinePragmas", "Src", "Strict", "ViewStateMode", "WarningLevel" };
			foreach (var a in Attributes.ToList()) {
				if (res.Contains(a.Name)) {
					str.Append(a.Name);
					if (a.Value != null) {
						str.Append("=\"");
						str.Append(a.Value);
						str.Append("\" ");
					}
					Attributes.Remove(a);
				}
			}
			str.AppendLine("%>");
			str.AppendLine();

			string id = null;
			var ida = Attributes["id"];
			if (ida == null) id = ("map_" + Image.GetHashCode().ToString());
			else id = ida.Value;

			var map = new XElement("asp:ImageMap", new XAttribute("ID", id), new XAttribute("runat", "server"), new XAttribute("ImageUrl", Image));
 			Attributes.Remove("id");
			Attributes.Remove("runat");
			Attributes.Remove("imageurl");
			foreach (var a in Attributes) map.SetAttributeValue(a.Name, a.Value);

			var s = Snapshot;
			if (s == null) throw new CompilerException("ImageMap has no related Snapshot", 60, this.XElement);
			
			System.Windows.FrameworkElement e = null;
			if (string.IsNullOrEmpty(s.ElementName)) e = s.Root.Element;
			else e = s.Element;

			foreach (XElement child in Children) {
				//TODO
				if (child.Name == "area") {
					if (


				switch (a.Name) {
				case "Language": str.Append("Language=\""); str.Append(a.Value); str.Append("\" ");
				case "CodeBehind": str.Append("CodeBehind=\""); str.Append(a.Value
			Language="
	}
}
