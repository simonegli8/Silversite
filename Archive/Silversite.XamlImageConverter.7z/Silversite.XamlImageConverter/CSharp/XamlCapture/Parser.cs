﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;
using System.Windows.Media.Animation;
using System.Xml.Linq;
using System.Xml.XPath;
using System.Windows.Media;
using System.Reflection;
using System.Threading;
using System.Globalization;

namespace Silversite.XamlImageConverter {

	[Serializable]
	public class Parser: MarshalByRefObject {

		[NonSerialized]
		Errors errors = null;
		public Errors Errors { get { if (errors == null) errors = new Errors(); return errors; } set { errors = value; } }

		public Compiler Compiler { get { return this as Compiler; } } 

		[NonSerialized]
		private static string ns1 = "http://schemas.johnshope.com/SkinBuilder/2011";
		[NonSerialized]
		private static string ns2 ="http://www.chriscavanagh.com/SkinBuilder";

		/// <summary>
		/// Save snapshots for multiple scenes
		/// </summary>
		/// <param name="config">Configuration element</param>
		/// <returns>Returns a collection of snapshot bitmaps</returns>
		public IEnumerable<Group> ParseScenes(DateTime Version, XElement config) {
			var ns = config.Name.NamespaceName;
			if (ns == ns1 || ns == ns2) {
				Namespace = ns;
				if (config.Name != SBName("SkinBuilder")) Errors.Error("Invalid root element", "26", config);
				foreach (var x in config.Elements()) {
					if (x.Name == SBName("Scene")) {
						Group scene = null;
						try {
							scene = ParseScene(Version, x);
						} catch (CompilerInnerException ex) {
							Errors.Error(ex.Message + "\n" + ex.InnerException.Message + "\n" + ex.InnerException.StackTrace, ex.ErrorCode.ToString(), ex.XObject);
						} catch (CompilerException ex) {
							Errors.Error(ex.Message, ex.ErrorCode.ToString(), ex.XObject);
						} catch (Exception ex) {
							Errors.Warning("An internal parsing error occurred\n\n" + ex.Message + "\n" + ex.StackTrace, "2", x);
						}
						if (scene != null) yield return scene;
					} else {
						Errors.Error("Invalid element " + x.Name.LocalName, "24", x);
					}
				}
			} else {
				Errors.Error("Invalid namespace " + config.Name.NamespaceName, "25", config);
			}
		}

		/// <summary>
		/// Returns a collection of <see cref="Snapshot"/>s from configuration elements
		/// </summary>
		/// <param name="snapshots">A collection of snapshot configuration elements</param>
		/// <returns>Returns a list of <see cref="Snapshot"/>s</returns>
		public Group ParseScene(DateTime Version, XElement x) {
			var scene = new Group() { Compiler = Compiler };

			var xaml = x.Elements(SBName("Xaml")).SingleOrDefault();
			xaml = x.Elements(SBName("Source")).SingleOrDefault() ?? xaml;
			if (x.Attribute("Source") != null || x.Attribute("File") != null || x.Attribute("Type") != null) xaml = x;
			var src = scene.Source = (xaml.Attribute("Source") ?? xaml.Attribute("File")).Value; 

			if (xaml == null) throw new CompilerException("Scene must contain source file specification.", 10, x);
			scene.XamlElement = xaml;

			var width = (double?)xaml.Attribute("Width") ?? double.PositiveInfinity;
			var height = (double?)xaml.Attribute("Height") ?? double.PositiveInfinity;
			var cultures = (string)x.Attribute("Cultures");
			var dependencies = (string)x.Attribute("DependsOn");

			var outputPath = Compiler.MapPath((string)x.Attribute("OutputPath"));
			scene.PreferredSize = new Size(width, height);
			scene.OutputPath = outputPath;
			scene.Cultures = cultures;
			if (dependencies != null) scene.DependsOn = dependencies.Split(';').ToList();
			else scene.DependsOn = new List<string>();

			/*
			if (!string.IsNullOrEmpty(culture)) { // set UICulture
				var cultureInfo = new CultureInfo(culture);
				Thread.CurrentThread.CurrentUICulture = cultureInfo;
			} */

			// FrameworkElement element;

			//FileInfo info = null, cinfo = null;
			DateTime XamlVersion = new DateTime();
			FileInfo info;

			if (src != null) {
				info = new FileInfo(Compiler.MapPath(src));
				if (!info.Exists) throw new CompilerException("Source file " + info.FullName + " not found.", 11, xaml);

				XamlVersion = info.LastWriteTimeUtc;
				if (XamlVersion > Version) Version = XamlVersion;
			} else {
				string assemblyName = (string)xaml.Attribute("Assembly");
				string typename = (string)xaml.Attribute("Type");
				
				scene.AssemblyName = assemblyName;
				scene.TypeName = typename;

				if (typename == null) {
					scene.InnerXaml = xaml.Elements().SingleOrDefault();
					if (scene.InnerXaml == null) throw new CompilerException("Scene must contain a single XAML root element", 16, xaml);
				}
			}

			if (xaml.Attribute("Dynamic") != null && xaml.Attribute("Dynamic").Value == "true") Version = DateTime.Now.ToUniversalTime();
	

			// parse dependencies
			foreach (var dependency in x.Elements().Where(child => child.Name == SBName("Depends"))) {
				var d = new Dependency(dependency) { Compiler = Compiler };
				if (d.Version > Version) Version = d.Version;
			}

			scene.Version = Version;

			if (Compiler.Parameters.Count > 0) {
				var p = new Parameters(Compiler.Parameters);
				p.Compiler = Compiler;
				p.Root = scene;
				p.ElementName = string.Empty;
				p.XElement = null;
			}

			// parse oridnary elements
			var names = new XName[] { SBName("Xaml"), SBName("Depends") };
			foreach (var child in x.Elements().Where(child => !names.Contains(child.Name))) {
				Parse(child, scene);
			}

			foreach (var node in x.Nodes().Where(node => !(node is XElement || node is XComment))) {
				Errors.Error("Invalid content", "23", node);
			}

			return scene;
		}


		/// <summary>
		/// Returns a collection of <see cref="Snapshot"/>s from configuration elements
		/// </summary>
		/// <param name="snapshots">A collection of snapshot configuration elements</param>
		/// <returns>Returns a list of <see cref="Snapshot"/>s</returns>
		public Group Parse(XElement x, Group container) {
			Group item = CreateItem(container, x);
			item.Version = container.Version;
			container.Children.Add(item);

			if (x.Attribute("Left") != null) item.SetValue(Canvas.LeftProperty, (double)x.Attribute("Left"));
			if (x.Attribute("Top") != null) item.SetValue(Canvas.TopProperty, (double)x.Attribute("Top"));
			if (x.Attribute("Right") != null) item.SetValue(Canvas.RightProperty, (double)x.Attribute("Right"));
			if (x.Attribute("Bottom") != null) item.SetValue(Canvas.BottomProperty, (double)x.Attribute("Bottom"));
			if (x.Attribute("Width") != null) item.Width = (double)x.Attribute("Width");
			if (x.Attribute("Height") != null) item.Height = (double)x.Attribute("Height");
			if (x.Attribute("Cultures") != null) item.Cultures = (string)x.Attribute("Cultures");

			if (item.ParseChildren) {
				foreach (var child in x.Elements()) {
					Parse(child, item);
				}
				foreach (var nodes in x.Nodes().Where(node => !(node is XElement || node is XComment))) {
					Errors.Error("Invalid content " + nodes.ToString(), "23", nodes);
				}
			}

			return item;
		}

		public void ValidAttributes(XElement x, params string[] names) {
			foreach (var a in x.Attributes()) {
				if (!names.Contains(a.Name.LocalName)) {
					Errors.Error("Invalid attribute " + a.Name.LocalName, "22", a);
				}
			}
		}

		/// <summary>
		/// Create a new group or snapshot
		/// </summary>
		/// <param name="container">Container element</param>
		/// <param name="x">Definition element</param>
		/// <returns>Returns a new group or snapshot</returns>
		private Group CreateItem(Group container, XElement x) {
			var root = container.Root ?? container;
			Group result = null;

			switch (x.Name.LocalName) {
			case "Snapshot":
				
				result = new Snapshot {
					StoryboardName = (string)x.Attribute("Storyboard"),
					Frames = (int?)x.Attribute("Frames"),
					Filmstrip = (bool?)x.Attribute("Filmstrip") ?? false,
					Dpi = (double?)x.Attribute("Dpi"),
					RenderDpi = (double?)x.Attribute("RenderDpi"),
					Quality = (int?)x.Attribute("Quality"),
					Filename = (string)x.Attribute("Filename"),
					Cultures = (string)x.Attribute("Cultures"),
					RenderTimeout = (int?)x.Attribute("RenderTimeout"),
					Page = (string)x.Attribute("Page"),
					FitToPage = (bool?)x.Attribute("FitToPage") ?? false
				};
				ValidAttributes(x, "Element", "Storyboard", "Frames", "Filmstrip", "Dpi", "RenderDpi", "Quality", "Filename", "Left", "Top", "Right", "Bottom", "Width", "Height", "Cultures", "RenderTimeout", "Page", "FitToPage");
				break;
			case "Set":
				result = new Parameters(x);
				break;
			case "Undo":
				result = new Undo();
				ValidAttributes(x);
				break;
			case "Reset":
				result = new Reset();
				ValidAttributes(x);
				break;
			case "Group":
				result = new Group { OutputPath = (string)x.Attribute("OutputPath") };
				ValidAttributes(x, "Element", "OutputPath", "Left", "Top", "Right", "Bottom", "Width", "Height");
				break;
			default:
				Errors.Error("Invalid element " +  x.Name.LocalName, "20", x);
				result = new Group();
				break;
			}
			result.Compiler = Compiler;
			result.Root = root;
			result.ElementName = (string)x.Attribute("Element");
			result.XElement = x;

			return result;
		}

		private string Namespace = ns1;
		/// <summary>
		/// Returns a namespace qualified <see cref="XName"/>
		/// </summary>
		/// <param name="name">Local name</param>
		/// <returns>Returns a namespace qualified <see cref="XName"/></returns>
		private XName SBName(string name) {
			return XName.Get(name, Namespace);
		}
	}
}