﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;

namespace Silversite.XamlImageConverter {

	public static class WPFExtensions {
		/// <summary>
		/// Measure and Arrange an element using the specified maximum size
		/// </summary>
		/// <param name="element">Element to Measure and Arrange</param>
		/// <param name="size">Maximum container size</param>
		/// <returns>The Measured and Arranged element</returns>
		public static UIElement MeasureAndArrange(this UIElement element, Size size) {
			element.Measure(size);
			element.Arrange(new Rect(element.DesiredSize));
			element.UpdateLayout();

			if (element is Page && ((Page)element).Content is Canvas) {
				var page = (Page)element;
				var canvas = (Canvas)page.Content;
				if (page.ActualWidth == 0 || page.ActualHeight == 0) { // photoshop import has a canvas without size
					size = new Size(0, 0);
					foreach (UIElement part in canvas.Children) {
						if (part is FrameworkElement) {
							var fp = (FrameworkElement)part;
							double top, left;
							top = (double)fp.GetValue(Canvas.TopProperty);
 							left = (double)fp.GetValue(Canvas.LeftProperty);
							size = new Size(Math.Max(size.Width, left + fp.Width), Math.Max(size.Height, top + fp.Height));
						}
					}

					page.Width = size.Width; page.Height = size.Height;
					element.Measure(size);
					element.Arrange(new Rect(element.DesiredSize));
					element.UpdateLayout();
				}
			}

			return element;
		}

		/// <summary>
		/// Find an element by its name; throw an exception if it doesn't exist
		/// </summary>
		/// <typeparam name="T">Element type</typeparam>
		/// <param name="rootElement">Root element</param>
		/// <param name="name">Element name</param>
		/// <returns>Returns the element</returns>
		public static T FindName<T>(this FrameworkElement rootElement, string name) {
			var element = (T)rootElement.FindName(name);
			if (element != null) return element;

			throw new CompilerException(string.Format("The specified element '{0}' does not exist", name), 19, null);
		}

		/// <summary>
		/// Find a resource by its name; throw an exception if it doesn't exist
		/// </summary>
		/// <typeparam name="T">Resource type</typeparam>
		/// <param name="rootElement">Root element</param>
		/// <param name="name">Resource name</param>
		/// <returns>Returns the resource</returns>
		public static T FindResource<T>(this FrameworkElement rootElement, string name) {
			return (T)rootElement.FindResource(name);
		}
	}
}
