﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace Silversite.XamlImageConverter {
	public class XamlScene {
		public static XElement Create(string filename) {
			var xaml = filename;
			if (!xaml.EndsWith(".xaml")) xaml = System.IO.Path.GetFileNameWithoutExtension(filename);
			else filename = filename + ".png"; 
			XNamespace ns = "http://schemas.johnshope.com/SkinBuilder/2011";
			return new XElement(ns + "SkinBuilder",
					new XElement(ns + "Scene",
						new XElement(ns + "Xaml", new XAttribute("Source", xaml)),
						new XElement(ns + "Snapshot", new XAttribute("Filename", filename))
					)
				);
		}
	}
}
