﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Handlers;
using System.Diagnostics;
using System.Globalization;
using System.Configuration;
using Silversite.XamlImageConverter;

namespace Silversite.Web {

	[Configuration.Section(Name = "xamlImages")]
	public class XamlImageHandler: Configuration.Section, System.Web.IHttpHandler {

		[ConfigurationProperty("useService", IsRequired = false, DefaultValue=false)]
		public bool UseSevice { get { return (bool)(this["useService"] ?? true); } set { this["useService"] = value; } }

		[ConfigurationProperty("log", IsRequired = false, DefaultValue = true)]
		public bool Log { get { return (bool)(this["log"] ?? true); } set { this["log"] = value; } }


		public XamlImageHandler(): base() { }

		public bool IsReusable {
			get { return true; }
		}

		//TODO color gradient?
		public void ProcessRequest(System.Web.HttpContext context) {
			var filename = context.Request.AppRelativeCurrentExecutionFilePath;
			var projpath = context.Server.MapPath("~");
			var libpath = context.Server.MapPath("~/bin");
			var skinpath = context.Server.MapPath(context.Request.AppRelativeCurrentExecutionFilePath);
			string cultureid = context.Request.QueryString["culture"];

			var par = new Dictionary<string, string>();
			foreach (var key in context.Request.QueryString.AllKeys) {
				if (key != "culture" && key != "image") {
					par.Add(key, context.Request.QueryString[key]);
				}
			}

			var compiler = new Compiler(projpath, libpath);
			compiler.SourceFiles.Add(skinpath);
			compiler.RebuildAll = false;
			compiler.SeparateAppDomain = !UseSevice;
			compiler.UseService = UseSevice;
			compiler.Parameters = par;
			if (Log) compiler.Loggers.Add(new FileLogger());
			if (!string.IsNullOrEmpty(cultureid)) { compiler.Culture = CultureInfo.GetCultureInfo(cultureid); }
			compiler.Compile();

			string image = context.Request.QueryString["image"];
			if (!string.IsNullOrEmpty(image)) filename = image;
			var sfile = context.Server.MapPath(filename);
			switch (System.IO.Path.GetExtension(filename).ToLower()) {
			case ".bmp": context.Response.ContentType = "image/bmp"; break;
			case ".png": context.Response.ContentType = "image/png"; break;
			case ".jpg":
			case ".jpeg":	context.Response.ContentType = "image/jpeg"; break;
			case ".tif":
			case ".tiff": context.Response.ContentType = "image/tiff"; break;
			case ".gif": context.Response.ContentType = "image/gif"; break;
			case ".wdp": context.Response.ContentType = "image/vnd.ms-photo"; break;
			case ".pdf": 
				context.Response.AppendHeader("content-disposition", "attachment; filename=" + System.IO.Path.GetFileName(sfile));
				context.Response.ContentType = "application/pdf"; break;
			case ".xps":
				context.Response.AppendHeader("content-disposition", "attachment; filename=" + System.IO.Path.GetFileName(sfile));
				context.Response.ContentType = "application/vnd.ms-xpsdocument"; break;
			case ".eps":
			case ".ps":
				context.Response.AppendHeader("content-disposition", "attachment; filename=" + System.IO.Path.GetFileName(sfile));
				context.Response.ContentType = "application/postscript"; break;
			default: break;
			}

			if (System.IO.File.Exists(sfile)) context.Response.WriteFile(sfile);
			else {
				context.Response.StatusCode = 404;
				context.Response.End();
			}
		}
	}
}
