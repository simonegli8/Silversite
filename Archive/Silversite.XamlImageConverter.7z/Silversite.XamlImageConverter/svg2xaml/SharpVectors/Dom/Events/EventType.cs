using System;

namespace SharpVectors.Dom.Events
{
	public enum EventType{MouseOver, MouseDown, MouseUp, Click}
}
