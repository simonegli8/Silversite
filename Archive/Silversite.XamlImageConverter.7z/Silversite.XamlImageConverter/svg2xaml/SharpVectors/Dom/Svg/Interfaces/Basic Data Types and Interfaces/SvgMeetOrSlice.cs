using System;
using System.Text.RegularExpressions;

namespace SharpVectors.Dom.Svg
{
	// Meet-or-slice Types
	public enum SvgMeetOrSlice
	{
		Unknown,
		Meet,
		Slice
	}
}
