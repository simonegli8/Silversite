using System;

namespace SharpVectors.Dom.Svg
{
	/// <summary>
	/// Summary description for SvgZoomAndPanType.
	/// </summary>
	public enum SvgZoomAndPanType
	{
		Unknown =0,
		Disable =1,
		Magnify =2
	}
}
