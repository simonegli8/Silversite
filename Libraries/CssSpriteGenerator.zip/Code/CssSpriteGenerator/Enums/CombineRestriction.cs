﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CssSpriteGenerator
{
    // It is important to have the more restrictive combine restrictions
    // lower in the list. In Generator.cs, when imageInfosMostRestrictiveFirst gets
    // created, its sort order depends on this.

    // TODO: Have additional restrictions: HorizontalRightOnly, HorizontalLeftOnly, etc.
    // This way, a background image that repeats vertically but is not as wide as its parent could still be sprited.

    public enum CombineRestriction
    {
        Null,
        None,
        HorizontalOnly,
        VerticalOnly
    }
}
