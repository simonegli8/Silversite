﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CssSpriteGenerator
{
    public enum ImageType
    {
        Null,
        Png,
        Gif,
        Jpg
    }
}
