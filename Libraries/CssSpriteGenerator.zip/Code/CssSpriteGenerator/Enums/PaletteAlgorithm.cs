﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CssSpriteGenerator
{
    public enum PaletteAlgorithm
    {
        None = 0,
        DontCare = 0,
        Windows,
        HSB,
        MedianCut,
        Octree,
        Popularity,
        Uniform
    }
}
