﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.HtmlControls;

namespace CssSpriteGenerator
{
    public class HtmlImage_ImageReference : PageBase_ImageReference
    {
        public HtmlImage_ImageReference(HtmlImage htmlImage, ConfigSection cs)
            : base(htmlImage, cs)
        {
        }

    }
}
