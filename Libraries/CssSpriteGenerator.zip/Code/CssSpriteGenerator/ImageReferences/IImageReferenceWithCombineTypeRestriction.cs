﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CssSpriteGenerator
{
    /// <summary>
    /// An IImageReference with a combine type restriction.
    /// </summary>
    public interface IImageReferenceWithCombineTypeRestriction: IImageReference
    {
        /// <summary>
        /// Gets the combine type restriction of the image in the image reference.
        /// </summary>
        /// <returns></returns>
        CombineRestriction CombineRestriction { get; }
    }
}
