﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;

namespace CssSpriteGenerator
{
    public class Image_ImageReference : PageBase_ImageReference
    {
        public Image_ImageReference(Image image, ConfigSection cs)
            : base(image, cs)
        {
        }
    }
}
