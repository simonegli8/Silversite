﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;

namespace CssSpriteGenerator
{
    /// <summary>
    /// This image reference is used to store a reference to an image
    /// found in a LiteralControl. An img tag without runat="server" would be 
    /// found this way.
    /// 
    /// Note that if a LiteralControl (a run of html without runat="server")
    /// contains multiple img tags, than multiple 
    /// LiteralControl_ImageReference objects will be created and added to the generator,
    /// all pointing at the same LiteralControl. They may even have the same url, class and id
    /// if the same image appears multiple times in the same LiteralControl.
    /// </summary>
    public class LiteralControl_ImageReference : PageBase_ImageReference
    {
        public LiteralControl_ImageReference(LiteralControl literalControl, ImageTag imageTag, ConfigSection cs) : 
            base(literalControl, imageTag, cs)
        {
        }

    }
}
