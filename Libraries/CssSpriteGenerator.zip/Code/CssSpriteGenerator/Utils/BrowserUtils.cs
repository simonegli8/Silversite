﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace CssSpriteGenerator
{
    public class BrowserUtils
    {
        public static bool BrowserSupportsInlinedImages()
        {
            string userAgent = HttpContext.Current.Request.UserAgent;
            return !(userAgent.Contains("MSIE 7") || userAgent.Contains("MSIE 6"));
        }
    }
}
