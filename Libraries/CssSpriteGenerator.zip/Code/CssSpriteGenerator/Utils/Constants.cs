﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CssSpriteGenerator
{
    public class Constants
    {
        /// <summary>
        /// If no sprite image type has been set in web.config, and the constituent images of a sprite have different image types,
        /// then this image type is used for the sprite. 
        /// </summary>
        public static ImageType DefaultDefaultSpriteImageType { get { return ImageType.Png;}}

        // -----------------------------------
        // Defaults for group parameters

        public static int DefaultMaxWidth { get { return 100; }}
        public static int DefaultMaxHeight { get { return 100; }}
        public static int DefaultMaxSpriteSize { get { return 30000; }}
        public static bool DefaultSamePixelFormat { get { return true; }}
        public static int DefaultMaxSize { get { return Int32.MaxValue; }}
    }
}
