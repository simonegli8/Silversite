﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for ImageStore
/// </summary>
public class ImageStore
{
	public ImageStore()
	{
	}

    public class ImageUrl
    {
        public string Url { get; set; }
    }

    public IEnumerable<ImageUrl> GetAllImages()
    {
        List<string> rawImages = new List<string>(
            new string[] {
                "images/cart.png",
                "images/contactus.png",
                "images/print.png"
            });

        IEnumerable<ImageUrl> images =
            from i in rawImages
            select new ImageUrl { Url = i };

        return images;
    }
}

