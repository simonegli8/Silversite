using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ActiveUp.MailSystem.DesktopClient.Help
{
    /// <summary>
    /// This class represents an about form.
    /// </summary>
    public partial class AboutForm : Form
    {

        /// <summary>
        /// About form constructor.
        /// </summary>
        public AboutForm()
        {
            this.InitializeComponent();
        }
    }
}