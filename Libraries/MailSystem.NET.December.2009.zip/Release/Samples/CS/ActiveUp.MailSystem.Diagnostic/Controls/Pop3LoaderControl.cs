using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace ActiveUp.MailSystem.Diagnostic.Controls
{
    public partial class Pop3LoaderControl : UserControl
    {
        public Pop3LoaderControl()
        {
            InitializeComponent();
        }
    }
}
