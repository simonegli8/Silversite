using System;
using System.Collections.Generic;
using System.Text;

namespace PrintMail
{
    class Constants
    {
        public static string SETT_FILE_NAME = "PrintSettings.conf";
        public static string SAVE_FOLDER = "Attachments";
    }
}
