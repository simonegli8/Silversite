using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ActiveUp.Net.Samples.Compact
{
    public partial class frmvToDo : Form
    {
        public frmvToDo()
        {
            InitializeComponent();
        }
    }
}