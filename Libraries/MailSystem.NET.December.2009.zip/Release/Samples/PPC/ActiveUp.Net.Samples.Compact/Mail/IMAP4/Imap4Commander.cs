using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ActiveUp.Net.Samples.Compact.Mail.IMAP4
{
    public partial class Imap4Commander : Form
    {
        public Imap4Commander()
        {
            InitializeComponent();
        }
    }
}