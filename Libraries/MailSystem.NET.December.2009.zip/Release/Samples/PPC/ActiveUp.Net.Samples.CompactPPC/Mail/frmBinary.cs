using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ActiveUp.Net.Samples.CompactPPC
{
    public partial class frmBinary : Form
    {
        public frmBinary()
        {
            InitializeComponent();
        }
    }
}