using System;

using NUnit.Framework;

using TypeBuilderLib.AOP;

namespace TypeBuilderLib.UnitTests.AOP
{
	[TestFixture(Description = "Test an AOP adapter to see that it really forwards calls.")]
	public class AopAdapterTest : TestBase
	{
		#region Inner types
		public interface IPersonName
		{
			string Name { get;}
		}

		public interface IPersonAge
		{
			int Age { get;set;}
		}

		public interface IPersonGrow
		{
			void GrowOlder();
		}

		public interface IPersonGetter
		{
			string GetName();
		}

		public interface IPersonSetter
		{
			int SetAge(int newAge);
		}

		public interface IPersonAgeOut
		{
			void GetAgeOut(out int ageOut);
		}

		public interface IPersonNameRef
		{
			void GetNameRef(ref string nameRef);
		}

		public interface IPerson :
			IPersonName,
			IPersonAge,
			IPersonGrow,
			IPersonGetter,
			IPersonSetter,
			IPersonAgeOut,
			IPersonNameRef
		{
		}

		private class Person : IPerson
		{
			private readonly string name;
			private int age;

			public Person(string name, int age)
			{
				this.name = name;
				this.age = age;
			}

			#region IPersonName Members
			string IPersonName.Name
			{
				get { return name; }
			}
			#endregion

			#region IPersonAge Members
			int IPersonAge.Age
			{
				get { return age; }
				set { age = value; }
			}
			#endregion

			#region IPersonGrow Members
			void IPersonGrow.GrowOlder()
			{
				++age;
			}
			#endregion

			#region IPersonGetter Members
			string IPersonGetter.GetName()
			{
				return name;
			}
			#endregion

			#region IPersonSetter Members
			int IPersonSetter.SetAge(int newAge)
			{
				age = newAge;

				return age;
			}
			#endregion

			#region IPersonAgeOut Members
			void IPersonAgeOut.GetAgeOut(out int ageOut)
			{
				ageOut = age;
			}
			#endregion

			#region IPersonNameRef Members
			void IPersonNameRef.GetNameRef(ref string nameRef)
			{
				nameRef = nameRef.Length.ToString();
			}
			#endregion
		}
		#endregion

		[Test]
		public void TestNameGet()
		{
			IPersonName person = new Person("Vincent", 33);
			IPersonName proxy = AopAdapterCache.GetInstance<IPersonName>((Person)person);

			Assert.AreEqual(proxy.Name, person.Name);
		}

		[Test]
		public void TestAgeSet()
		{
			IPersonAge person = new Person("Vincent", 33);
			IPersonAge proxy = AopAdapterCache.GetInstance<IPersonAge>((Person)person);

			Assert.AreEqual(person.Age, proxy.Age);
			person.Age = 14;
			Assert.AreEqual(person.Age, proxy.Age);
			proxy.Age = 5;
			Assert.AreEqual(person.Age, 5);
		}

		[Test]
		public void TestGrow()
		{
			IPerson person = new Person("Vincent", 33);
			IPerson proxy = AopAdapterCache.GetInstance<IPerson>((Person)person);

			Assert.AreEqual(person.Age, proxy.Age);
			person.GrowOlder();
			Assert.AreEqual(person.Age, proxy.Age);
			int olderOlder = person.Age + 1;
			proxy.GrowOlder();
			Assert.AreEqual(person.Age, olderOlder);
		}

		[Test]
		public void TestGetName()
		{
			IPerson person = new Person("Vincent", 33);
			IPerson proxy = AopAdapterCache.GetInstance<IPerson>((Person)person);

			Assert.AreEqual(person.Name, proxy.Name);
			Assert.AreEqual(person.GetName(), proxy.GetName());
		}

		[Test]
		public void TestSetAge()
		{
			IPerson person = new Person("Vincent", 33);
			IPerson proxy = AopAdapterCache.GetInstance<IPerson>((Person)person);

			Assert.AreEqual(person.Age, proxy.Age);
			Assert.AreEqual(14, proxy.SetAge(14));
			Assert.AreEqual(14, proxy.Age);
			Assert.AreEqual(person.Age, proxy.Age);
		}

		[Test]
		public void TestAgeOut()
		{
			IPerson person = new Person("Vincent", 33);
			IPersonAgeOut proxy = AopAdapterCache.GetInstance<IPersonAgeOut>((Person)person);
			int age;

			proxy.GetAgeOut(out age);
			Assert.AreEqual(person.Age, age);
		}

		[Test]
		public void TestNameRef()
		{
			IPerson person = new Person("Vincent", 33);
			IPersonNameRef proxy = AopAdapterCache.GetInstance<IPersonNameRef>((Person)person);
			string name = "Vincent-";
			int output = name.Length;

			proxy.GetNameRef(ref name);
			Assert.AreEqual(output.ToString(), name);
		}
	}
}