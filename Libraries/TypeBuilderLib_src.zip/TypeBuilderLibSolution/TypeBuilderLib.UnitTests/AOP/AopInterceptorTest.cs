using System;

using NUnit.Framework;

using TypeBuilderLib.AOP;

namespace TypeBuilderLib.UnitTests.AOP
{
	[TestFixture(Description = "Test an AOP adapter to see that it really forwards calls using interceptors.")]
	public class AopInterceptorTest : TestBase
	{
		#region Inner types
		public interface IPersonProperties
		{
			int Age { get;set;}
		}

		public interface IPersonMethods
		{
			int GetAge();

			void GetAge(string s);

			void GetAge(string s, out int age);

			void GetAgeRef(string s, ref int age);
		}

		public interface IPerson : IPersonProperties, IPersonMethods
		{
		}

		private class Person : IPerson
		{
			private int age;

			public Person(int age)
			{
				this.age = age;
			}

			#region IPersonProperties Members
			int IPersonProperties.Age
			{
				get { return age; }
				set { age = value; }
			}
			#endregion

			#region IPersonMethods Members
			int IPersonMethods.GetAge()
			{
				return age;
			}

			void IPersonMethods.GetAge(string s)
			{
			}

			void IPersonMethods.GetAge(string s, out int age)
			{
				age = this.age;
			}

			void IPersonMethods.GetAgeRef(string s, ref int age)
			{
				age += this.age + Convert.ToInt32(s);
			}
			#endregion
		}

		private class DetectInterceptor : IInterceptor
		{
			private bool intercepted = false;

			public bool Intercepted
			{
				get { return intercepted; }
			}

			#region IInterceptor Members
			object IInterceptor.InterceptCall(IMethodInvoker invoker)
			{
				intercepted = true;

				return invoker.Invoke();
			}
			#endregion
		}
		#endregion

		[Test]
		public void TestPropertyGet()
		{
			IPersonProperties person = new Person(33);
			DetectInterceptor interceptor = new DetectInterceptor();
			IPersonProperties proxy = AopAdapterCache.GetInstance<IPersonProperties>(person, interceptor);

			Assert.IsFalse(interceptor.Intercepted);

			//	Do a call to be intercepted
			int age = proxy.Age;

			Assert.AreEqual(person.Age, age);
			Assert.IsTrue(interceptor.Intercepted);
		}

		[Test]
		public void TestPropertySet()
		{
			IPersonProperties person = new Person(33);
			DetectInterceptor interceptor = new DetectInterceptor();
			IPersonProperties proxy = AopAdapterCache.GetInstance<IPersonProperties>(person, interceptor);

			Assert.IsFalse(interceptor.Intercepted);

			//	Do a call to be intercepted
			proxy.Age = 12;

			Assert.IsTrue(interceptor.Intercepted);
			Assert.AreEqual(person.Age, proxy.Age);
		}

		[Test]
		public void TestMethodParameterLess()
		{
			IPersonMethods person = new Person(33);
			DetectInterceptor interceptor = new DetectInterceptor();
			IPersonMethods proxy = AopAdapterCache.GetInstance(person, interceptor);

			Assert.IsFalse(interceptor.Intercepted);

			//	Do a call to be intercepted
			int age = proxy.GetAge();

			Assert.AreEqual(person.GetAge(), age);
			Assert.IsTrue(interceptor.Intercepted);
		}

		[Test]
		public void TestMethodOneParameter()
		{
			IPersonMethods person = new Person(33);
			DetectInterceptor interceptor = new DetectInterceptor();
			IPersonMethods proxy = AopAdapterCache.GetInstance(person, interceptor);

			Assert.IsFalse(interceptor.Intercepted);

			//	Do a call to be intercepted
			proxy.GetAge("Bla");

			Assert.IsTrue(interceptor.Intercepted);
		}

		[Test]
		public void TestMethodParameterOut()
		{
			IPersonMethods person = new Person(33);
			DetectInterceptor interceptor = new DetectInterceptor();
			IPersonMethods proxy = AopAdapterCache.GetInstance(person, interceptor);

			Assert.IsFalse(interceptor.Intercepted);

			//	Do a call to be intercepted
			int age, expectedAge;

			proxy.GetAge("Bla", out age);
			person.GetAge("bla", out expectedAge);

			Assert.AreEqual(expectedAge, age);
			Assert.IsTrue(interceptor.Intercepted);
		}

		[Test]
		public void TestMethodParameterRef()
		{
			IPersonMethods person = new Person(33);
			DetectInterceptor interceptor = new DetectInterceptor();
			IPersonMethods proxy = AopAdapterCache.GetInstance(person, interceptor);

			Assert.IsFalse(interceptor.Intercepted);

			//	Do a call to be intercepted
			int age = 12;
			int expectedAge = 12;

			proxy.GetAgeRef("64", ref age);
			person.GetAgeRef("64", ref expectedAge);

			Assert.AreEqual(expectedAge, age);
			Assert.IsTrue(interceptor.Intercepted);
		}
	}
}