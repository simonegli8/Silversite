using System;

using NUnit.Framework;

using TypeBuilderLib.AOP;
using System.Collections.Generic;

namespace TypeBuilderLib.UnitTests.AOP
{
	[TestFixture(Description = "Test the InterceptorGroup.")]
	public class InterceptorGroupTest
	{
		#region Inner types
		public interface IPerson
		{
			int Age { get;set;}
			int GetAge(out int age);
		}

		private class Person : IPerson
		{
			private int age;

			public Person(int age)
			{
				this.age = age;
			}

			#region IPerson Members
			int IPerson.Age
			{
				get { return age; }
				set { age = value; }
			}

			int IPerson.GetAge(out int age)
			{
				age = this.age;

				return this.age;
			}
			#endregion
		}

		private class DetectInterceptor : IInterceptor
		{
			private readonly int id;
			private readonly IList<int> detectedList;

			public DetectInterceptor(int id, IList<int> detectedList)
			{
				this.id = id;
				this.detectedList = detectedList;
			}

			#region IInterceptor Members
			object IInterceptor.InterceptCall(IMethodInvoker invoker)
			{
				detectedList.Add(id);

				return invoker.Invoke();
			}
			#endregion
		}
		#endregion

		[Test]
		public void TestPropertyGet()
		{
			IList<int> detectedList = new List<int>();
			IPerson person = new Person(33);
			DetectInterceptor interceptor1 = new DetectInterceptor(1, detectedList);
			DetectInterceptor interceptor2 = new DetectInterceptor(2, detectedList);
			InterceptorGroup group = new InterceptorGroup();
			IPerson proxy = AopAdapterCache.GetInstance<IPerson>(person, group);

			group.Interceptors = new IInterceptor[] { interceptor1, interceptor2};

			Assert.AreEqual(0, detectedList.Count);

			//	Do a call to be intercepted
			int age = proxy.Age;

			Assert.AreEqual(2, detectedList.Count);
			Assert.AreEqual(1, detectedList[0]);
			Assert.AreEqual(2, detectedList[1]);
		}

		[Test]
		public void TestPropertySet()
		{
			IList<int> detectedList = new List<int>();
			IPerson person = new Person(33);
			DetectInterceptor interceptor1 = new DetectInterceptor(1, detectedList);
			DetectInterceptor interceptor2 = new DetectInterceptor(2, detectedList);
			InterceptorGroup group = new InterceptorGroup();
			IPerson proxy = AopAdapterCache.GetInstance<IPerson>(person, group);

			group.Interceptors = new IInterceptor[] { interceptor1, interceptor2 };

			Assert.AreEqual(0, detectedList.Count);

			//	Do a call to be intercepted
			proxy.Age = 12;

			Assert.AreEqual(2, detectedList.Count);
			Assert.AreEqual(1, detectedList[0]);
			Assert.AreEqual(2, detectedList[1]);
		}

		[Test]
		public void TestMethod()
		{
			IList<int> detectedList = new List<int>();
			IPerson person = new Person(33);
			DetectInterceptor interceptor1 = new DetectInterceptor(1, detectedList);
			DetectInterceptor interceptor2 = new DetectInterceptor(2, detectedList);
			InterceptorGroup group = new InterceptorGroup();
			IPerson proxy = AopAdapterCache.GetInstance<IPerson>(person, group);

			group.Interceptors = new IInterceptor[] { interceptor1, interceptor2 };

			Assert.AreEqual(0, detectedList.Count);

			//	Do a call to be intercepted
			int age;
			proxy.GetAge(out age);

			Assert.AreEqual(2, detectedList.Count);
			Assert.AreEqual(1, detectedList[0]);
			Assert.AreEqual(2, detectedList[1]);
		}
	}
}