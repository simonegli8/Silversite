using System;

using NUnit.Framework;

using TypeBuilderLib.Buffering;
using TypeBuilderLib;

namespace TypeBuilderLib.UnitTests.Buffering
{
	[TestFixture(Description = "Test a buffered adapter to see that it really buffered original object.")]
	public class BufferedTest
	{
		#region Inner types
		public interface IPersonEmpty
		{
		}

		public interface IPersonName : IPersonEmpty
		{
			string Name { get;}
		}

		public interface IPersonAge : IPersonEmpty
		{
			int Age { get;set;}
		}

		public interface IPersonTwiceAge
		{
			int Age { get;}
		}

		public interface IPerson : IPersonName, IPersonAge, IPersonTwiceAge
		{
		}

		public class Person : IPerson
		{
			private readonly string name;
			private int age;

			public Person(string name, int age)
			{
				this.name = name;
				this.age = age;
			}

			#region IPersonName Members
			string IPersonName.Name
			{
				get { return name; }
			}
			#endregion

			#region IPersonAge Members
			int IPersonAge.Age
			{
				get { return age; }
				set { age = value; }
			}
			#endregion

			#region IPersonTwiceAge Members
			int IPersonTwiceAge.Age
			{
				get { return 2 * age; }
			}
			#endregion
		}
		#endregion

		[Test]
		public void TestCache()
		{
			Person person = new Person("Vincent", 33);
			IPersonName person1 = BufferingAdapterCache.GetReadOnlyInstance<IPersonName>(person);
			IPersonName person2 = BufferingAdapterCache.GetReadOnlyInstance<IPersonName>(person);

			TypeEmitterCache.FlushCache();

			IPersonName person3 = BufferingAdapterCache.GetReadOnlyInstance<IPersonName>(person);

			Assert.AreEqual(person1.GetType(), person2.GetType());
			Assert.AreNotEqual(person1.GetType(), person3.GetType());
		}

		[Test]
		public void TestName()
		{
			IPersonName person = new Person("Vincent", 33);
			IPersonName buffer = BufferingAdapterCache.GetReadOnlyInstance(person);

			Assert.AreEqual(person.Name, buffer.Name);
		}

		[Test]
		public void TestAge()
		{
			IPersonAge person = new Person("Vincent", 33);
			IPersonAge buffer = BufferingAdapterCache.GetReadOnlyInstance(person);

			Assert.AreEqual(person.Age, buffer.Age);
			++person.Age;
			Assert.AreNotEqual(person.Age, buffer.Age);
		}

		[Test]
		[ExpectedException(typeof(NotSupportedException))]
		public void TestSetInReadOnlyBuffer()
		{
			IPersonAge person = new Person("Vincent", 33);
			IPersonAge buffer = BufferingAdapterCache.GetReadOnlyInstance(person);

			Assert.AreEqual(person.Age, buffer.Age);
			++buffer.Age;
		}

		[Test]
		public void TestSetInWritableBuffer()
		{
			IPersonAge person = new Person("Vincent", 33);
			IPersonAge buffer = BufferingAdapterCache.GetWritableInstance(person);

			Assert.AreEqual(person.Age, buffer.Age);
			++buffer.Age;
			Assert.AreEqual(person.Age+1, buffer.Age);
		}

		[Test]
		public void TestPersonTwiceAge()
		{
			IPerson person = new Person("Vincent", 33);
			IPerson buffer = BufferingAdapterCache.GetReadOnlyInstance(person);

			IPersonAge personAge = person;
			IPersonAge bufferAge = buffer;

			Assert.AreEqual(personAge.Age, bufferAge.Age);

			IPersonTwiceAge personTwice = person;
			IPersonTwiceAge bufferTwice = buffer;

			Assert.AreEqual(personTwice.Age, bufferTwice.Age);
		}
	}
}