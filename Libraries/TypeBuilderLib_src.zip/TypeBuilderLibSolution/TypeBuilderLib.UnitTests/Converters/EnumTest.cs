using System;

using NUnit.Framework;

using TypeBuilderLib.Converters;

namespace TypeBuilderLib.UnitTests.Converters
{
	[TestFixture(Description="Testing the enumerator converters")]
	public class EnumTest
	{
		#region Inner Types
		public enum Colour
		{
			Red,
			Green,
			[EnumFieldLabel("Light Gray")]
			LightGray,
			[EnumFieldLabel("Dark Blue")]
			DarkBlue
		}
		#endregion

		[Test]
		public void EnumToString()
		{
			ITypeConverter<string, Colour> converter = new EnumConverter<Colour>();

			Assert.AreEqual(Colour.Red, converter.ConvertForward(Colour.Red.ToString()));
			Assert.AreEqual(Colour.Green, converter.ConvertForward(Colour.Green.ToString()));
			Assert.AreEqual(Colour.LightGray, converter.ConvertForward("Light Gray"));
			Assert.AreEqual(Colour.DarkBlue, converter.ConvertForward("Dark Blue"));
		}

		[Test]
		public void StringToEnum()
		{
			ITypeConverter<string, Colour> converter = new EnumConverter<Colour>();

			Assert.AreEqual(Colour.Red.ToString(), converter.ConvertBackward(Colour.Red));
			Assert.AreEqual(Colour.Green.ToString(), converter.ConvertBackward(Colour.Green));
			Assert.AreEqual("Light Gray", converter.ConvertBackward(Colour.LightGray));
			Assert.AreEqual("Dark Blue", converter.ConvertBackward(Colour.DarkBlue));
		}

		[Test]
		public void NullableEnumToString()
		{
			ITypeConverter<string, Colour?> converter = new NullableEnumConverter<Colour>();

			Assert.AreEqual(Colour.Red, converter.ConvertForward(Colour.Red.ToString()));
			Assert.AreEqual(Colour.Green, converter.ConvertForward(Colour.Green.ToString()));
			Assert.AreEqual(Colour.LightGray, converter.ConvertForward("Light Gray"));
			Assert.AreEqual(Colour.DarkBlue, converter.ConvertForward("Dark Blue"));
			Assert.AreEqual(new Colour?(), converter.ConvertForward(""));
			Assert.AreEqual(new Colour?(), converter.ConvertForward(null));
		}

		[Test]
		public void StringToNullableEnum()
		{
			ITypeConverter<string, Colour?> converter = new NullableEnumConverter<Colour>();

			Assert.AreEqual(Colour.Red.ToString(), converter.ConvertBackward(Colour.Red));
			Assert.AreEqual(Colour.Green.ToString(), converter.ConvertBackward(Colour.Green));
			Assert.AreEqual("Light Gray", converter.ConvertBackward(Colour.LightGray));
			Assert.AreEqual("Dark Blue", converter.ConvertBackward(Colour.DarkBlue));
			Assert.AreEqual("", converter.ConvertBackward(new Colour?()));
		}

		[Test]
		public void SpaceTest()
		{
			TypeConverterAttribute att = new TypeConverterAttribute(typeof(EnumConverter<Colour>));

			Assert.IsNotNull(att.TypeConverterType);

			att.ValidateTypeConverterType(typeof(string), typeof(Colour));

			ITypeConverter<string, Colour> converter =
				(ITypeConverter<string, Colour>)Activator.CreateInstance(att.TypeConverterType);

			Assert.AreEqual(Colour.Red, converter.ConvertForward(Colour.Red.ToString()));
			Assert.AreEqual(Colour.Green, converter.ConvertForward(Colour.Green.ToString()));
			Assert.AreEqual(Colour.LightGray, converter.ConvertForward("Light Gray"));
			Assert.AreEqual(Colour.DarkBlue, converter.ConvertForward("Dark Blue"));

			Assert.AreEqual(Colour.Red.ToString(), converter.ConvertBackward(Colour.Red));
			Assert.AreEqual(Colour.Green.ToString(), converter.ConvertBackward(Colour.Green));
			Assert.AreEqual("Light Gray", converter.ConvertBackward(Colour.LightGray));
			Assert.AreEqual("Dark Blue", converter.ConvertBackward(Colour.DarkBlue));
		}
	}
}