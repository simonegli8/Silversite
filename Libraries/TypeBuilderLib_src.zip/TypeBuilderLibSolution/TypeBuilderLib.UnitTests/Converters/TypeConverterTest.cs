using System;

using NUnit.Framework;

using TypeBuilderLib.Converters;

namespace TypeBuilderLib.UnitTests.Converters
{
	[TestFixture(Description = "Test the type converter attribute class.")]
	public class TypeConverterTest
	{
		#region Inner Types
		public enum Colour
		{
			Red,
			Green,
			[EnumFieldLabel("Light Gray")]
			LightGray,
			[EnumFieldLabel("Dark Blue")]
			DarkBlue
		}
		#endregion

		[Test]
		public void EmptyTest()
		{
			TypeConverterAttribute att = new TypeConverterAttribute();

			Assert.IsNull(att.TypeConverterType);

			att.ValidateTypeConverterType(typeof(string), typeof(string));
			att.ValidateTypeConverterType(typeof(int), typeof(int));
			att.ValidateTypeConverterType(typeof(int), typeof(object));
			try
			{
				att.ValidateTypeConverterType(typeof(object), typeof(int));
				Assert.Fail();
			}
			catch
			{
			}
		}

		[Test]
		public void CompositionTest()
		{
			TypeConverterAttribute att = new TypeConverterAttribute(
				typeof(CastFromObjectConverter<string>),
				typeof(EnumConverter<Colour>));

			Assert.IsNotNull(att.TypeConverterType);

			att.ValidateTypeConverterType(typeof(object), typeof(Colour));

			ITypeConverter<object, Colour> converter =
				(ITypeConverter<object, Colour>)Activator.CreateInstance(att.TypeConverterType);

			Assert.AreEqual(Colour.Red, converter.ConvertForward(Colour.Red.ToString()));
			Assert.AreEqual(Colour.Green, converter.ConvertForward(Colour.Green.ToString()));
			Assert.AreEqual(Colour.LightGray, converter.ConvertForward("Light Gray"));
			Assert.AreEqual(Colour.DarkBlue, converter.ConvertForward("Dark Blue"));

			Assert.AreEqual(Colour.Red.ToString(), converter.ConvertBackward(Colour.Red));
			Assert.AreEqual(Colour.Green.ToString(), converter.ConvertBackward(Colour.Green));
			Assert.AreEqual("Light Gray", converter.ConvertBackward(Colour.LightGray));
			Assert.AreEqual("Dark Blue", converter.ConvertBackward(Colour.DarkBlue));
		}
	}
}