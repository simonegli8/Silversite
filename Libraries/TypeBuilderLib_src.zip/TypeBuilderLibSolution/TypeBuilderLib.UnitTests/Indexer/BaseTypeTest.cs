using System;
using System.Data;

using NUnit.Framework;

using TypeBuilderLib.Indexer;

namespace TypeBuilderLib.UnitTests.Indexer
{
	[TestFixture(Description = "Test a data row adapter with a custom base type.")]
	public class BaseTypeTest
	{
		#region Inner types
		public interface IPersonName
		{
			string Name { get;set;}
		}

		public abstract class TrivialBase<INDEX> : IndexerAdapterBase<INDEX>
		{
		}

		public interface IUpdatablePersonName : IPersonName
		{
			[UseBase]
			void Update();

			[UseBase(MemberName = "ProtectUpdate")]
			void UpdateProtected();
		}

		public abstract class UpdatableBase<INDEX> : IndexerAdapterBase<INDEX>
		{
			private bool hasUpdatedPublic = false;
			private bool hasUpdatedProtected = false;

			public bool HasUpdatedPublic
			{
				get { return hasUpdatedPublic; }
			}

			public bool HasUpdatedProtected
			{
				get { return hasUpdatedProtected; }
			}

			public void Update()
			{
				hasUpdatedPublic = true;
			}

			protected void ProtectUpdate()
			{
				hasUpdatedProtected = true;
			}
		}

		public interface IPersonNameAndNumber : IPersonName
		{
			[UseBase]
			int Number { get;set;}

			[UseBase(MemberName = "ProtectNumber")]
			int NumberProtected { get;set;}
		}

		public abstract class NumberBase<INDEX> : IndexerAdapterBase<INDEX>
		{
			private int number = 10;
			private bool hasNumberPublic = false;
			private bool hasNumberProtected = false;

			public bool HasNumberPublic
			{
				get { return hasNumberPublic; }
			}

			public bool HasNumberProtected
			{
				get { return hasNumberProtected; }
			}

			public int Number
			{
				get { return number; }
				set
				{
					number = value;
					hasNumberPublic = true;
				}
			}

			protected int ProtectNumber
			{
				get { return Number + 1; }
				set
				{
					number = value-1;
					hasNumberProtected = true;
				}
			}
		}
		#endregion

		private DataTable table;

		[SetUp]
		public void Setup()
		{
			table = new DataTable();

			table.Columns.Add("Name", typeof(string));
			table.Columns.Add("Age", typeof(int));
		}

		[Test]
		public void TestBase()
		{
			DataRow row = table.Rows.Add("Vincent", 33);
			IPersonName person =
				IndexerAdapterCache<IPersonName>.GetInstance(row, typeof(TrivialBase<DataRow>), null);

			Assert.AreEqual(row["Name"].ToString(), person.Name);

			person.Name = "Philippe";

			Assert.AreEqual(row["Name"].ToString(), person.Name);
		}

		[Test]
		public void TestUpdate()
		{
			DataRow row = table.Rows.Add("Vincent", 33);
			IUpdatablePersonName person =
				IndexerAdapterCache<IUpdatablePersonName>.GetInstance(row, typeof(UpdatableBase<DataRow>), null);
			UpdatableBase<DataRow> updatable = (UpdatableBase<DataRow>)person;

			Assert.AreEqual(row["Name"].ToString(), person.Name);

			person.Name = "Philippe";

			Assert.AreEqual(row["Name"].ToString(), person.Name);

			Assert.IsFalse(updatable.HasUpdatedPublic);
			person.Update();
			Assert.IsTrue(updatable.HasUpdatedPublic);

			Assert.IsFalse(updatable.HasUpdatedProtected);
			person.UpdateProtected();
			Assert.IsTrue(updatable.HasUpdatedProtected);
		}

		[Test]
		public void TestNumber()
		{
			DataRow row = table.Rows.Add("Vincent", 33);
			IPersonNameAndNumber person =
				IndexerAdapterCache<IPersonNameAndNumber>.GetInstance(row, typeof(NumberBase<DataRow>), null);
			NumberBase<DataRow> numberable = (NumberBase<DataRow>)person;

			Assert.AreEqual(row["Name"].ToString(), person.Name);

			person.Name = "Philippe";

			Assert.AreEqual(row["Name"].ToString(), person.Name);

			Assert.AreEqual(numberable.Number, person.Number);
			Assert.AreEqual(numberable.Number + 1, person.NumberProtected);

			Assert.IsFalse(numberable.HasNumberPublic);
			person.Number = 1;
			Assert.IsTrue(numberable.HasNumberPublic);

			Assert.IsFalse(numberable.HasNumberProtected);
			person.NumberProtected = 1;
			Assert.IsTrue(numberable.HasNumberProtected);
		}
	}
}