using System;
using System.Data;

using NUnit.Framework;

using TypeBuilderLib;
using TypeBuilderLib.Indexer;

namespace TypeBuilderLib.UnitTests.Indexer
{
	[TestFixture(Description = "Test a data row adapter to see that it really forwards calls.")]
	public class DataRowAdapterTest : TestBase
	{
		#region Inner types
		public interface IPersonEmpty
		{
		}

		public interface IPersonName : IPersonEmpty
		{
			string Name { get;}
		}

		public interface IPersonAge : IPersonEmpty
		{
			int Age { get;set;}
		}

		public interface IPersonMappedName : IPersonEmpty
		{
			[IndexerMapping("Name")]
			string MyName { get;}
		}

		public interface IPerson : IPersonName, IPersonAge
		{
		}
		#endregion

		private DataTable table;

		[SetUp]
		public void Setup()
		{
			table = new DataTable();

			table.Columns.Add("Name", typeof(string));
			table.Columns.Add("Age", typeof(int));
		}

		[Test]
		public void TestCache()
		{
			DataRow row = table.Rows.Add("Vincent", 33);
			IPersonName person1 = IndexerAdapterCache<IPersonName>.GetInstance(row);
			IPersonName person2 = IndexerAdapterCache<IPersonName>.GetInstance(row);

			TypeEmitterCache.FlushCache();

			IPersonName person3 = IndexerAdapterCache<IPersonName>.GetInstance(row);

			Assert.AreEqual(person1.GetType(), person2.GetType());
			Assert.AreNotEqual(person1.GetType(), person3.GetType());
		}

		[Test]
		public void TestEmpty()
		{
			DataRow row = table.Rows.Add("Vincent", 33);
			IPersonEmpty person = IndexerAdapterCache<IPersonEmpty>.GetInstance(row);
		}

		[Test]
		public void TestGetName()
		{
			DataRow row = table.Rows.Add("Vincent", 33);
			IPersonName person = IndexerAdapterCache<IPersonName>.GetInstance(row);

			Assert.AreEqual(row["Name"], person.Name);
		}

		[Test]
		public void TestGetAge()
		{
			DataRow row = table.Rows.Add("Vincent", 33);
			IPersonAge person = IndexerAdapterCache<IPersonAge>.GetInstance(row);

			Assert.AreEqual(row["Age"], person.Age);
		}

		[Test]
		public void TestSetAge()
		{
			DataRow row = table.Rows.Add("Vincent", 33);
			IPersonAge person = IndexerAdapterCache<IPersonAge>.GetInstance(row);

			Assert.AreEqual(row["Age"], person.Age);
			row["Age"] = 14;
			Assert.AreEqual(row["Age"], person.Age);
			person.Age = 5;
			Assert.AreEqual(row["Age"], 5);
		}

		[Test]
		public void TestPerson()
		{
			DataRow row = table.Rows.Add("Vincent", 33);
			IPerson person = IndexerAdapterCache<IPerson>.GetInstance(row);

			Assert.AreEqual(row["Age"], person.Age);
			row["Age"] = 14;
			Assert.AreEqual(row["Age"], person.Age);
			person.Age = 5;
			Assert.AreEqual(row["Age"], 5);
			Assert.AreEqual(row["Name"], person.Name);
		}

		[Test]
		public void TestGetNameMapping()
		{
			DataRow row = table.Rows.Add("Vincent", 33);
			IPersonMappedName person = IndexerAdapterCache<IPersonMappedName>.GetInstance(row);

			Assert.AreEqual(row["Name"], person.MyName);
		}
	}
}