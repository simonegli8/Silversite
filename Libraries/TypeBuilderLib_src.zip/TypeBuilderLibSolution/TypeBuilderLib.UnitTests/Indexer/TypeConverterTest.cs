using System;
using System.Data;

using NUnit.Framework;

using TypeBuilderLib.Converters;
using TypeBuilderLib.Indexer;

namespace TypeBuilderLib.UnitTests.Indexer
{
	[TestFixture(Description = "Test a data row adapter with type converter.")]
	public class TypeConverterTest
	{
		#region Inner types
		public class CapitalConverter : ITypeConverter<object, string>
		{
			#region ITypeConverter<object, string> Members
			string ITypeConverter<object, string>.ConvertForward(object from)
			{
				return from.ToString().ToUpper();
			}

			object ITypeConverter<object, string>.ConvertBackward(string to)
			{
				return to.ToLower();
			}
			#endregion
		}

		public interface IPersonName
		{
			[TypeConverter(typeof(CastFromObjectConverter<string>))]
			string Name { get;set;}
		}

		public interface IPersonCapitalName
		{
			[TypeConverter(typeof(CapitalConverter))]
			string Name { get;set;}
		}

		public interface IContextPersonCapitalName
		{
			[TypeConverter(null, Context=12)]
			[TypeConverter(typeof(CapitalConverter))]
			string Name { get;set;}
		}

		public interface IPersonAge
		{
			[TypeConverter(typeof(DBNullableTypeConverter<int>))]
			int? Age { get;set;}
		}
		#endregion

		private DataTable table;

		[SetUp]
		public void Setup()
		{
			table = new DataTable();

			table.Columns.Add("Name", typeof(string));
			table.Columns.Add("Age", typeof(int));
		}

		[Test]
		public void TestCast()
		{
			DataRow row = table.Rows.Add("Vincent", 33);
			IPersonName person = IndexerAdapterCache<IPersonName>.GetInstance(row);

			Assert.AreEqual(row["Name"], person.Name);

			person.Name = "Philippe";

			Assert.AreEqual(row["Name"], person.Name);
		}

		[Test]
		public void TestCapital()
		{
			DataRow row = table.Rows.Add("Vincent", 33);
			IPersonCapitalName person = IndexerAdapterCache<IPersonCapitalName>.GetInstance(row);

			Assert.AreEqual(row["Name"].ToString().ToUpper(), person.Name);

			person.Name = "Philippe";

			Assert.AreEqual(row["Name"].ToString().ToUpper(), person.Name);
		}

		[Test]
		public void TestContextCapital()
		{
			DataRow row = table.Rows.Add("Vincent", 33);
			IContextPersonCapitalName personCapital = IndexerAdapterCache<IContextPersonCapitalName>.GetInstance(row);
			IContextPersonCapitalName personNormal = IndexerAdapterCache<IContextPersonCapitalName>.GetInstance(row, 12);

			Assert.AreEqual(row["Name"].ToString().ToUpper(), personCapital.Name);
			Assert.AreEqual(row["Name"].ToString(), personNormal.Name);

			personCapital.Name = "Philippe";

			Assert.AreEqual(row["Name"].ToString().ToUpper(), personCapital.Name);
			Assert.AreEqual(row["Name"].ToString(), personNormal.Name);
		}

		[Test]
		public void TestNull()
		{
			DataRow row = table.Rows.Add("Vincent", null);
			IPersonAge person = IndexerAdapterCache<IPersonAge>.GetInstance(row);

			Assert.IsFalse(person.Age.HasValue);

			person.Age = 33;

			Assert.AreEqual(row["Age"], person.Age);

			person.Age = null;

			Assert.IsFalse(person.Age.HasValue);
		}
	}
}