using System;

using NUnit.Framework;

using TypeBuilderLib;
using TypeBuilderLib.Mask;

namespace TypeBuilderLib.UnitTests.Mask
{
	[TestFixture(Description = "Test an data row adapter to see that it really forwards calls.")]
	public class MaskAdapterTest : TestBase
	{
		#region Inner types
		public interface IPersonEmpty
		{
		}

		public interface IPersonName : IPersonEmpty
		{
			string Name { get;}
		}

		public interface IPersonAge : IPersonEmpty
		{
			int Age { get;set;}
		}

		public interface IPersonMethod : IPersonEmpty
		{
			void GrowAge(int offset);
		}

		public interface IPerson : IPersonName, IPersonAge, IPersonMethod
		{
		}

		public class Person
		{
			private readonly string name;
			private int age;

			public Person(string name, int age)
			{
				this.name = name;
				this.age = age;
			}

			public string Name
			{
				get { return name; }
			}

			public int Age
			{
				get { return age; }
				set { age = value; }
			}

			public void GrowAge(int offset)
			{
				age += offset;
			}
		}
		#endregion

		[Test]
		public void TestCache()
		{
			Person person = new Person("Vincent", 33);
			IPersonName person1 = MaskAdapterCache<IPersonName>.GetInstance<Person>(person);
			IPersonName person2 = MaskAdapterCache<IPersonName>.GetInstance<Person>(person);

			TypeEmitterCache.FlushCache();

			IPersonName person3 = MaskAdapterCache<IPersonName>.GetInstance<Person>(person);

			Assert.AreEqual(person1.GetType(), person2.GetType());
			Assert.AreNotEqual(person1.GetType(), person3.GetType());
		}

		[Test]
		public void TestEmpty()
		{
			Person person = new Person("Vincent", 33);
			IPersonEmpty personEmpty = MaskAdapterCache<IPersonEmpty>.GetInstance<Person>(person);
		}

		[Test]
		public void TestGetName()
		{
			Person person = new Person("Vincent", 33);
			IPersonName personName = MaskAdapterCache<IPersonName>.GetInstance<Person>(person);

			Assert.AreEqual(person.Name, personName.Name);
		}

		[Test]
		public void TestSetAge()
		{
			Person person = new Person("Vincent", 33);
			IPersonAge personAge = MaskAdapterCache <IPersonAge>.GetInstance<Person>(person);

			Assert.AreEqual(person.Age, personAge.Age);
			person.Age = 14;
			Assert.AreEqual(person.Age, personAge.Age);
			personAge.Age = 5;
			Assert.AreEqual(5, person.Age);
		}

		[Test]
		public void TestPerson()
		{
			Person person = new Person("Vincent", 33);
			IPerson personProxy = MaskAdapterCache<IPerson>.GetInstance<Person>(person);

			Assert.AreEqual(person.Age, personProxy.Age);
			personProxy.GrowAge(87);
			Assert.AreEqual(person.Age, personProxy.Age);
		}
	}
}