using System;

using NUnit.Framework;

using TypeBuilderLib;

namespace TypeBuilderLib.UnitTests
{
	/// <summary>Base class for tests.  Encapsulates setups.</summary>
	public abstract class TestBase
	{
		[SetUp]
		private void SetUp()
		{
			//	Flush the cache to always have fresh types
			TypeEmitterCache.FlushCache();
		}
	}
}