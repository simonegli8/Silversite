using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;

namespace TypeBuilderLib.AOP
{
	/// <summary>Base class for AOP adapters.</summary>
	/// <remarks>This class is typically derived by dynamically emitted classes.</remarks>
	/// <typeparam name="I"></typeparam>
	public abstract class AopAdapterBase<I> where I : class //	Should be interface, but there isn't such a constraint
	{
		private readonly IDictionary<string, Type> interfaceTypeMap = new Dictionary<string, Type>();
		private I adapted;
		private IInterceptor interceptor;
		
		/// <summary>Initialize internal map.</summary>
		public AopAdapterBase()
		{
			List<Type> interfaceTypes = new List<Type>();

			interfaceTypes.Add(typeof(I));
			interfaceTypes.AddRange(typeof(I).GetInterfaces());

			foreach (Type type in interfaceTypes)
			{
				interfaceTypeMap.Add(type.FullName, type);
			}
		}

		/// <summary>Exposes the adapted object.</summary>
		/// <remarks>This must be set before any call can be done.</remarks>
		public I Adapted
		{
			get { return adapted; }
			set { adapted = value; }
		}

		/// <summary>Exposes the interceptor object.</summary>
		/// <remarks>If not set, a default implementation takes place.</remarks>
		public IInterceptor Interceptor
		{
			get { return interceptor; }
			set { interceptor = value; }
		}

		/// <summary>
		/// Returns a non-<c>null</c> <see cref="IInterceptor"/>.
		/// If <see cref="Interceptor"/> is <c>null</c>, it returns an instance of
		/// <see cref="DefaultInterceptor"/>.
		/// </summary>
		protected IInterceptor NonNullMethodInterceptor
		{
			get
			{
				return Interceptor == null ? new DefaultInterceptor() : Interceptor;
			}
		}

		/// <summary>Call the interceptor for a given method.</summary>
		/// <remarks>Used by emitted code, simpler than emitting.</remarks>
		/// <param name="proxyMethod"></param>
		/// <param name="parameters"></param>
		/// <returns></returns>
		protected object CallInterceptor(MethodBase proxyMethod, params object[] parameters)
		{
			MethodInfo interfaceMethod = GetInterfaceMethod(proxyMethod);
			IMethodInvoker invoker = new MethodInvoker(Adapted, parameters, interfaceMethod);

			return NonNullMethodInterceptor.InterceptCall(invoker);
		}

		/// <summary>Dereference a reference.</summary>
		/// <remarks>Used by emitted code, simpler than emitting.</remarks>
		/// <typeparam name="T"></typeparam>
		/// <param name="reference"></param>
		/// <returns></returns>
		protected object GetReferenceValue<T>(ref T reference)
		{
			return reference;
		}

		/// <summary>Boxes a value.</summary>
		/// <remarks>Used by emitted code, simpler than emitting.</remarks>
		/// <typeparam name="T"></typeparam>
		/// <param name="reference"></param>
		/// <returns></returns>
		protected object GetValue<T>(T reference)
		{
			return reference;
		}

		/// <summary>Stores a value in a reference.</summary>
		/// <remarks>Used by emitted code, simpler than emitting.</remarks>
		/// <typeparam name="T"></typeparam>
		/// <param name="reference"></param>
		/// <param name="value"></param>
		protected void StoreInReference<T>(ref T reference, object value)
		{
			reference = (T)value;
		}

		/// <summary>Returns the <see cref="MethodInfo"/> of a the interface from a proxy method.</summary>
		/// <param name="proxyMethod"></param>
		/// <returns></returns>
		private MethodInfo GetInterfaceMethod(MethodBase proxyMethod)
		{
			string proxyMethodName = proxyMethod.Name;
			int lastDot = proxyMethodName.LastIndexOf('.');
			string interfaceTypeName = proxyMethodName.Substring(0, lastDot);
			string methodName = proxyMethod.Name.Substring(
				lastDot + 1,
				proxyMethodName.Length - lastDot - 1);
			Type interfaceType = interfaceTypeMap[interfaceTypeName];
			Type[] parameterTypes = Array.ConvertAll<ParameterInfo, Type>(
				proxyMethod.GetParameters(),
				delegate(ParameterInfo info) { return info.ParameterType; });
			MethodInfo method = interfaceType.GetMethod(methodName, parameterTypes);

			return method;
		}
	}
}