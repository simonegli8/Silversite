using System;
using System.Data;

using TypeBuilderLib;

namespace TypeBuilderLib.AOP
{
	/// <summary>Cache for AOP adapter emitted on the fly in an application.</summary>
	/// <remarks>
	/// <para>Reference implementation.</para>
	/// <para>This class acts as a facade to <see cref="TypeEmitterCache"/>.</para>
	/// <para>
	/// AOP stands for Aspect Oriented Programming.  It is implemented here by adapting a target
	/// with the same interface exposed by the adapted and putting an interceptor between the calls
	/// to the adapter and the calls to the underlying adapted.
	/// </para>
	/// <para>
	/// This is very usefull when we want to monitor method calls (e.g. logging), when we want to add
	/// a behavior to method calls (e.g. exception handling, transaction) or when we want to do something
	/// before or after the method call (e.g. authentication).
	/// </para>
	/// </remarks>
	public static class AopAdapterCache
	{
		/// <summary>
		/// Returns an instance of an adapter adapting an adapted with an interceptor intercepting
		/// the calls.
		/// </summary>
		/// <typeparam name="I"></typeparam>
		/// <param name="adapted"></param>
		/// <param name="interceptor"></param>
		/// <returns></returns>
		public static I GetInstance<I>(I adapted, IInterceptor interceptor) where I : class //	Should be interface, but there isn't such a constraint
		{
			AopTypeEmitter buildSpecifier = new AopTypeEmitter();

			buildSpecifier.InterfaceType = typeof(I);

			object adapter = TypeEmitterCache.GetInstance(buildSpecifier);
			I adapterInterface = adapter as I;
			AopAdapterBase<I> adapterBase = (AopAdapterBase<I>)adapter;

			if (adapterBase == null)
			{
				throw new TypeEmitterException(string.Format(
					"{0} doesn't derive from {1}",
					adapter.GetType().FullName,
					typeof(AopAdapterBase<I>).Name));
			}
			if (adapterInterface == null)
			{
				throw new TypeEmitterException(string.Format(
					"{0} doesn't implement {1}",
					adapterBase.GetType().FullName,
					typeof(I).FullName));
			}
			adapterBase.Adapted = adapted;
			adapterBase.Interceptor = interceptor;

			return adapterInterface;
		}

		/// <summary>Returns an instance of an adapter adapting an adapted without interceptors.</summary>
		/// <typeparam name="I"></typeparam>
		/// <param name="adapted"></param>
		/// <param name="interceptor"></param>
		/// <returns></returns>
		public static I GetInstance<I>(I adapted) where I : class //	Should be interface, but there isn't such a constraint
		{
			return GetInstance<I>(adapted, null);
		}
	}
}