using System;
using System.Reflection;
using System.Reflection.Emit;

using TypeBuilderLib;

namespace TypeBuilderLib.AOP
{
	/// <summary>Specifies how to build an adapter for AOP.</summary>
	/// <remarks>
	/// <para>
	/// AOP stands for Aspect Oriented Programming.  It is implemented here by adapting a target
	/// with the same interface exposed by the adapted and putting an interceptor between the calls
	/// to the adapter and the calls to the underlying adapted.
	/// </para>
	/// <para>
	/// This is very usefull when we want to monitor method calls (e.g. logging), when we want to add
	/// a behavior to method calls (e.g. exception handling, transaction) or when we want to do something
	/// before or after the method call (e.g. authentication).
	/// </para>
	/// </remarks>
	public class AopTypeEmitter : TypeEmitterOneInterfaceBase
	{
		#region object methods
		/// <summary>Returns <c>true</c> iif <paramref name="obj"/> if equal to this object.</summary>
		/// <param name="obj"></param>
		/// <returns></returns>
		public override bool Equals(object obj)
		{
			AopTypeEmitter typeEmitter = obj as AopTypeEmitter;

			return typeEmitter != null && base.Equals(obj);
		}

		/// <summary>Computes the hash code of all object's components.</summary>
		/// <returns></returns>
		public override int GetHashCode()
		{
			return base.GetHashCode();
		}

		/// <summary>Returns a <see cref="string"/> representation of this object.</summary>
		/// <returns></returns>
		public override string ToString()
		{
			return string.Format(
				"{0}<{1}>",
				typeof(AopTypeEmitter).Name,
				InterfaceType.FullName);
		}
		#endregion

		/// <summary>Returns <see cref="AopAdapterBase"/> type.</summary>
		protected override Type BaseType
		{
			get
			{
				Type genericBaseType = typeof(AopAdapterBase<>);
				Type baseType = genericBaseType.MakeGenericType(InterfaceType);

				return baseType;
			}
		}

		/// <summary>Implements a simple forward to the underlying adapted.</summary>
		/// <param name="propertyInfo"></param>
		/// <param name="ilGenerator"></param>
		/// <param name="typeBuilder"></param>
		protected override void EmitGetMethod(
			PropertyInfo propertyInfo,
			ILGenerator ilGenerator,
			TypeBuilder typeBuilder)
		{
			MethodInfo method = propertyInfo.GetGetMethod();

			EmitMethod(method, ilGenerator, typeBuilder);
		}

		/// <summary>Implements a simple forward to the underlying adapted.</summary>
		/// <param name="propertyInfo"></param>
		/// <param name="ilGenerator"></param>
		/// <param name="typeBuilder"></param>
		protected override void EmitSetMethod(
			PropertyInfo propertyInfo,
			ILGenerator ilGenerator,
			TypeBuilder typeBuilder)
		{
			MethodInfo method = propertyInfo.GetSetMethod();

			EmitMethod(method, ilGenerator, typeBuilder);
		}

		/// <summary>Implements a simple forward to the underlying adapted.</summary>
		/// <param name="methodInfo"></param>
		/// <param name="ilGenerator"></param>
		/// <param name="typeBuilder"></param>
		protected override void EmitMethod(
			MethodInfo methodInfo,
			ILGenerator ilGenerator,
			TypeBuilder typeBuilder)
		{
			//	Put the dimension of the parameter array on the stack
			ilGenerator.Emit(OpCodes.Ldc_I4, methodInfo.GetParameters().Length);
			//	Create an object array
			ilGenerator.Emit(OpCodes.Newarr, typeof(object));

			LocalBuilder arrayLocal = EmitMethodParameterArray(methodInfo, ilGenerator);

			//	Put this on the stack
			ilGenerator.Emit(OpCodes.Ldarg_0);
			//	Call GetCurrentMethod on MethodBase
			ilGenerator.Emit(OpCodes.Call, typeof(MethodBase).GetMethod("GetCurrentMethod"));
			//	Push the array on the stack
			ilGenerator.Emit(OpCodes.Ldloc, arrayLocal);
			//	Call the protected CallInterceptor method
			ilGenerator.Emit(
				OpCodes.Call,
				BaseType.GetMethod("CallInterceptor", BindingFlags.Instance | BindingFlags.NonPublic));
			if (methodInfo.ReturnType == typeof(void))
			{	//	Remove the null returned value
				ilGenerator.Emit(OpCodes.Pop);
			}
			else if (methodInfo.ReturnType.IsValueType)
			{	//	Unbox the value
				ilGenerator.Emit(OpCodes.Unbox_Any, methodInfo.ReturnType);
			}
			GetOutValues(methodInfo, ilGenerator, arrayLocal);

			//	Return
			ilGenerator.Emit(OpCodes.Ret);
		}

		private void GetOutValues(
			MethodInfo methodInfo,
			ILGenerator ilGenerator,
			LocalBuilder arrayLocal)
		{
			//	Gather back values of out and ref parameters
			for (int i = 0; i != methodInfo.GetParameters().Length; ++i)
			{
				ParameterInfo parameter = methodInfo.GetParameters()[i];

				if (parameter.IsOut || parameter.ParameterType.IsByRef)
				{
					//	Put this on the stack
					ilGenerator.Emit(OpCodes.Ldarg_0);
					//	Push the argument on the stack
					ilGenerator.Emit(OpCodes.Ldarg, i + 1);
					//	Push the array on the stack
					ilGenerator.Emit(OpCodes.Ldloc, arrayLocal);
					//	Push the array index on the stack
					ilGenerator.Emit(OpCodes.Ldc_I4, i);
					//	Push the array element value on the stack
					ilGenerator.Emit(OpCodes.Ldelem, typeof(object));
					//	Call StoreInReference
					MethodInfo genericMethod = BaseType.GetMethod(
						"StoreInReference",
						BindingFlags.Instance | BindingFlags.NonPublic);
					MethodInfo method =
						genericMethod.MakeGenericMethod(parameter.ParameterType.GetElementType());

					ilGenerator.Emit(OpCodes.Call, method);
				}
			}
		}

		private LocalBuilder EmitMethodParameterArray(
			MethodInfo methodInfo,
			ILGenerator ilGenerator)
		{
			//	Declare a local variTypeBuilderLibe for the array
			LocalBuilder arrayLocal = ilGenerator.DeclareLocal(typeof(object[]));

			//	Stores the array in the local variTypeBuilderLibe
			ilGenerator.Emit(OpCodes.Stloc, arrayLocal);
			//	Populate the parameter array
			for (int i = 0; i != methodInfo.GetParameters().Length; ++i)
			{
				ParameterInfo parameter = methodInfo.GetParameters()[i];

				//	Push the array on the stack
				ilGenerator.Emit(OpCodes.Ldloc, arrayLocal);
				//	Push the array index on the stack
				ilGenerator.Emit(OpCodes.Ldc_I4, i);
				if (parameter.IsOut)
				{	//	Push null on the stack (an out param shouldn't be used)
					ilGenerator.Emit(OpCodes.Ldnull);
				}
				else
				{	//	Put this on the stack
					ilGenerator.Emit(OpCodes.Ldarg_0);
					//	Push the argument of the current index on the stack
					//	The index 0 is 'this', so we need to offset by 1
					ilGenerator.Emit(OpCodes.Ldarg, i + 1);
					if (parameter.ParameterType.IsByRef)
					{	//	Call GetReferenceValue
						MethodInfo genericMethod = BaseType.GetMethod(
							"GetReferenceValue",
							BindingFlags.Instance | BindingFlags.NonPublic);
						MethodInfo method =
							genericMethod.MakeGenericMethod(parameter.ParameterType.GetElementType());

						ilGenerator.Emit(OpCodes.Call, method);
					}
					else
					{	//	Call GetValue
						MethodInfo genericMethod = BaseType.GetMethod(
							"GetValue",
							BindingFlags.Instance | BindingFlags.NonPublic);
						MethodInfo method =
							genericMethod.MakeGenericMethod(parameter.ParameterType);

						ilGenerator.Emit(OpCodes.Call, method);
					}
				}
				//	Assign the parameter value to the array
				ilGenerator.Emit(OpCodes.Stelem, typeof(object));
			}

			return arrayLocal;
		}
	}
}