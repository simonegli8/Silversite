using System;

namespace TypeBuilderLib.AOP
{
	/// <summary>
	/// Default implementation of <see cref="IInterceptor"/>.  Simply calls the caller
	/// without any extra operations.
	/// </summary>
	internal class DefaultInterceptor : IInterceptor
	{
		#region IInterceptor Members
		object IInterceptor.InterceptCall(IMethodInvoker methodInvoker)
		{
			return methodInvoker.Invoke();
		}
		#endregion
	}
}