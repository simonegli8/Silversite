using System;

namespace TypeBuilderLib.AOP
{
	/// <summary>Represent an object TypeBuilderLibe to intercept methods (or properties) calls.</summary>
	public interface IInterceptor
	{
		/// <summary>Call interception.</summary>
		/// <param name="methodInvoker"></param>
		/// <returns></returns>
		object InterceptCall(IMethodInvoker methodInvoker);
	}
}