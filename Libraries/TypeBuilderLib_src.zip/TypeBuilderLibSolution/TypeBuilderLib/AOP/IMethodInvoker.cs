using System;
using System.Reflection;

namespace TypeBuilderLib.AOP
{
	/// <summary>Represents the object invoking the underlying method.</summary>
	public interface IMethodInvoker
	{
		/// <summary><see cref="MethodBase"/> of the underlying method.</summary>
		MethodBase Method { get;}

		/// <summary>Collection of parameters passed to the method.</summary>
		/// <remarks>Objects from the collection can be replaced at will before the invoke take place.</remarks>
		object[] Parameters { get;}

		/// <summary>Invoke the underlying method.</summary>
		/// <returns></returns>
		object Invoke();
	}
}