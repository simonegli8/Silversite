using System;
using System.Reflection;

namespace TypeBuilderLib.AOP
{
	/// <summary>Implementation of <see cref="IMethodInvoker"/>.</summary>
	internal class MethodInvoker : IMethodInvoker
	{
		private readonly object obj;
		private readonly object[] parameters;
		private readonly MethodBase method;

		/// <summary>Construct a method invoker.</summary>
		/// <param name="obj"></param>
		/// <param name="parameters"></param>
		/// <param name="method"></param>
		public MethodInvoker(object obj, object[] parameters, MethodBase method)
		{
			this.obj = obj;
			this.parameters = parameters;
			this.method = method;
		}

		#region IMethodInvoker Members
		MethodBase IMethodInvoker.Method
		{
			get { return method; }
		}

		object[] IMethodInvoker.Parameters
		{
			get { return parameters; }
		}

		object IMethodInvoker.Invoke()
		{
			return method.Invoke(obj, parameters);
		}
		#endregion
	}
}