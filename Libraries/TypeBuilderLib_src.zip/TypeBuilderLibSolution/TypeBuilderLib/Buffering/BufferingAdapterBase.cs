using System;
using System.Data;

namespace TypeBuilderLib.Buffering
{
	/// <summary>Base class for buffering adapters.</summary>
	/// <remarks>This class is typically derived by dynamically emitted classes.</remarks>
	/// <typeparam name="I"></typeparam>
	public abstract class BufferingAdapterBase<I> where I : class
	{
		/// <summary>Buffers a given instance.</summary>
		/// <param name="buffered"></param>
		public void Buffer(I buffered)
		{
			BufferCopy(buffered);
		}

		/// <summary>Implemented by emitted class.</summary>
		/// <remarks>Must perform the copy into emitted fields.</remarks>
		/// <param name="buffered"></param>
		protected abstract void BufferCopy(I buffered);
	}
}