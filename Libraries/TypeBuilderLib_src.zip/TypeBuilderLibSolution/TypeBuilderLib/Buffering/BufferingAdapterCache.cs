using System;
using System.Data;

using TypeBuilderLib;

namespace TypeBuilderLib.Buffering
{
	/// <summary>Cache for buffering adapters emitted on the fly in an application.</summary>
	/// <remarks>
	/// <para>Reference implementation.</para>
	/// <para>This class acts as a facade to <see cref="TypeEmitterCache"/>.</para>
	/// <para>
	/// This is useful when we want to have a snapshot of an object without keeping an object around.
	/// For instance, we might have an object that is expensive or impossible to keep around, since it
	/// holds a connection to a store.
	/// </para>
	/// </remarks>
	public static class BufferingAdapterCache
	{
		/// <summary>
		/// Returns an instance of an object exposing a given interface and simply acting as a buffer
		/// for another object exposing the same interface.  The new object retains no reference to the
		/// buffered object.
		/// </summary>
		/// <remarks>
		/// The returned object is readonly:
		/// if setters are called on the return object, a <see cref="NotSupportedException"/> is thrown.
		/// </remarks>
		/// <typeparam name="I"></typeparam>
		/// <param name="bufferedInstance"></param>
		/// <returns></returns>
		public static I GetReadOnlyInstance<I>(I bufferedInstance) where I : class //	Should be interface, but there isn't such a constraint
		{
			return GetInstance(bufferedInstance, true);
		}

		/// <summary>
		/// Returns an instance of an object exposing a given interface and simply acting as a buffer
		/// for another object exposing the same interface.  The new object retains no reference to the
		/// buffered object.
		/// </summary>
		/// <remarks>The returned object is writable, as long as properties have setters.</remarks>
		/// <typeparam name="I"></typeparam>
		/// <param name="bufferedInstance"></param>
		/// <returns></returns>
		public static I GetWritableInstance<I>(I bufferedInstance) where I : class //	Should be interface, but there isn't such a constraint
		{
			return GetInstance(bufferedInstance, false);
		}

		/// <summary>
		/// Returns an instance of an object exposing a given interface and simply acting as a buffer
		/// for another object exposing the same interface.  The new object retains no reference to the
		/// buffered object.
		/// </summary>
		/// <remarks>
		/// The returned object is readonly:
		/// if setters are called on the return object, a <see cref="NotSupportedException"/> is thrown.
		/// </remarks>
		/// <typeparam name="I"></typeparam>
		/// <param name="bufferedInstance"></param>
		/// <returns></returns>
		private static I GetInstance<I>(I bufferedInstance, bool readOnly) where I : class //	Should be interface, but there isn't such a constraint
		{
			BufferingTypeEmitter buildSpecifier = new BufferingTypeEmitter();

			buildSpecifier.InterfaceType = typeof(I);
			buildSpecifier.ReadOnly = readOnly;

			object buffer = TypeEmitterCache.GetInstance(buildSpecifier);
			I adapterInterface = buffer as I;
			BufferingAdapterBase<I> adapterBase = buffer as BufferingAdapterBase<I>;

			if (adapterBase == null)
			{
				throw new TypeEmitterException(string.Format(
					"{0} doesn't derive from {1}",
					buffer.GetType().FullName,
					typeof(BufferingAdapterBase<I>).Name));
			}
			if (adapterInterface == null)
			{
				throw new TypeEmitterException(string.Format(
					"{0} doesn't implement {1}",
					adapterBase.GetType().FullName,
					typeof(I).FullName));
			}
			adapterBase.Buffer(bufferedInstance);

			return adapterInterface;
		}
	}
}