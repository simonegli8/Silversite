using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;

using TypeBuilderLib;

namespace TypeBuilderLib.Buffering
{
	/// <summary>Specifies how to build an adapter for AOP.</summary>
	/// <remarks>
	/// <para>
	/// This is useful when we want to have a snapshot of an object without keeping an object around.
	/// For instance, we might have an object that is expensive or impossible to keep around, since it
	/// holds a connection to a store.
	/// </para>
	/// </remarks>
	public class BufferingTypeEmitter : TypeEmitterOneInterfaceBase
	{
		private bool readOnly = true;
		private ILGenerator bufferCopyIlGenerator;
		private IDictionary<string, FieldBuilder> fieldMap;

		#region object methods
		/// <summary>Returns <c>true</c> iif <paramref name="obj"/> if equal to this object.</summary>
		/// <param name="obj"></param>
		/// <returns></returns>
		public override bool Equals(object obj)
		{
			BufferingTypeEmitter typeEmitter = obj as BufferingTypeEmitter;

			return typeEmitter != null && typeEmitter.ReadOnly == ReadOnly && base.Equals(obj);
		}

		/// <summary>Computes the hash code of all object's components.</summary>
		/// <returns></returns>
		public override int GetHashCode()
		{
			return base.GetHashCode() ^ readOnly.GetHashCode();
		}

		/// <summary>Returns a <see cref="string"/> representation of this object.</summary>
		/// <returns></returns>
		public override string ToString()
		{
			return string.Format(
				"{0}<{1}, {2}>",
				typeof(BufferingTypeEmitter).Name,
				InterfaceType.FullName,
				ReadOnly);
		}
		#endregion

		/// <summary>Creates buffer objects that are read only or not.</summary>
		public bool ReadOnly
		{
			get { return readOnly; }
			set { readOnly = value; }
		}

		/// <summary>Returns <see cref="AopAdapterBase"/> type.</summary>
		protected override Type BaseType
		{
			get
			{
				Type genericBaseType = typeof(BufferingAdapterBase<>);
				Type baseType = genericBaseType.MakeGenericType(InterfaceType);

				return baseType;
			}
		}

		/// <summary>Overrides the BufferCopy method.</summary>
		/// <param name="typeBuilder"></param>
		protected override void BeforeImplementingInterface(TypeBuilder typeBuilder)
		{
			base.BeforeImplementingInterface(typeBuilder);

			const MethodAttributes METHOD_ATTRIBUTES =
				MethodAttributes.Family
				| MethodAttributes.HideBySig
				| MethodAttributes.Virtual;
			Type[] parameterTypeList = new Type[] { InterfaceType };
			MethodBuilder method = typeBuilder.DefineMethod(
				"BufferCopy",
				METHOD_ATTRIBUTES,
				typeof(void),
				parameterTypeList);

			bufferCopyIlGenerator = method.GetILGenerator();
			fieldMap = new Dictionary<string, FieldBuilder>();
		}

		/// <summary>Closes the buffer copy method by returning.</summary>
		/// <param name="typeBuilder"></param>
		protected override void AfterImplementingInterface(TypeBuilder typeBuilder)
		{
			base.AfterImplementingInterface(typeBuilder);

			//	Returns from the buffer copy method
			bufferCopyIlGenerator.Emit(OpCodes.Ret);
			bufferCopyIlGenerator = null;
			fieldMap = null;
		}

		/// <summary>Implements a simple returns of the buffered value.</summary>
		/// <param name="propertyInfo"></param>
		/// <param name="ilGenerator"></param>
		/// <param name="typeBuilder"></param>
		protected override void EmitGetMethod(
			PropertyInfo propertyInfo,
			ILGenerator ilGenerator,
			TypeBuilder typeBuilder)
		{
			FieldBuilder field = GetFieldBuilder(propertyInfo, typeBuilder);

			//	Code for the BufferCopy method
			//	Put this on the stack
			bufferCopyIlGenerator.Emit(OpCodes.Ldarg_0);
			//	Put the buffered parameter on the stack
			bufferCopyIlGenerator.Emit(OpCodes.Ldarg_1);
			//	Cast it to the property interface
			bufferCopyIlGenerator.Emit(OpCodes.Castclass, propertyInfo.ReflectedType);
			//	Call the get method on the interface
			bufferCopyIlGenerator.Emit(OpCodes.Call, propertyInfo.GetGetMethod());
			//	Store the value of the property in the buffer field
			bufferCopyIlGenerator.Emit(OpCodes.Stfld, field);

			//	Code for the property itself:
			//	Put this on the stack
			ilGenerator.Emit(OpCodes.Ldarg_0);
			//	Put the buffer field on the stack
			ilGenerator.Emit(OpCodes.Ldfld, field);
			//	Return the buffer field
			ilGenerator.Emit(OpCodes.Ret);
		}

		/// <summary>
		/// Implements a throw exception (if <see cref="ReadOnly"/> is <c>true</c> or sets the underlying
		/// field otherwise.
		/// </summary>
		/// <param name="propertyInfo"></param>
		/// <param name="ilGenerator"></param>
		/// <param name="typeBuilder"></param>
		protected override void EmitSetMethod(
			PropertyInfo propertyInfo,
			ILGenerator ilGenerator,
			TypeBuilder typeBuilder)
		{
			if (ReadOnly)
			{
				ConstructorInfo exceptionConstructor =
					typeof(NotSupportedException).GetConstructor(new Type[] { typeof(string) });

				ilGenerator.Emit(
					OpCodes.Ldstr,
					BaseType.GetType().FullName + " can't set method:  it's a buffer to another object.");
				ilGenerator.Emit(OpCodes.Newobj, exceptionConstructor);
				ilGenerator.Emit(OpCodes.Throw);
			}
			else
			{
				FieldBuilder field = GetFieldBuilder(propertyInfo, typeBuilder);

				//	Put this on the stack
				ilGenerator.Emit(OpCodes.Ldarg_0);
				//	Put the parameter 'value' on the stack
				ilGenerator.Emit(OpCodes.Ldarg_1);
				//	Store the value in the buffer field
				ilGenerator.Emit(OpCodes.Stfld, field);
				//	Returns
				ilGenerator.Emit(OpCodes.Ret);
			}
		}

		/// <summary>Implements a simple forward to the underlying adapted.</summary>
		/// <param name="methodInfo"></param>
		/// <param name="ilGenerator"></param>
		/// <param name="typeBuilder"></param>
		protected override void EmitMethod(
			MethodInfo methodInfo,
			ILGenerator ilGenerator,
			TypeBuilder typeBuilder)
		{
			throw new NotSupportedException(GetType().Name + " does not support methods in the interface.");
		}

		private FieldBuilder GetFieldBuilder(PropertyInfo propertyInfo, TypeBuilder typeBuilder)
		{
			//	Lookup for a corresponding field to buffer
			string explicitPropertyName = propertyInfo.ReflectedType.FullName + "." + propertyInfo.Name;
			string fieldName = explicitPropertyName.Replace('.', '_').Replace('+', '_');

			if (!fieldMap.ContainsKey(fieldName))
			{
				//	Create a corresponding field to buffer
				FieldBuilder field = typeBuilder.DefineField(
					fieldName,
					propertyInfo.PropertyType,
					FieldAttributes.Private);

				fieldMap[fieldName] = field;
			}

			return fieldMap[fieldName];
		}
	}
}