using System;
using System.Collections.Generic;
using System.Reflection;

namespace TypeBuilderLib
{
	/// <summary>Allow an attribute to be context-dependant.</summary>
	/// <remarks>
	/// Derives attribute will be applicable only if the current context is the one specified in the attribute.
	/// </remarks>
	public abstract class ContextAttributeBase : Attribute
	{
		private object context = null;

		/// <summary>The context of this attribute.</summary>
		public object Context
		{
			get { return context; }
			set { context = value; }
		}

		/// <summary>
		/// Returns the custom attribute associated with a member (either a property or method) in a given context.
		/// </summary>
		/// <remarks>We assume that multiple attributes in one context is not allowed.</remarks>
		/// <typeparam name="A"></typeparam>
		/// <param name="member"></param>
		/// <param name="context"></param>
		/// <param name="fallBackToNullContext"></param>
		/// <returns></returns>
		protected static A GetAttributeInContext<A>(
			MemberInfo member,
			object context,
			bool fallBackToNullContext) where A : ContextAttributeBase
		{
			A[] list = GetAttributesInContext<A>(member, context, false, fallBackToNullContext);

			return list.Length==1 ? list[0] : null;
		}

		/// <summary>
		/// Returns the custom attributes associated with a member (either a property or method) in a given context.
		/// </summary>
		/// <typeparam name="A"></typeparam>
		/// <param name="member"></param>
		/// <param name="context"></param>
		/// <param name="allowMultipleInContext"></param>
		/// <param name="fallBackToNullContext"></param>
		/// <returns></returns>
		protected static A[] GetAttributesInContext<A>(
			MemberInfo member,
			object context,
			bool allowMultipleInContext,
			bool fallBackToNullContext)
			where A : ContextAttributeBase
		{
			A[] attributes = GetAttributes<A>(member, allowMultipleInContext);
			A[] contextAttributes =
				Array.FindAll(attributes, delegate(A att) { return object.Equals(att.Context, context); });

			if (contextAttributes.Length > 0 || !fallBackToNullContext)
			{
				return contextAttributes;
			}
			else
			{
				A[] nullContextAttributes = Array.FindAll(attributes, delegate(A att) { return att.Context == null; });

				return nullContextAttributes;
			}
		}

		/// <summary>Returns the custom attributes associated with a member (either a property or method).</summary>
		/// <typeparam name="A"></typeparam>
		/// <param name="member"></param>
		/// <param name="allowMultipleInContext"></param>
		/// <returns></returns>
		protected static A[] GetAttributes<A>(MemberInfo member, bool allowMultipleInContext)
			where A : ContextAttributeBase
		{
			object[] objects = member.GetCustomAttributes(typeof(A), true);
			A[] attributes = Array.ConvertAll<object, A>(objects, delegate(object obj) { return (A)obj; });

			//	Validate unicity of context
			if (!allowMultipleInContext)
			{	//	We assume that there will be few attributes of the same type on a member so that a list
				//	is an efficient enough data structure, to avoid the overhead of a dictionary
				IList<object> contexts = new List<object>();

				foreach (ContextAttributeBase contextAttribute in attributes)
				{
					if (contexts.Contains(contextAttribute.Context))
					{
						throw new ApplicationException(string.Format(
							"There are two attributes of type {0} with the same context ({1}) on member {2} on type {3}.",
							typeof(A).FullName,
							contextAttribute.Context,
							member.Name,
							member.ReflectedType.FullName));
					}
					else
					{
						contexts.Add(contextAttribute.Context);
					}
				}
			}

			return attributes;
		}
	}
}