using System;

using TypeBuilderLib;

namespace TypeBuilderLib.Indexer
{
	/// <summary>Base class for indexer adapters.</summary>
	/// <remarks>This class is typically derived by dynamically compiled classes.</remarks>
	public abstract class IndexerAdapterBase<INDEXER>
	{
		private INDEXER indexer;

		/// <summary>Runtime constraint check.</summary>
		public IndexerAdapterBase()
		{
			if (typeof(INDEXER).GetMethod("get_Item", new Type[] { typeof(string) }) == null)
			{
				throw new TypeEmitterException("An indexer must have an itemizer taking a string in input.");
			}
		}

		/// <summary>Adapted indexer.</summary>
		public INDEXER Indexer
		{
			get { return indexer; }
			set { indexer = value; }
		}
	}
}