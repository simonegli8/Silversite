using System;

using TypeBuilderLib;

namespace TypeBuilderLib.Indexer
{
	/// <summary>Cache for indexers adapter emitted on the fly in an application.</summary>
	/// <remarks>
	/// <para>Reference implementation.</para>
	/// <para>This class acts as a facade to <see cref="TypeEmitterCache"/>.</para>
	/// <para>
	/// An indexer is an object having an itemizer taking a string in input.
	/// </para>
	/// </remarks>
	/// <typeparam name="I"></typeparam>
	public static class IndexerAdapterCache<I> where I : class //	Should be interface, but there isn't such a constraint
	{
		/// <summary>Returns an instance of an adapter adapting an indexer.</summary>
		/// <typeparam name="INDEXER"></typeparam>
		/// <param name="indexer"></param>
		/// <returns></returns>
		public static I GetInstance<INDEXER>(INDEXER indexer)
		{
			return GetInstance<INDEXER>(indexer, null);
		}

		/// <summary>Returns an instance of an adapter adapting an indexer in a given context.</summary>
		/// <typeparam name="INDEXER"></typeparam>
		/// <param name="indexer"></param>
		/// <param name="context"></param>
		/// <returns></returns>
		public static I GetInstance<INDEXER>(INDEXER indexer, object context)
		{
			return GetInstance<INDEXER>(indexer, null, context);
		}

		/// <summary>
		/// Returns an instance of an adapter (derived from a given type) adapting an indexer in a given context.
		/// </summary>
		/// <typeparam name="INDEXER"></typeparam>
		/// <param name="indexer"></param>
		/// <param name="baseAdapterType"></param>
		/// <param name="context"></param>
		/// <returns></returns>
		public static I GetInstance<INDEXER>(INDEXER indexer, Type baseAdapterType, object context)
		{
			IndexerTypeEmitter buildSpecifier = new IndexerTypeEmitter();

			buildSpecifier.InterfaceType = typeof(I);
			buildSpecifier.IndexerType = typeof(INDEXER);
			buildSpecifier.BaseTypeParameter = baseAdapterType;
			buildSpecifier.Context = context;

			object adapter = TypeEmitterCache.GetInstance(buildSpecifier);
			IndexerAdapterBase<INDEXER> adapterBase = adapter as IndexerAdapterBase<INDEXER>;
			I adapterInterface = adapter as I;

			if (adapterBase == null)
			{
				throw new TypeEmitterException(string.Format(
					"{0} doesn't derive from {1}",
					adapter.GetType().FullName,
					typeof(IndexerAdapterBase<INDEXER>).Name));
			}
			if (adapterInterface == null)
			{
				throw new TypeEmitterException(string.Format(
					"{0} doesn't implement {1}",
					adapterBase.GetType().FullName,
					typeof(I).FullName));
			}
			adapterBase.Indexer = indexer;

			return adapterInterface;
		}
	}
}