using System;
using System.Reflection;

namespace TypeBuilderLib.Indexer
{
	/// <summary>Attribute allowing to map a property to a column name other than the property name.</summary>
	/// <remarks>
	/// Used on interface properties to guide <see cref="IndexerTypeEmitter"/> to use another column
	/// name than the property name.
	/// </remarks>
	[AttributeUsage(AttributeTargets.Property, Inherited = true, AllowMultiple = true)]
	public class IndexerMappingAttribute : ContextAttributeBase
	{
		private readonly string columnName;

		/// <summary>Construct a mapping attribute.</summary>
		/// <param name="columnName"></param>
		public IndexerMappingAttribute(string columnName)
		{
			this.columnName = columnName;
		}

		/// <summary>Exposes the mapped column name.</summary>
		public string ColumnName
		{
			get { return columnName; }
		}

		/// <summary>
		/// Returns the mapped column name of a property.  If no mapping attribute is associated to the property,
		/// the column name is the property name.
		/// </summary>
		/// <param name="propertyInfo"></param>
		/// <param name="context"></param>
		/// <returns></returns>
		internal static string GetMappedColumnName(PropertyInfo propertyInfo, object context)
		{
			IndexerMappingAttribute mapping =
				GetAttributeInContext<IndexerMappingAttribute>(propertyInfo, context, true);

			if (mapping == null)
			{	//	Default mapping
				return propertyInfo.Name;
			}
			else
			{
				return mapping.ColumnName;
			}
		}
	}
}