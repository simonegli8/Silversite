using System;
using System.Reflection;
using System.Reflection.Emit;

using TypeBuilderLib;
using TypeBuilderLib.Converters;

namespace TypeBuilderLib.Indexer
{
	/// <summary>Specifies how to build an adapter for indexers.</summary>
	/// <remarks>
	/// <para>An indexer is any object having an itemizer taking a string and returning an object.</para>
	/// <para>
	/// This emitter emits a type exposing a strongly type interface consisting only of properties.
	/// The properties simply forwards to the indexer using its itemizer.
	/// This gives a strongly type interface to an otherwise loosely type indexer.
	/// </para>
	/// </remarks>
	internal class IndexerTypeEmitter : TypeEmitterOneInterfaceParamBaseClassBase
	{
		private Type indexerType;
		private object context = null;

		#region object methods
		/// <summary>Returns <c>true</c> iif <paramref name="obj"/> if equal to this object.</summary>
		/// <param name="obj"></param>
		/// <returns></returns>
		public override bool Equals(object obj)
		{
			IndexerTypeEmitter typeEmitter = obj as IndexerTypeEmitter;

			return base.Equals(typeEmitter)
				&& typeEmitter.IndexerType == IndexerType
				&& object.Equals(typeEmitter.context, context);
		}

		/// <summary>Computes the hash code of all object's components.</summary>
		/// <returns></returns>
		public override int GetHashCode()
		{
			int contextHash = context == null ? 0 : context.GetHashCode();

			return base.GetHashCode() ^ IndexerType.GetHashCode() ^ contextHash;
		}

		/// <summary>Returns a <see cref="string"/> representation of this object.</summary>
		/// <returns></returns>
		public override string ToString()
		{
			return string.Format(
				"{0}<{1}, {2}, {3}>",
				typeof(IndexerTypeEmitter).Name,
				InterfaceType.FullName,
				IndexerType.FullName,
				context);
		}
		#endregion

		/// <summary>Exposes the type of indexer used.</summary>
		public Type IndexerType
		{
			get { return indexerType; }
			set { indexerType = value; }
		}

		/// <summary>Exposes the context in which the type is emitted.  <c>null</c> by default.</summary>
		public object Context
		{
			get { return context; }
			set { context = value; }
		}

		/// <summary>Returns <see cref="IndexerAdapterBase"/> type.</summary>
		/// <remarks><see cref="IndexerType"/> must have been set before setting this property.</remarks>
		public override Type BaseTypeParameter
		{
			get
			{
				if (base.BaseTypeParameter == null)
				{
					return DefaultBaseType;
				}
				else
				{
					return base.BaseTypeParameter;
				}
			}
			set
			{
				//	Validate the type
				if (value != null && !DefaultBaseType.IsAssignableFrom(value))
				{
					throw new ApplicationException(
						value.FullName + " doesn't derive from " + DefaultBaseType.FullName);
				}
				else
				{
					base.BaseTypeParameter = value;
				}
			}
		}

		/// <summary>Implements a simple forward to the underlying indexer.</summary>
		/// <param name="propertyInfo"></param>
		/// <param name="ilGenerator"></param>
		/// <param name="typeBuilder"></param>
		protected override void EmitGetMethod(
			PropertyInfo propertyInfo,
			ILGenerator ilGenerator,
			TypeBuilder typeBuilder)
		{
			UseBaseAttribute useBase = UseBaseAttribute.GetAttributeInContext(propertyInfo, Context);

			if (useBase == null)
			{
				EmitGetFromItem(propertyInfo, ilGenerator);
			}
			else
			{
				EmitGetFromBaseProperty(useBase, propertyInfo, ilGenerator);
			}
		}

		/// <summary>Implements a simple forward to the underlying indexer.</summary>
		/// <param name="propertyInfo"></param>
		/// <param name="ilGenerator"></param>
		/// <param name="typeBuilder"></param>
		protected override void EmitSetMethod(
			PropertyInfo propertyInfo,
			ILGenerator ilGenerator,
			TypeBuilder typeBuilder)
		{
			UseBaseAttribute useBase = UseBaseAttribute.GetAttributeInContext(propertyInfo, Context);

			if (useBase == null)
			{
				EmitSetFromItem(propertyInfo, ilGenerator);
			}
			else
			{
				EmitSetFromBaseProperty(useBase, propertyInfo, ilGenerator);
			}
		}

		protected override void EmitMethod(MethodInfo methodInfo, ILGenerator ilGenerator, TypeBuilder typeBuilder)
		{
			UseBaseAttribute useBase = UseBaseAttribute.GetAttributeInContext(methodInfo, Context);
			bool notPresentNoThrow = false;

			if (useBase != null)
			{
				string methodName =
					string.IsNullOrEmpty(useBase.MemberName) ? methodInfo.Name : useBase.MemberName;
				Type[] parameterTypes = Array.ConvertAll<ParameterInfo, Type>(
					methodInfo.GetParameters(),
					delegate(ParameterInfo info) { return info.ParameterType; });
				//	Fetch the method info of the base class's method to call
				MethodInfo baseMethod = BaseType.GetMethod(
					methodName,
					BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic,
					null,
					parameterTypes,
					null);

				if (baseMethod == null || baseMethod.IsPrivate)
				{
					if (!useBase.ThrowsIfNotPresent)
					{	//	This will result in an exception throw being emitted instead of thrown here
						notPresentNoThrow = true;
					}
					else
					{
						throw new TypeEmitterException(string.Format(
							"Base class {0} doesn't contain a non-private method named {1}.",
							BaseType.FullName,
							methodName));
					}
				}
				else
				{
					//	Push all the method arguments AND the this (arg 0)
					for (int i = 0; i <= methodInfo.GetParameters().Length; ++i)
					{
						ilGenerator.Emit(OpCodes.Ldarg_S, i);
					}
					//	Call the base method
					ilGenerator.Emit(OpCodes.Call, baseMethod);
					//	return
					ilGenerator.Emit(OpCodes.Ret);
				}
			}
			if (useBase == null || notPresentNoThrow)
			{
				ConstructorInfo exceptionConstructor =
					typeof(NotSupportedException).GetConstructor(new Type[] { typeof(string) });

				ilGenerator.Emit(
					OpCodes.Ldstr,
					GetType().Name + " does not support methods in the interface by default.  Use UseBaseAttribute to use the implementation of the base class (the method must be implemented in the base class).");
				ilGenerator.Emit(OpCodes.Newobj, exceptionConstructor);
				ilGenerator.Emit(OpCodes.Throw);
			}

		}

		private Type DefaultBaseType
		{
			get
			{
				Type genericBaseType = typeof(IndexerAdapterBase<>);
				Type defaultBaseType = genericBaseType.MakeGenericType(IndexerType);

				return defaultBaseType;
			}
		}

		private void GetTypeConverterType(
			Type indexerType,
			PropertyInfo propertyInfo,
			out Type typeConverterType,
			out Type typeConverterInterfaceType)
		{
			Type propertyType = propertyInfo.PropertyType;
			TypeConverterAttribute typeConverterAttribute =
				TypeConverterAttribute.GetAttributeInContext(propertyInfo, Context);

			if (typeConverterAttribute == null || typeConverterAttribute.TypeConverterType == null)
			{	//	Default mapping
				typeConverterType = null;
				typeConverterInterfaceType = null;
			}
			else
			{
				typeConverterAttribute.ValidateTypeConverterType(indexerType, propertyType);
				typeConverterType = typeConverterAttribute.TypeConverterType;
				typeConverterInterfaceType =
					TypeConverterAttribute.GetExpectedConverterInterfaceType(indexerType, propertyType);
			}
		}

		private void EmitGetFromItem(PropertyInfo propertyInfo, ILGenerator ilGenerator)
		{
			string columnName = IndexerMappingAttribute.GetMappedColumnName(propertyInfo, Context);
			MethodInfo getItemMethod = IndexerType.GetMethod("get_Item", new Type[] { typeof(string) });
			Type typeConverterType;
			Type typeConverterInterfaceType;

			GetTypeConverterType(
				getItemMethod.ReturnType,
				propertyInfo,
				out typeConverterType,
				out typeConverterInterfaceType);

			if (typeConverterType != null)
			{	//	New the converter
				ilGenerator.Emit(OpCodes.Newobj, typeConverterType.GetConstructor(Type.EmptyTypes));
			}
			//	Put this on the stack
			ilGenerator.Emit(OpCodes.Ldarg_0);

			//	Call the data row property
			ilGenerator.Emit(OpCodes.Call, BaseType.GetMethod("get_Indexer"));
			//	Put the column name on the stack
			ilGenerator.Emit(OpCodes.Ldstr, columnName);
			//	Call the get item on the data row
			ilGenerator.Emit(OpCodes.Callvirt, getItemMethod);
			if (typeConverterType == null)
			{
				if (propertyInfo.PropertyType.IsValueType && getItemMethod.ReturnType == typeof(object))
				{	//	Unbox the item
					ilGenerator.Emit(OpCodes.Unbox_Any, propertyInfo.PropertyType);
				}
				else
				{	//	Cast the item
					ilGenerator.Emit(OpCodes.Castclass, propertyInfo.PropertyType);
				}
			}
			else
			{	//	Call the convert method
				ilGenerator.Emit(OpCodes.Callvirt, typeConverterInterfaceType.GetMethod("ConvertForward"));
			}
			//	Return
			ilGenerator.Emit(OpCodes.Ret);
		}

		private void EmitGetFromBaseProperty(
			UseBaseAttribute useBase,
			PropertyInfo propertyInfo,
			ILGenerator ilGenerator)
		{
			string propertyName =
				string.IsNullOrEmpty(useBase.MemberName) ? propertyInfo.Name : useBase.MemberName;
			//	Fetch the method info of the base class's method to call
			PropertyInfo baseProperty = BaseType.GetProperty(
				propertyName,
				BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

			if (baseProperty == null)
			{
				throw new TypeEmitterException(string.Format(
					"Base class {0} doesn't contain a property named {1}.",
					BaseType.FullName,
					propertyName));
			}
			if (baseProperty.GetGetMethod(true) == null)
			{
				throw new TypeEmitterException(string.Format(
					"The property {0} in base class {1} has not getter.",
					propertyName,
					BaseType.FullName));
			}
			if (baseProperty.GetGetMethod(true).IsPrivate)
			{
				throw new TypeEmitterException(string.Format(
					"The property {0} in base class {1} is private and therefore can't be called by derived class.",
					propertyName,
					BaseType.FullName));
			}

			//	Put this on the stack
			ilGenerator.Emit(OpCodes.Ldarg_0);
			//	Call the base property
			ilGenerator.Emit(OpCodes.Call, baseProperty.GetGetMethod(true));
			//	Return
			ilGenerator.Emit(OpCodes.Ret);
		}

		private void EmitSetFromItem(PropertyInfo propertyInfo, ILGenerator ilGenerator)
		{
			string columnName = IndexerMappingAttribute.GetMappedColumnName(propertyInfo, Context);
			MethodInfo setItemMethod = IndexerType.GetMethod(
				"set_Item",
				new Type[] { typeof(string), typeof(object) });
			Type typeConverterType;
			Type typeConverterInterfaceType;

			GetTypeConverterType(
				setItemMethod.GetParameters()[1].ParameterType,
				propertyInfo,
				out typeConverterType,
				out typeConverterInterfaceType);

			//	Put this on the stack
			ilGenerator.Emit(OpCodes.Ldarg_0);
			//	Call the data row property
			ilGenerator.Emit(OpCodes.Call, BaseType.GetMethod("get_Indexer"));
			//	Put the column name on the stack
			ilGenerator.Emit(OpCodes.Ldstr, columnName);
			if (typeConverterType != null)
			{	//	New the converter
				ilGenerator.Emit(OpCodes.Newobj, typeConverterType.GetConstructor(Type.EmptyTypes));
			}
			//	Put 'value' on the stack
			ilGenerator.Emit(OpCodes.Ldarg_1);
			if (typeConverterType != null)
			{	//	Call the convert method
				ilGenerator.Emit(OpCodes.Callvirt, typeConverterInterfaceType.GetMethod("ConvertBackward"));
			}
			else if (propertyInfo.PropertyType != setItemMethod.GetParameters()[1].ParameterType)
			{
				if (propertyInfo.PropertyType.IsValueType
					&& setItemMethod.GetParameters()[1].ParameterType == typeof(object))
				{	//	Box the item
					ilGenerator.Emit(OpCodes.Box, propertyInfo.PropertyType);
				}
				else
				{	//	Cast the item to property type
					ilGenerator.Emit(OpCodes.Castclass, setItemMethod.GetParameters()[1].ParameterType);
				}
			}
			//	Call the set item on the data row
			ilGenerator.Emit(OpCodes.Callvirt, setItemMethod);
			//	return
			ilGenerator.Emit(OpCodes.Ret);
		}

		private void EmitSetFromBaseProperty(
			UseBaseAttribute useBase,
			PropertyInfo propertyInfo,
			ILGenerator ilGenerator)
		{
			string propertyName =
				string.IsNullOrEmpty(useBase.MemberName) ? propertyInfo.Name : useBase.MemberName;
			//	Fetch the method info of the base class's method to call
			PropertyInfo baseProperty = BaseType.GetProperty(
				propertyName,
				BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

			if (baseProperty == null)
			{
				throw new TypeEmitterException(string.Format(
					"Base class {0} doesn't contain a property named {1}.",
					BaseType.FullName,
					propertyName));
			}
			if (baseProperty.GetSetMethod(true) == null)
			{
				throw new TypeEmitterException(string.Format(
					"The property {0} in base class {1} has not setter.",
					propertyName,
					BaseType.FullName));
			}
			if (baseProperty.GetSetMethod(true).IsPrivate)
			{
				throw new TypeEmitterException(string.Format(
					"The property {0} in base class {1} is private and therefore can't be called by derived class.",
					propertyName,
					BaseType.FullName));
			}

			//	Put this on the stack
			ilGenerator.Emit(OpCodes.Ldarg_0);
			//	Put 'value' on the stack
			ilGenerator.Emit(OpCodes.Ldarg_1);
			//	Call the base property
			ilGenerator.Emit(OpCodes.Call, baseProperty.GetSetMethod(true));
			//	Return
			ilGenerator.Emit(OpCodes.Ret);
		}
	}
}