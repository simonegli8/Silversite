using System;
using System.Reflection;

namespace TypeBuilderLib.Indexer
{
	/// <summary>
	/// Attribute indicating to the emitter to use the base class implementation for implementing a property or
	/// a method of an interface.
	/// </summary>
	[AttributeUsage(AttributeTargets.Property | AttributeTargets.Method, Inherited = true, AllowMultiple = true)]
	public class UseBaseAttribute : ContextAttributeBase
	{
		private bool throwsIfNotPresent = true;
		private string memberName = null;

		/// <summary>
		/// If set to <c>true</c>, a type emitter will throw an exception if the member isn't present.
		/// Otherwise, the emitter emit a member that throws an exception on use.
		/// </summary>
		/// <remarks><c>true</c> by default.</remarks>
		public bool ThrowsIfNotPresent
		{
			get { return throwsIfNotPresent; }
			set { throwsIfNotPresent = value; }
		}

		/// <summary>Name of the member (either method or property) to use.</summary>
		public string MemberName
		{
			get { return memberName; }
			set { memberName = value; }
		}

		/// <summary>Returns the custom attributes associated with a member in a given context.</summary>
		/// <param name="member"></param>
		/// <returns></returns>
		public static UseBaseAttribute GetAttributeInContext(MemberInfo member, object context)
		{
			return GetAttributeInContext<UseBaseAttribute>(member, context, true);
		}
	}
}