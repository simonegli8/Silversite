using System;
using System.Data;

namespace TypeBuilderLib.Mask
{
	/// <summary>Base class for mask adapters.</summary>
	/// <remarks>This class is typically derived by dynamically emitted classes.</remarks>
	/// <typeparam name="A"></typeparam>
	public abstract class MaskAdapterBase<A> where A : class
	{
		private A adapted;

		/// <summary>Exposes the adaptee object.</summary>
		/// <remarks>This must be set before any call can be done.</remarks>
		public A Adapted
		{
			get { return adapted; }
			set { adapted = value; }
		}
	}
}