using System;
using System.Data;

using TypeBuilderLib;

namespace TypeBuilderLib.Mask
{
	/// <summary>Cache for mask adapter emitted on the fly in an application.</summary>
	/// <remarks>
	/// <para>Reference implementation.</para>
	/// <para>This class acts as a facade to <see cref="TypeEmitterCache"/>.</para>
	/// <para>
	/// A mask adapter is an adapter exposing an interface while the adapted object didn't expose it
	/// but exposed all properties and methods of the interface.  It basically acts as a mask to the
	/// adapted, exposing an interface.
	/// </para>
	/// <para>
	/// This is very useful when we need a class to expose a given interface but we do not control the
	/// implementation of that class.
	/// </para>
	/// </remarks>
	public static class MaskAdapterCache<I> where I : class //	Should be interface, but there isn't such a constraint
	{
		/// <summary>
		/// Returns an instance of an adapter adapting an adapted to indirectly expose an interface.
		/// </summary>
		/// <typeparam name="I"></typeparam>
		/// <param name="adapted"></param>
		/// <returns></returns>
		public static I GetInstance<A>(A adapted) where A : class
		{
			MaskTypeEmitter buildSpecifier = new MaskTypeEmitter();

			buildSpecifier.InterfaceType = typeof(I);
			buildSpecifier.AdaptedType = typeof(A);

			object adapter = TypeEmitterCache.GetInstance(buildSpecifier);
			I adapterInterface = adapter as I;
			MaskAdapterBase<A> adapterBase = adapter as MaskAdapterBase<A>;

			if (adapterBase == null)
			{
				throw new TypeEmitterException(string.Format(
					"{0} doesn't derive from {1}",
					adapter.GetType().FullName,
					typeof(MaskAdapterBase<A>).Name));
			}
			if (adapterInterface == null)
			{
				throw new TypeEmitterException(string.Format(
					"{0} doesn't implement {1}",
					adapterBase.GetType().FullName,
					typeof(I).FullName));
			}
			adapterBase.Adapted = adapted;

			return adapterInterface;
		}
	}
}