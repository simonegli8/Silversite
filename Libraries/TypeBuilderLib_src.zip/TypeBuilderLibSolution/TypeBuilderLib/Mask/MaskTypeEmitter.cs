using System;
using System.Reflection;
using System.Reflection.Emit;

using TypeBuilderLib;

namespace TypeBuilderLib.Mask
{
	/// <summary>Specifies how to build a mask adapter.</summary>
	/// <remarks>
	/// <para>
	/// A mask adapter is an adapter exposing an interface while the adapted object didn't expose it
	/// but exposed all properties and methods of the interface.  It basically acts as a mask to the
	/// adapted, exposing an interface.
	/// </para>
	/// <para>
	/// This is very useful when we need a class to expose a given interface but we do not control the
	/// implementation of that class.
	/// </para>
	/// </remarks>
	public class MaskTypeEmitter : TypeEmitterOneInterfaceBase
	{
		private Type adaptedType;

		#region object methods
		/// <summary>Returns <c>true</c> iif <paramref name="obj"/> if equal to this object.</summary>
		/// <param name="obj"></param>
		/// <returns></returns>
		public override bool Equals(object obj)
		{
			MaskTypeEmitter typeEmitter = obj as MaskTypeEmitter;

			return typeEmitter != null && base.Equals(obj) && adaptedType==typeEmitter.AdaptedType;
		}

		/// <summary>Computes the hash code of all object's components.</summary>
		/// <returns></returns>
		public override int GetHashCode()
		{
			return base.GetHashCode() ^ AdaptedType.GetHashCode();
		}

		/// <summary>Returns a <see cref="string"/> representation of this object.</summary>
		/// <returns></returns>
		public override string ToString()
		{
			return string.Format(
				"{0}<{1}, {2}>",
				typeof(MaskTypeEmitter).Name,
				InterfaceType.FullName,
				AdaptedType.FullName);
		}
		#endregion

		/// <summary>Exposes the adapted type.</summary>
		public Type AdaptedType
		{
			get { return adaptedType; }
			set { adaptedType = value; }
		}

		/// <summary>Returns <see cref="AopAdapterBase"/> type.</summary>
		protected override Type BaseType
		{
			get
			{
				Type genericBaseType = typeof(MaskAdapterBase<>);
				Type baseType = genericBaseType.MakeGenericType(AdaptedType);
				
				return baseType;
			}
		}

		/// <summary>Implements a simple forward to the underlying adapted.</summary>
		/// <param name="propertyInfo"></param>
		/// <param name="ilGenerator"></param>
		/// <param name="typeBuilder"></param>
		protected override void EmitGetMethod(
			PropertyInfo propertyInfo,
			ILGenerator ilGenerator,
			TypeBuilder typeBuilder)
		{
			//	Put this on the stack
			ilGenerator.Emit(OpCodes.Ldarg_0);
			//	Call the Adapted property
			ilGenerator.Emit(OpCodes.Call, BaseType.GetMethod("get_Adapted"));

			//	Call the underlying property
			MethodInfo method = AdaptedType.GetMethod("get_" + propertyInfo.Name);

			if (method == null)
			{
				throw new TypeEmitterException(string.Format(
					"{0} doesn't have a getter property named {1}",
					InterfaceType.FullName,
					propertyInfo.Name));
			}
			ilGenerator.Emit(OpCodes.Call, method);
			//	Return
			ilGenerator.Emit(OpCodes.Ret);
		}

		/// <summary>Implements a simple forward to the underlying adapted.</summary>
		/// <param name="propertyInfo"></param>
		/// <param name="ilGenerator"></param>
		/// <param name="typeBuilder"></param>
		protected override void EmitSetMethod(
			PropertyInfo propertyInfo,
			ILGenerator ilGenerator,
			TypeBuilder typeBuilder)
		{
			//	Put this on the stack
			ilGenerator.Emit(OpCodes.Ldarg_0);
			//	Call the Adapted property
			ilGenerator.Emit(OpCodes.Call, BaseType.GetMethod("get_Adapted"));
			//	Put value on the stack
			ilGenerator.Emit(OpCodes.Ldarg_1);
			//	Call the underlying property
			MethodInfo method = AdaptedType.GetMethod("set_" + propertyInfo.Name);

			if (method == null)
			{
				throw new TypeEmitterException(string.Format(
					"{0} doesn't have a setter property named {1}",
					InterfaceType.FullName,
					propertyInfo.Name));
			}
			ilGenerator.Emit(OpCodes.Call, method);
			//	Return
			ilGenerator.Emit(OpCodes.Ret);
		}

		/// <summary>Implements a simple forward to the underlying adapted.</summary>
		/// <param name="methodInfo"></param>
		/// <param name="ilGenerator"></param>
		/// <param name="typeBuilder"></param>
		protected override void EmitMethod(
			MethodInfo methodInfo,
			ILGenerator ilGenerator,
			TypeBuilder typeBuilder)
		{
			//	Put this on the stack
			ilGenerator.Emit(OpCodes.Ldarg_0);
			//	Call the Adaptee property
			ilGenerator.Emit(OpCodes.Call, BaseType.GetMethod("get_Adapted"));
			//	Load every argument on the stack
			for (int i = 0; i != methodInfo.GetParameters().Length; ++i)
			{
				//	We do not put this on the stack (so we skip 0)
				ilGenerator.Emit(OpCodes.Ldarg, i+1);
			}
			//	Call the underlying method
			MethodInfo adaptedMethod = AdaptedType.GetMethod(methodInfo.Name);

			if (adaptedMethod == null)
			{
				throw new TypeEmitterException(string.Format(
					"{0} doesn't have a method named {1}",
					InterfaceType.FullName,
					methodInfo.Name));
			}
			ilGenerator.Emit(OpCodes.Call, adaptedMethod);
			//	Return
			ilGenerator.Emit(OpCodes.Ret);
		}
	}
}