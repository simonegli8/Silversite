using System;
using System.Reflection;
using System.Reflection.Emit;

namespace TypeBuilderLib
{
	/// <summary>Base class for all build specifier.  Specifies how to build a class.</summary>
	/// <remarks>
	/// <para>
	/// Derived classes have two functions:  emitting types and being used as a key to cache the type
	/// they can emit by <see cref="TypeEmitterCache"/>.
	/// </para>
	/// <para>
	/// This class acts as an abstraction of <see cref="System.Reflection.Emit"/> to create dynamic
	/// classes.
	/// </para>
	/// <para>
	/// Since <see cref="TypeEmitterCache"/> uses instances of derived classes as a key in a cache
	/// dictionary, derived classes must correctly implement <see cref="Equals"/> and
	/// <see cref="GetHashCode"/>.
	/// </para>
	/// </remarks>
	public abstract class TypeEmitterBase
	{
		#region object methods
		/// <summary>Returns <c>true</c> iif <paramref name="obj"/> if equal to this object.</summary>
		/// <param name="obj"></param>
		/// <returns></returns>
		public override bool Equals(object obj)
		{
			throw new NotImplementedException("Must implement the Equals method.");
		}

		/// <summary>Computes the hash code of all object's components.</summary>
		/// <returns></returns>
		public override int GetHashCode()
		{
			throw new NotImplementedException("Must implement the GetHashCode method.");
		}

		/// <summary>Returns a <see cref="string"/> representation of this object.</summary>
		/// <returns></returns>
		public override string ToString()
		{
			return base.ToString();
		}
		#endregion

		/// <summary>Emit a type.</summary>
		/// <param name="typeFullName"></param>
		/// <param name="moduleBuilder"></param>
		/// <returns></returns>
		public virtual TypeBuilder EmitType(string typeFullName, ModuleBuilder moduleBuilder)
		{
			TypeBuilder typeBuilder = DefineType(typeFullName, moduleBuilder);

			PopulateType(typeBuilder);

			return typeBuilder;
		}

		/// <summary>Called by <see cref="DefineType"/> to define the type.  Template method.</summary>
		protected abstract Type BaseType { get;}

		/// <summary>Called by <see cref="DefineType"/> to define the type.  Template method.</summary>
		protected abstract Type[] ImplementedInterfaces { get;}

		/// <summary>Populates a type.</summary>.
		/// <param name="typeBuilder"></param>
		protected abstract void PopulateType(TypeBuilder typeBuilder);

		/// <summary>Defines a type in a <see cref="ModuleBuilder"/>.</summary>
		/// <remarks>
		/// This implementation defines a public type and calls <see cref="BaseType"/> and
		/// <see cref="ImplementedInterfaces"/> properties to define the type.
		/// </remarks>
		/// <param name="typeFullName"></param>
		/// <param name="moduleBuilder"></param>
		/// <returns></returns>
		protected virtual TypeBuilder DefineType(string typeFullName, ModuleBuilder moduleBuilder)
		{
			TypeBuilder typeBuilder = moduleBuilder.DefineType(
				typeFullName,
				TypeAttributes.Public
				| TypeAttributes.Class
				| TypeAttributes.AutoClass
				| TypeAttributes.AnsiClass
				| TypeAttributes.BeforeFieldInit
				| TypeAttributes.AutoLayout,
				BaseType,
				ImplementedInterfaces);

			return typeBuilder;
		}
	}
}