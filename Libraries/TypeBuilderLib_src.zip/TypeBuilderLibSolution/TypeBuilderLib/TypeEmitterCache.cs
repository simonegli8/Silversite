using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using System.Threading;

namespace TypeBuilderLib
{
	/// <summary>Cache for classes built on the fly in an application.</summary>
	/// <remarks>
	/// <para>The main method of this class is <see cref="GetInstance"/>.</para>
	/// <para>The responsibility of this class is to emit new types and cache them.</para>
	/// <para>
	/// This class can be used directly but is typically used by other facade classes offering a less
	/// low-level interface.
	/// </para>
	/// </remarks>
	public static class TypeEmitterCache
	{
		private const string ASSEMBLY_NAME = "TypeEmitterCache";
		private const string TYPE_PREFIX = "TypeEmitterCache.";

		private static bool writeAssemblies = false;
		private static int compilationNumber = 0;
		private static AssemblyBuilder assemblyBuilder;
		private static ModuleBuilder moduleBuilder;
		private static readonly object cacheSync = new object();
		private static IDictionary<TypeEmitterBase, Type> typeCache;

		/// <summary>Initializes static fields.</summary>
		static TypeEmitterCache()
		{
			FlushCache();
		}

		/// <summary>
		/// For debugging purposes this flag can be set to <c>true</c>.  When so, the cache
		/// doesn't cache and writes the assemblies to disk.
		/// </summary>
		public static bool WriteAssemblies
		{
			get { return writeAssemblies; }
			set
			{
				writeAssemblies = value;
				FlushCache();
			}
		}

		/// <summary>
		/// Returns an instance of a type emitted according to a <see cref="TypeEmiterBase"/>.
		/// Must emit the type if the type is not cached.
		/// Types are cached using the the <see cref="TypeEmiterBase"/> instance hash code.
		/// </summary>
		/// <param name="typeEmitger"></param>
		/// <returns></returns>
		public static object GetInstance(TypeEmitterBase typeEmitter)
		{
			Type type = GetDynamicType(typeEmitter);
			object instance = Activator.CreateInstance(type);

			return instance;
		}

		/// <summary>
		/// Returns a type emitted according to a <see cref="TypeEmiterBase"/>.
		/// Must emit the type if the type is not cached.
		/// Types are cached using the the <see cref="TypeEmiterBase"/> instance hash code.
		/// </summary>
		/// <param name="typeEmitger"></param>
		/// <returns></returns>
		public static Type GetDynamicType(TypeEmitterBase typeEmitter)
		{
			if (!typeCache.ContainsKey(typeEmitter))
			{
				int thisCompilationNumber = Interlocked.Increment(ref compilationNumber);
				string typeFullName = TYPE_PREFIX + thisCompilationNumber;

				TypeBuilder typeBuilder = typeEmitter.EmitType(typeFullName, moduleBuilder);
				Type emittedType = typeBuilder.CreateType();

				AddToCache(typeEmitter, emittedType);
			}

			Type type = typeCache[typeEmitter];

			if (WriteAssemblies)
			{
				assemblyBuilder.Save(ASSEMBLY_NAME + (compilationNumber - 1) + ".dll");
				FlushCache();
			}

			return type;
		}

		/// <summary>Flushes the cache.</summary>
		/// <remarks>
		/// This can have negative impact on applications and should be used only in a test environment
		/// to make sure to always have a freshly compiled adapter.
		/// </remarks>
		public static void FlushCache()
		{
			lock (cacheSync)
			{
				typeCache = new Dictionary<TypeEmitterBase, Type>();

				if (!WriteAssemblies)
				{
					assemblyBuilder = AppDomain.CurrentDomain.DefineDynamicAssembly(
						new AssemblyName(ASSEMBLY_NAME),
						AssemblyBuilderAccess.Run);
					moduleBuilder = assemblyBuilder.DefineDynamicModule(ASSEMBLY_NAME, true);
				}
				else
				{	//	Assemblies will be written to disk
					assemblyBuilder = AppDomain.CurrentDomain.DefineDynamicAssembly(
						new AssemblyName(ASSEMBLY_NAME),
						AssemblyBuilderAccess.RunAndSave);
					moduleBuilder = assemblyBuilder.DefineDynamicModule(
						ASSEMBLY_NAME,
						ASSEMBLY_NAME + compilationNumber + ".dll",
						true);
				}
			}
		}

		/// <summary>
		/// To avoid locking, we copy the cache to a new dictionary, add to this new one and
		/// then interchange the two caches.
		/// </summary>
		/// <param name="typeCompilier"></param>
		/// <param name="compiledType"></param>
		private static void AddToCache(TypeEmitterBase typeCompilier, Type compiledType)
		{
			lock (cacheSync)
			{
				if (!typeCache.ContainsKey(typeCompilier))
				{
					//	Copy
					IDictionary<TypeEmitterBase, Type> newCache =
						new Dictionary<TypeEmitterBase, Type>(typeCache);

					//	Add new
					newCache.Add(typeCompilier, compiledType);
					//	Interchange
					Interlocked.Exchange<IDictionary<TypeEmitterBase, Type>>(ref typeCache, newCache);
				}
			}
		}
	}
}