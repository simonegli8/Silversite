using System;

namespace TypeBuilderLib
{
	/// <summary>Exception thrown when the emitter isn't able to generate a type.</summary>
	public class TypeEmitterException : ApplicationException
	{
		/// <summary>Constructor of an emitter exception.</summary>
		/// <param name="message"></param>
		public TypeEmitterException(string message)
			: base(message)
		{
		}
	}
}