using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;

namespace TypeBuilderLib
{
	/// <summary>Specifies how to build a class with one interface.</summary>
	/// <remarks>
	/// Very useful specialisation of <see cref="TypeEmitterBase"/>, this class specialise in
	/// emitting classes exposing only one interface.  It steamlines the emitting of such dynamic
	/// classes.
	/// </remarks>
	public abstract class TypeEmitterOneInterfaceBase : TypeEmitterBase
	{
		//	The methods require a special set of attributes.
		private const MethodAttributes METHOD_ATTRIBUTES =
			MethodAttributes.Private
			| MethodAttributes.HideBySig
			| MethodAttributes.NewSlot
			| MethodAttributes.Virtual
			| MethodAttributes.Final;
		//	The property get property and set methods require a special set of attributes.
		private const MethodAttributes getSetAttributes =
			METHOD_ATTRIBUTES
			| MethodAttributes.SpecialName;
		private Type interfaceType;

		#region object methods
		/// <summary>Returns <c>true</c> iif <paramref name="obj"/> if equal to this object.</summary>
		/// <param name="obj"></param>
		/// <returns></returns>
		public override bool Equals(object obj)
		{
			TypeEmitterOneInterfaceBase typeEmitter = obj as TypeEmitterOneInterfaceBase;

			return typeEmitter != null && typeEmitter.InterfaceType == InterfaceType;
		}

		/// <summary>Computes the hash code of all object's components.</summary>
		/// <returns></returns>
		public override int GetHashCode()
		{
			return GetType().GetHashCode() ^ InterfaceType.GetHashCode();
		}

		/// <summary>Returns a <see cref="string"/> representation of this object.</summary>
		/// <returns></returns>
		public override string ToString()
		{
			return base.ToString();
		}
		#endregion

		/// <summary>Exposes the interface type exposed by the type being built.</summary>
		/// <remarks>Must be set before type emission starts.</remarks>
		public Type InterfaceType
		{
			get { return interfaceType; }
			set
			{
				if (!value.IsInterface)
				{
					throw new TypeEmitterException(string.Format(
						"Type {0} cannot act as an interface type since it isn't an interface.",
						value.FullName));
				}
				interfaceType = value;
			}
		}

		/// <summary>Returns one interface:  <see cref="InterfaceType"/>.</summary>
		protected override Type[] ImplementedInterfaces
		{
			get { return new Type[] { InterfaceType }; }
		}

		/// <summary>Populates a type by implementing the <see cref="InterfaceType"/>.</summary>.
		protected override void PopulateType(TypeBuilder typeBuilder)
		{
			if (InterfaceType == null)
			{
				throw new TypeEmitterException(string.Format(
					"{0} has InterfaceType set to null.",
					GetType().FullName));
			}

			BeforeImplementingInterface(typeBuilder);
			ImplementingInterface(typeBuilder);
			AfterImplementingInterface(typeBuilder);
		}

		/// <summary>Emits the body of a get method:  the method mapping to the get of a property.</summary>
		/// <param name="propertyInfo"></param>
		/// <param name="ilGenerator"></param>
		/// <param name="typeBuilder"></param>
		protected abstract void EmitGetMethod(
			PropertyInfo propertyInfo,
			ILGenerator ilGenerator,
			TypeBuilder typeBuilder);

		/// <summary>Emits the body of a set method:  the method mapping to the set of a property.</summary>
		/// <param name="propertyInfo"></param>
		/// <param name="ilGenerator"></param>
		/// <param name="typeBuilder"></param>
		protected abstract void EmitSetMethod(
			PropertyInfo propertyInfo,
			ILGenerator ilGenerator,
			TypeBuilder typeBuilder);

		/// <summary>Emits the body of a method.</summary>
		/// <param name="methodInfo"></param>
		/// <param name="ilGenerator"></param>
		/// <param name="typeBuilder"></param>
		protected abstract void EmitMethod(
			MethodInfo methodInfo,
			ILGenerator ilGenerator,
			TypeBuilder typeBuilder);

		/// <summary>
		/// Called before implementing the interface.
		/// Typically where the base class virtual methods are overidden.
		/// </summary>
		/// <param name="typeBuilder"></param>
		protected virtual void BeforeImplementingInterface(TypeBuilder typeBuilder)
		{
			//	Do nothing by default
		}

		/// <summary>Called after implementing the interface.</summary>
		/// <param name="typeBuilder"></param>
		protected virtual void AfterImplementingInterface(TypeBuilder typeBuilder)
		{
			//	Do nothing by default
		}

		/// <summary>Adds methods and properties to implement <see cref="InterfaceType"/>.</summary>
		/// <param name="typeBuilder"></param>
		private void ImplementingInterface(TypeBuilder typeBuilder)
		{
			foreach (PropertyInfo propertyInfo in GetInterfacePropertyInfos())
			{
				ImplementProperty(typeBuilder, propertyInfo);
			}

			foreach (MethodInfo methodInfo in GetInterfaceMethodInfos())
			{
				ImplementMethod(typeBuilder, methodInfo);
			}
		}

		private void ImplementProperty(TypeBuilder typeBuilder, PropertyInfo propertyInfo)
		{
			string interfaceDot = propertyInfo.ReflectedType.FullName + '.';
			PropertyBuilder propertyBuilder = typeBuilder.DefineProperty(
				interfaceDot + propertyInfo.Name,
				PropertyAttributes.HasDefault,
				propertyInfo.PropertyType,
				null);

			if (propertyInfo.CanRead)
			{	// Define the "get" accessor method
				string methodName = "get_" + propertyInfo.Name;
				MethodBuilder getMethod = typeBuilder.DefineMethod(
					interfaceDot + methodName,
					getSetAttributes,
					propertyInfo.PropertyType,
					Type.EmptyTypes);
				ILGenerator ilGenerator = getMethod.GetILGenerator();

				EmitGetMethod(propertyInfo, ilGenerator, typeBuilder);
				propertyBuilder.SetGetMethod(getMethod);
				typeBuilder.DefineMethodOverride(
					getMethod,
					propertyInfo.ReflectedType.GetMethod(methodName));
			}
			if (propertyInfo.CanWrite)
			{	// Define the "set" accessor method
				string methodName = "set_" + propertyInfo.Name;
				MethodBuilder setMethod = typeBuilder.DefineMethod(
					interfaceDot + methodName,
					getSetAttributes,
					null,
					new Type[] { propertyInfo.PropertyType });
				ILGenerator ilGenerator = setMethod.GetILGenerator();

				EmitSetMethod(propertyInfo, ilGenerator, typeBuilder);
				propertyBuilder.SetSetMethod(setMethod);
				typeBuilder.DefineMethodOverride(
					setMethod,
					propertyInfo.ReflectedType.GetMethod(methodName));
			}
		}

		private void ImplementMethod(TypeBuilder typeBuilder, MethodInfo methodInfo)
		{
			string interfaceDot = methodInfo.ReflectedType.FullName + '.';
			Type[] parameterTypeList = Array.ConvertAll<ParameterInfo, Type>(
				methodInfo.GetParameters(),
				delegate(ParameterInfo info) { return info.ParameterType; });
			MethodBuilder methodBuilder = typeBuilder.DefineMethod(
				interfaceDot + methodInfo.Name,
				METHOD_ATTRIBUTES,
				methodInfo.ReturnType,
				parameterTypeList);
			ILGenerator ilGenerator = methodBuilder.GetILGenerator();

			EmitMethod(methodInfo, ilGenerator, typeBuilder);
			typeBuilder.DefineMethodOverride(methodBuilder, methodInfo);
		}

		/// <summary>Fetch the properties of whole the interfaces in <see cref="InterfaceType"/>.</summary>
		/// <remarks>In general, <see cref="InterfaceType"/> can have base interfaces.</remarks>
		/// <returns></returns>
		private PropertyInfo[] GetInterfacePropertyInfos()
		{
			List<Type> interfaceTypes = new List<Type>();
			List<PropertyInfo> info = new List<PropertyInfo>();

			interfaceTypes.Add(InterfaceType);
			interfaceTypes.AddRange(InterfaceType.GetInterfaces());

			foreach (Type type in interfaceTypes)
			{
				info.AddRange(type.GetProperties());
			}

			return info.ToArray();
		}

		/// <summary>Fetch the methods of whole the interfaces in <see cref="InterfaceType"/>.</summary>
		/// <remarks>In general, <see cref="InterfaceType"/> can have base interfaces.</remarks>
		/// <returns></returns>
		private MethodInfo[] GetInterfaceMethodInfos()
		{
			List<Type> interfaceTypes = new List<Type>();
			List<MethodInfo> info = new List<MethodInfo>();

			interfaceTypes.Add(InterfaceType);
			interfaceTypes.AddRange(InterfaceType.GetInterfaces());

			foreach (Type type in interfaceTypes)
			{
				info.AddRange(type.GetMethods());
			}
			info = info.FindAll(delegate(MethodInfo method) { return !method.IsSpecialName; });

			return info.ToArray();
		}
	}
}