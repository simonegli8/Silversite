using System;

namespace TypeBuilderLib
{
	/// <summary>
	/// Offers the same behaviours than <see cref="TypeEmitterOneInterfaceBase"/> but allows to set the
	/// base class of the generated type.
	/// </summary>
	public abstract class TypeEmitterOneInterfaceParamBaseClassBase : TypeEmitterOneInterfaceBase
	{
		private Type baseTypeParameter = null;

		#region object methods
		/// <summary>Returns <c>true</c> iif <paramref name="obj"/> if equal to this object.</summary>
		/// <param name="obj"></param>
		/// <returns></returns>
		public override bool Equals(object obj)
		{
			TypeEmitterOneInterfaceParamBaseClassBase typeEmitter =
				obj as TypeEmitterOneInterfaceParamBaseClassBase;

			return base.Equals(typeEmitter) && typeEmitter.BaseTypeParameter == BaseTypeParameter;
		}

		/// <summary>Computes the hash code of all object's components.</summary>
		/// <returns></returns>
		public override int GetHashCode()
		{
			int baseTypeParameterHash = baseTypeParameter == null ? 0 : baseTypeParameter.GetHashCode();

			return base.GetHashCode() ^ baseTypeParameterHash;
		}

		/// <summary>Returns a <see cref="string"/> representation of this object.</summary>
		/// <returns></returns>
		public override string ToString()
		{
			return base.ToString();
		}
		#endregion

		/// <summary>Allows to set a base class in parameter.</summary>
		public virtual Type BaseTypeParameter
		{
			get { return baseTypeParameter; }
			set { baseTypeParameter = value; }
		}

		/// <summary>Returns <see cref="BaseTypeParameter"/>.</summary>
		protected sealed override Type BaseType
		{
			get { return BaseTypeParameter; }
		}
	}
}