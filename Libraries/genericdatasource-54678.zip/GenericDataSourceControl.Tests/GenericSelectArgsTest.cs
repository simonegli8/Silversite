﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Web.UI;
using System.Collections;
using System.Web.UI.WebControls;
using GenericDataSourceControl;

namespace GenericDataSourceControl.Tests
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class GenericSelectArgsTest
    {
        public GenericSelectArgsTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void TestSetPagedData()
        {
            DataSourceSelectArguments dataSourceSelectArgs = new DataSourceSelectArguments();
            GenericSelectArgs target = new GenericSelectArgs(dataSourceSelectArgs);
            var items = new List<string>()
            {
                "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten"
            };
            //pageSize = 3;
            //pageCount = 2;
            //get the page #2:
            var dataPage = new List<string>()
            {
                items[3], items[4], items[5],
            };
            //setup paged DataSource
            target.SetPagedData(dataPage, items.Count);
            var actual = target.DataSource;
            //check for the TotalRowCount
            Assert.AreEqual(items.Count, target.SelectArguments.TotalRowCount);
            //checked the paged data:
            foreach (string item in actual)
            {
                Assert.IsTrue(dataPage.Contains(item), "Paged data does not contain <{0}>", item);
            }
        }

        [TestMethod]
        public void TestSetDataWithGenericQueryable()
        {
            DataSourceSelectArguments dataSourceSelectArgs = new DataSourceSelectArguments()
            {
                MaximumRows = 3,
                StartRowIndex = 3,
            };
            GenericSelectArgs target = new GenericSelectArgs(dataSourceSelectArgs);
            var items = new List<string>()
            {
                "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten"
            };
            //get the page #2:
            var dataPage = new List<string>()
            {
                items[3], items[4], items[5],
            };
            //setup paged DataSource
            target.SetData(items.AsQueryable());
            var actual = target.DataSource;
            //check for the TotalRowCount
            Assert.AreEqual(items.Count, target.SelectArguments.TotalRowCount);
            //checked the paged data:
            foreach (string item in actual)
            {
                Assert.IsTrue(dataPage.Contains(item), "Paged data does not contain <{0}>", item);
            }
        }

        [TestMethod]
        public void TestSetDataSourceWithAnnonymousIEnumerable()
        {
            DataSourceSelectArguments dataSourceSelectArgs = new DataSourceSelectArguments()
            {
                MaximumRows = 3,
                StartRowIndex = 3,
                SortExpression = "Name",
            };
            GenericSelectArgs target = new GenericSelectArgs(dataSourceSelectArgs);
            var items = new ArrayList()
            {
                "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten"
            };
            //get the page #2:
            var dataPage = new ArrayList()
            {
                items[3], items[4], items[5],
            };
            //setup paged DataSource
            target.SetData(items);
            var actual = target.DataSource;
            //check for the TotalRowCount
            Assert.AreEqual(items.Count, target.SelectArguments.TotalRowCount);
            //check for the DataSource
            int actualRowCount = 0;
            foreach (string item in actual)
            {
                Assert.IsTrue(dataPage.Contains(item), "Paged data does not contain <{0}>", item);
                actualRowCount ++;
            }

            Assert.AreEqual(target.SelectArguments.MaximumRows, actualRowCount);
        }

        [TestMethod]
        public void TestSetDataSourceWithGenericQueryableSortingAndPaging()
        {
            DataSourceSelectArguments dataSourceSelectArgs = new DataSourceSelectArguments()
            {
                MaximumRows = 3,
                StartRowIndex = 3,
            };
            GenericSelectArgs target = new GenericSelectArgs(dataSourceSelectArgs);
            var items = new List<string>()
            {
                "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten"
            };
            //get the page #2:
            var dataPage = new List<string>()
            {
                items[3], items[4], items[5],
            };
            //setup paged DataSource
            target.SetData(items.AsQueryable());
            var actual = target.DataSource;
            //check for the TotalRowCount
            Assert.AreEqual(items.Count, target.SelectArguments.TotalRowCount);
            //checked the paged data:
            foreach (string item in actual)
            {
                Assert.IsTrue(dataPage.Contains(item), "Paged data does not contain <{0}>", item);
            }
        }

        /// <summary>
        ///A test for SetData
        ///</summary>
        [TestMethod()]
        public void SetDataTestWithAutoPage()
        {
            GenericSelectArgs target = new GenericSelectArgs()
            {
                SelectArguments = new DataSourceSelectArguments()
                {
                    MaximumRows = 3,
                    StartRowIndex = 3,
                }
            };

            IQueryable dataSource = new List<string>()
            {
                "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten"
            }.AsQueryable<string>();

            bool autoSort = true;
            bool autoPage = true;
            target.SetData(dataSource, autoSort, autoPage);

            Assert.AreEqual(3, target.DataSource.OfType<string>().Count());
        }
    }
}
