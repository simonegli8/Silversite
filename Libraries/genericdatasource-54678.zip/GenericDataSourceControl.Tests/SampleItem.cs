﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GenericDataSourceControl.Tests
{
    public enum SampleEnum
    {
        None = 0,
        One,
        Two,
    }

    public class SampleItem
    {
        public int Value { get; set; }
        public string Name { get; set; }

        public override string ToString()
        {
            return this.Name;
        }
    }
}
