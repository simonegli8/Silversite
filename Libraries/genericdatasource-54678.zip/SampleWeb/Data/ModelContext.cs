﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;

namespace SampleWeb.Data
{
    public partial class ModelContext
    {
        private static ModelContext _instance;

        public static ModelContext Instance
        {
            get
            {
                ModelContext theResult = null;

                if (HttpContext.Current == null)
                {
                    if (_instance == null)
                    {
                        _instance = new ModelContext()
                        {
                           
                        };
                    }

                    theResult = _instance;
                }
                else
                {
                    if (HttpContext.Current.Items["_modelContext"] == null)
                    {
                        var dataContext = new ModelContext()
                        {
                            
                        };

                        HttpContext.Current.Items["_dataContext"] = dataContext;
                    }

                    theResult = HttpContext.Current.Items["_dataContext"] as ModelContext;
                }

                return theResult;
            }
        }
    }
}
