﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;

namespace SampleWeb.Data
{
    public partial class ModelDataContext
    {
        private static ModelDataContext _instance;

        public static ModelDataContext Instance
        {
            get
            {
                ModelDataContext theResult = null;

                if (HttpContext.Current == null)
                {
                    if (_instance == null)
                    {
                        _instance = new ModelDataContext()
                        {
                            Log = new StringWriter(),
                        };
                    }

                    theResult = _instance;
                }
                else
                {
                    if (HttpContext.Current.Items["_dataContext"] == null)
                    {
                        var dataContext = new ModelDataContext()
                        {
                            Log = new StringWriter(),
                        };

                        HttpContext.Current.Items["_dataContext"] = dataContext;
                    }

                    theResult = HttpContext.Current.Items["_dataContext"] as ModelDataContext;
                }

                return theResult;
            }
        }
    }
}
