﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

namespace SampleWeb
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.GenericDataSource1.ExecuteSelect += new EventHandler<GenericDataSourceControl.GenericSelectArgs>(GenericDataSource1_ExecuteSelect);
        }

        void GenericDataSource1_ExecuteSelect(object sender, GenericDataSourceControl.GenericSelectArgs e)
        {
            e.SetData(
                new ArrayList()
                {
                    new {
                        Message = "Hello and Welcome to the GenericDataSourceControl showcase",
                        Body = "This message is displayed by a FormView with the GenericDataSource, via data binding.",
                    }
                });
        }
    }
}
