﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SampleWeb.Data;

namespace SampleWeb
{
    public partial class GridViewServerPaging : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Add some SQL logging
            this.GridView1.DataBound += new EventHandler(GridView1_DataBound);
        }

        void GridView1_DataBound(object sender, EventArgs e)
        {
            (this.Master as SiteMaster).Log(ModelDataContext.Instance.Log.ToString());
        }

        protected void GenericDataSource1_ExecuteSelect(object sender, GenericDataSourceControl.GenericSelectArgs e)
        {
            //Get the total row count for Tasks
            var taskCount = ModelDataContext.Instance.Tasks.Count();

            //Perform here server paging, using the Select parameters: e.SelectArguments.StartRowIndex and e.SelectArguments.MaximumRows
            var theResult = ModelDataContext.Instance.Tasks.Skip(e.SelectArguments.StartRowIndex).Take(e.SelectArguments.MaximumRows);
            e.SetPagedData(theResult, taskCount);
        }
    }
}
