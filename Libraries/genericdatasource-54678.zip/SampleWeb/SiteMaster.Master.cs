﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SampleWeb.Data;
using System.Text;

namespace SampleWeb
{
    public partial class SiteMaster : System.Web.UI.MasterPage
    {
        public void Log(string logInfo)
        {
            this.LogTextBox.Text = logInfo;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            this.SiteScript.AsyncPostBackError += new EventHandler<AsyncPostBackErrorEventArgs>(SiteScript_AsyncPostBackError);
        }

        void SiteScript_AsyncPostBackError(object sender, AsyncPostBackErrorEventArgs e)
        {
            ;
        }
    }
}
