(function($) {
    var cultures = $.cultures,
        en = cultures.en,
        standard = en.calendars.standard,
        culture = cultures["bg-BG"] = $.extend(true, {}, en, {
        name: "bg-BG",
        englishName: "Bulgarian (Bulgaria)",
        nativeName: "български (България)",
        language: "bg",
        numberFormat: {
            ',': " ",
            '.': ",",
            percent: {
                ',': " ",
                '.': ","
            },
            currency: {
                pattern: ["-n $","n $"],
                ',': " ",
                '.': ",",
                symbol: "лв."
            }
        },
        calendars: {
            standard: $.extend(true, {}, standard, {
                '/': ".",
                firstDay: 1,
                days: {
                    names: ["неделя","понеделник","вторник","сряда","четвъртък","петък","събота"],
                    namesAbbr: ["нед","пон","вт","ср","четв","пет","съб"],
                    namesShort: ["н","п","в","с","ч","п","с"]
                },
                months: {
                    names: ["януари","февруари","март","април","май","юни","юли","август","септември","октомври","ноември","декември",""],
                    namesAbbr: ["ян","февр","март","апр","май","юни","юли","авг","септ","окт","ноември","дек",""]
                },
                AM: null,
                PM: null,
                eras: [{"name":"след новата ера","start":null,"offset":0}],
                patterns: {
                    d: "d.M.yyyy 'г.'",
                    D: "dd MMMM yyyy 'г.'",
                    t: "HH:mm 'ч.'",
                    T: "HH:mm:ss 'ч.'",
                    f: "dd MMMM yyyy 'г.' HH:mm 'ч.'",
                    F: "dd MMMM yyyy 'г.' HH:mm:ss 'ч.'",
                    M: "dd MMMM",
                    Y: "MMMM yyyy 'г.'"
                }
            })
        }
    }, cultures["bg-BG"]);
    culture.calendar = culture.calendars.standard;
})(Globalization);