/**
 * jQuery.Modularize - Modular methods for jQuery.
 * Copyright (c) 2008 Ariel Flesler - aflesler(at)gmail(dot)com | http://flesler.blogspot.com
 * Dual licensed under MIT and GPL.
 * Date:4/17/2008
 * @author Ariel Flesler
 * @version 1.0.0
 */
jQuery.modularize=function(a,b,c){var $=this;c=c||$.fn;b=b||c[a];c[a]=$.extend(function(){return this._modularize_(arguments)},b,{_o_:b})};jQuery.fn._modularize_=function(a){var b=a.callee,c;if(b._o_&&a.length)return b._o_.apply(this,a);if(!b._||b.lazy){b._={};for(c in b){if(b[c]&&b[c].call&&c!='_o_'){b._[c]=function(){return arguments.callee._.apply(this._s_,arguments)};b._[c]._=b[c]}}}b._._s_=this;return b._};