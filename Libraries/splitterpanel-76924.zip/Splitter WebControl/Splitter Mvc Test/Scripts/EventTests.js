﻿Sys.onReady(function () {
    
    var splitter = $find("splitter");

    if (splitter) {

        splitter.add_dragging(splitter_onDragging);
        splitter.add_resizing(splitter_onResizing);
        splitter.add_toggling(splitter_onToggling);

        splitter.add_resized(splitter_onResized);
        splitter.add_toggled(splitter_onToggled);
    }
});

function splitter_onDragging(e, args) {

    var maxWidth = e.get_leftMaxWidth();
    var minWidth = e.get_leftMinWidth();
    var newWidth = args.get_leftWidth();
    var msg;

    if (parseInt(maxWidth) == parseInt(newWidth))
        msg = "Cannot exceed maximum of " + newWidth + ".";
    else if (parseInt(minWidth) == parseInt(newWidth))
        msg = "Cannot go below minimum width of " + minWidth + ".";
    else
        msg = "Pending Left Pane Width: " + newWidth;

    _resizeMsgDiv.innerHTML = msg;
}

function splitter_onResizing(e, args) {

    args.set_cancel(!confirm("Do you want to resize the left pane to " + args.get_leftWidth() + "?"));
}

function splitter_onToggling(e, args) {

    args.set_cancel(!confirm("Do you want to toggle?"));
}

function splitter_onResized(e, args) {

    alert("Left pane was resized. ");
}

function splitter_onToggled(e, args) {

    alert("Splitter was toggled.");
}