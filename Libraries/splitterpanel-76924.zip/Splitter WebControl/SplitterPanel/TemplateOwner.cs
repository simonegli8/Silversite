﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;

namespace SCS.Web.UI.WebControls
{
    [ToolboxItem(false)]
    public class TemplateOwner : WebControl
    {
        public override void RenderBeginTag(System.Web.UI.HtmlTextWriter writer)
        {
            //base.RenderBeginTag(writer);
        }

        public override void RenderEndTag(System.Web.UI.HtmlTextWriter writer)
        {
            //base.RenderEndTag(writer);
        }
    }
}
